package com.kisanlink.utilities;

public interface Constants1 {
	
	public static String SELLER_ID="sellerId";
	public static String SYSTEM="SYSTEM";
	public static String PLAN_ID="planId";
	public static String USER_ID = "id";
	public static String APPLICATION="application";
	public static String MARKETPLACE="marketplace";
	public static String USERID="userId";
	public static String PASSWORD="password";
	public static String KISANSATHIID = "kisanSathiId";
	public static String USERNAME = "username";
	public static String MOBILENUMBER = "mobileNumber";
	public static String USERTYPE = "userType";
	public static String REFERRALCODE = "referralCode";
	public static String PIN = "pin";
	public static String ROLES = "roles";
	
}

