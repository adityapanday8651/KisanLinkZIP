package com.kisanlink.logging.api.impl;

import com.kisanlink.logging.api.VCLogger;

public class VCLogManager {
	
	public static VCLogger getLogger(Class<?> aClass){
		return VCLoggerImpl.getLogger(aClass);
	}
}
