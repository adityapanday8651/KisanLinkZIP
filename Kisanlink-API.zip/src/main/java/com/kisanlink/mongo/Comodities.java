package com.kisanlink.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Comodities")
public class Comodities extends BaseModel {
	
	@Id
	private String id;
	private int comodityId;
	private String image;
	private String cropName;
	private String category;
	private int gstHsnCode;
	private String question1;
	private String question2;
	private String question3;
	
	
	public String getQuestion1() {
		return question1;
	}
	public String getQuestion2() {
		return question2;
	}
	public String getQuestion3() {
		return question3;
	}
	public void setQuestion1(String question1) {
		this.question1 = question1;
	}
	public void setQuestion2(String question2) {
		this.question2 = question2;
	}
	public void setQuestion3(String question3) {
		this.question3 = question3;
	}
	public String getId() {
		return id;
	}
	public int getComodityId() {
		return comodityId;
	}
	public String getImage() {
		return image;
	}
	public String getCropName() {
		return cropName;
	}
	public String getCategory() {
		return category;
	}
	public int getGstHsnCode() {
		return gstHsnCode;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setComodityId(int comodityId) {
		this.comodityId = comodityId;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public void setCropName(String cropName) {
		this.cropName = cropName;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public void setGstHsnCode(int gstHsnCode) {
		this.gstHsnCode = gstHsnCode;
	}

	@Override
	public String toString() {
		return "Comodities [id=" + id + ", comodityId=" + comodityId + ", image=" + image + ", cropName=" + cropName
				+ ", category=" + category + ", gstHsnCode=" + gstHsnCode + ", question1=" + question1 + ", question2="
				+ question2 + ", question3=" + question3 + "]";
	}
}
