package com.kisanlink.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Bids")
public class Bids extends BaseModel{
	@Id
	private String id;
	private String productName;
	private double ratePerKg;
	private String scope;
	private String labourCost;
	private String transpotationCost;
	private String dateOfDelievery;
	private String paymentTerms;
	private String status;
	
	
	public double getRatePerKg() {
		return ratePerKg;
	}
	public void setRatePerKg(double ratePerKg) {
		this.ratePerKg = ratePerKg;
	}
	public String getId() {
		return id;
	}
	public String getProductName() {
		return productName;
	}
	public String getScope() {
		return scope;
	}
	public String getLabourCost() {
		return labourCost;
	}
	public String getTranspotationCost() {
		return transpotationCost;
	}
	public String getDateOfDelievery() {
		return dateOfDelievery;
	}
	public String getPaymentTerms() {
		return paymentTerms;
	}
	public String getStatus() {
		return status;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public void setScope(String scope) {
		this.scope = scope;
	}
	public void setLabourCost(String labourCost) {
		this.labourCost = labourCost;
	}
	public void setTranspotationCost(String transpotationCost) {
		this.transpotationCost = transpotationCost;
	}
	public void setDateOfDelievery(String dateOfDelievery) {
		this.dateOfDelievery = dateOfDelievery;
	}
	public void setPaymentTerms(String paymentTerms) {
		this.paymentTerms = paymentTerms;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "Bids [id=" + id + ", productName=" + productName + ", ratePerKg=" + ratePerKg + ", scope=" + scope
				+ ", labourCost=" + labourCost + ", transpotationCost=" + transpotationCost + ", dateOfDelievery="
				+ dateOfDelievery + ", paymentTerms=" + paymentTerms + ", status=" + status + "]";
	}
}
