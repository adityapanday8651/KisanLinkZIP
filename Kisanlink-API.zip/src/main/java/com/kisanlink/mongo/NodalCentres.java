package com.kisanlink.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="NodalCentre")
public class NodalCentres extends BaseModel {

	@Id
	private String id;
	private int nodalCentreId;
	private String manager;
	private String salesValues;
	private String currentOrders;
	private String soilTestingSamples;
	private String droneSprayingAcres;
	private String contactNUmber;
	private String actions;

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getNodalCentreId() {
		return nodalCentreId;
	}
	public void setNodalCentreId(int nodalCentreId) {
		this.nodalCentreId = nodalCentreId;
	}
	public String getManager() {
		return manager;
	}
	public void setManager(String manager) {
		this.manager = manager;
	}
	public String getSalesValues() {
		return salesValues;
	}
	public void setSalesValues(String salesValues) {
		this.salesValues = salesValues;
	}
	public String getCurrentOrders() {
		return currentOrders;
	}
	public void setCurrentOrders(String currentOrders) {
		this.currentOrders = currentOrders;
	}
	public String getSoilTestingSamples() {
		return soilTestingSamples;
	}
	public void setSoilTestingSamples(String soilTestingSamples) {
		this.soilTestingSamples = soilTestingSamples;
	}
	public String getDroneSprayingAcres() {
		return droneSprayingAcres;
	}
	public void setDroneSprayingAcres(String droneSprayingAcres) {
		this.droneSprayingAcres = droneSprayingAcres;
	}
	public String getContactNUmber() {
		return contactNUmber;
	}
	public void setContactNUmber(String contactNUmber) {
		this.contactNUmber = contactNUmber;
	}
	public String getActions() {
		return actions;
	}
	public void setActions(String actions) {
		this.actions = actions;
	}
	@Override
	public String toString() {
		return "NodalCentres [id=" + id + ", nodalCentreId=" + nodalCentreId + ", manager=" + manager + ", salesValues="
				+ salesValues + ", currentOrders=" + currentOrders + ", soilTestingSamples=" + soilTestingSamples
				+ ", droneSprayingAcres=" + droneSprayingAcres + ", contactNUmber=" + contactNUmber + ", actions="
				+ actions + "]";
	}
}
