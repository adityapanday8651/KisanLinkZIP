package com.kisanlink.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="CheckOut")
public class CheckOut extends BaseModel{
	@Id
	private String id;
	private String orderFor;
	private String farmerId;
	private String fullName;
	private String mobileNumber;
	private String pinCode;
	
	public String getId() {
		return id;
	}
	public String getOrderFor() {
		return orderFor;
	}
	public String getFarmerId() {
		return farmerId;
	}
	public String getFullName() {
		return fullName;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setOrderFor(String orderFor) {
		this.orderFor = orderFor;
	}
	public void setFarmerId(String farmerId) {
		this.farmerId = farmerId;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	
	@Override
	public String toString() {
		return "CheckOut [id=" + id + ", orderFor=" + orderFor + ", farmerId=" + farmerId + ", fullName=" + fullName
				+ ", mobileNumber=" + mobileNumber + ", pinCode=" + pinCode + "]";
	}
}
