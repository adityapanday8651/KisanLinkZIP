package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.NodalCentres;
import com.kisanlink.mongo.manager.NodalCentresManager;
import com.kisanlink.mongo.repository.NodalCentresRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("NodalCentresManager")
public class NodalCentresManagerImpl implements NodalCentresManager {
    @Autowired NodalCentresRepository nodalCentresRepository;
    @Autowired GenericSearchRepository genericSearchRepository;
	@Override
	public void save(NodalCentres bean) throws ServiceException {
		nodalCentresRepository.save(bean);
	}

	@Override
	public void save(List<NodalCentres> beans) throws ServiceException {
		nodalCentresRepository.saveAll(beans);
	}

	@Override
	public boolean update(NodalCentres bean) throws ServiceException {
		nodalCentresRepository.save(bean);
 		return true;
	}

	@Override
	public long getCount() throws ServiceException {
 		return nodalCentresRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<NodalCentres> search(SearchRequest request) {
 		return (List<NodalCentres>) genericSearchRepository.search(request, NodalCentres.class);
	}

	@Override
	public NodalCentres findByid(String id) {
 		return nodalCentresRepository.findByid(id);
	}

	@Override
	public long searchCount(SearchRequest request) {
 		return genericSearchRepository.searchCount(request, NodalCentres.class);
	}

}
