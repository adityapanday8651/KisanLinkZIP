package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.LoginHistory;
import com.kisanlink.service.core.AbstractService;

public interface LoginHistoryManager extends AbstractService<LoginHistory>{
	List<LoginHistory> findByUserId(String userId);

	long searchCount(SearchRequest request);
}
