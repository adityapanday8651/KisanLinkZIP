package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.FavouriteFarmers;
import com.kisanlink.service.core.AbstractService;

public interface FavouriteFarmersManager extends AbstractService<FavouriteFarmers>{
	List<FavouriteFarmers> findAll();
	FavouriteFarmers findByFarmerName(String farmerName);
	FavouriteFarmers findByFarmerId(int farmerId);
}
