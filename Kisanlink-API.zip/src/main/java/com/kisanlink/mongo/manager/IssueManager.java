package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.Issue;
import com.kisanlink.service.core.AbstractService;

public interface IssueManager extends AbstractService<Issue>{
	List<Issue> findAll();

	Issue findByFarmerId(String farmerId);
}
