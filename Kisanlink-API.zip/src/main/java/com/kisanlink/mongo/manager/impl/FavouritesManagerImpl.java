package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Favourites;
import com.kisanlink.mongo.manager.FavouritesManager;
import com.kisanlink.mongo.repository.FavouritesReposiory;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("FavouritesManager")
public class FavouritesManagerImpl implements FavouritesManager {
    
	@Autowired  FavouritesReposiory favouritesRepository;
	@Autowired  GenericSearchRepository genericSearchRepository;
	@Override
	public void save(Favourites bean) throws ServiceException {
		favouritesRepository.save(bean);
	}

	@Override
	public void save(List<Favourites> beans) throws ServiceException {
		favouritesRepository.saveAll(beans);
	}

	@Override
	public boolean update(Favourites bean) throws ServiceException {
		favouritesRepository.save(bean);
 		return true;
	}

	@Override
	public long getCount() throws ServiceException {
 		return favouritesRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Favourites> search(SearchRequest request) {
 		return  (List<Favourites>) genericSearchRepository.search(request, Favourites.class );
	}
	
	@Override
	public long searchCount(SearchRequest request) {
 		return   genericSearchRepository.searchCount(request, Favourites.class );
	}

	@Override
	public Favourites findByfavId(String favId) {
 		return favouritesRepository.findByfavId(favId);
	}

	 
	
}
