package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.ServiceProvider;
import com.kisanlink.mongo.manager.ServiceProviderManager;
import com.kisanlink.mongo.repository.ServiceProviderRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("ServiceProviderManager")
public class ServiceProviderManagerImpl implements ServiceProviderManager{
	
	@Autowired ServiceProviderRepository serviceProviderRepository;
	@Autowired GenericSearchRepository searchRepository;
	
	@Override
	public void save(ServiceProvider bean) throws ServiceException {
		serviceProviderRepository.save(bean);
	}

	@Override
	public void save(List<ServiceProvider> beans) throws ServiceException {
		serviceProviderRepository.saveAll(beans);
	}

	@Override
	public boolean update(ServiceProvider bean) throws ServiceException {
		serviceProviderRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return serviceProviderRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ServiceProvider> search(SearchRequest request) {
		return (List<ServiceProvider>) searchRepository.search(request, ServiceProvider.class);
	}

	@Override
	public List<ServiceProvider> findAll() {
		return serviceProviderRepository.findAll();
	}

	@Override
	public ServiceProvider findByFarmerId(String farmerId) {
		return serviceProviderRepository.findByFarmerId(farmerId);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return 0;
	}

}
