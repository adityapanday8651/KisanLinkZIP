package com.kisanlink.mongo.manager;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Favourites;
import com.kisanlink.service.core.AbstractService;

public interface FavouritesManager extends AbstractService<Favourites> {
    public Favourites findByfavId(String favId);
	long searchCount(SearchRequest request);

}
