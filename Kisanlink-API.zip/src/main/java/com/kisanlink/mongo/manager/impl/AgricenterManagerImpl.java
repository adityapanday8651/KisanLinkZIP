package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Agricenter;
import com.kisanlink.mongo.manager.AgricenterManager;
import com.kisanlink.mongo.repository.AgricenterRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("AgricenterManager")
public class AgricenterManagerImpl implements AgricenterManager{
	
	@Autowired GenericSearchRepository searchRepository;
	@Autowired AgricenterRepository agricenterRepository;
	@Override
	public void save(Agricenter bean) throws ServiceException {
		agricenterRepository.save(bean);
		
	}

	@Override
	public void save(List<Agricenter> beans) throws ServiceException {
		agricenterRepository.saveAll(beans);
	}

	@Override
	public boolean update(Agricenter bean) throws ServiceException {
		agricenterRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return agricenterRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Agricenter> search(SearchRequest request) {
		return (List<Agricenter>) searchRepository.search(request, Agricenter.class);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return searchRepository.searchCount(request, Agricenter.class);
	}

	@Override
	public List<Agricenter> findAll() {
		return agricenterRepository.findAll();
	}

	@Override
	public Agricenter findByName(String name) {
		return agricenterRepository.findByName(name);
	}
}
