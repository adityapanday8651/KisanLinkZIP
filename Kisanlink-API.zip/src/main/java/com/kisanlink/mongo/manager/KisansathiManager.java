package com.kisanlink.mongo.manager;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Kisansathi;
import com.kisanlink.service.core.AbstractService;

public interface KisansathiManager extends AbstractService<Kisansathi> {
	public Kisansathi findByid(String id);
	public long searchCount(SearchRequest request);
}