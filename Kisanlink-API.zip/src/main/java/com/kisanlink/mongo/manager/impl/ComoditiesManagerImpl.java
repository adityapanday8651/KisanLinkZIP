package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Comodities;
import com.kisanlink.mongo.manager.ComoditiesManager;
import com.kisanlink.mongo.repository.ComoditiesRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("ComoditiesManager")
public class ComoditiesManagerImpl implements ComoditiesManager {
	
	@Autowired ComoditiesRepository comoditiesRepository;
	@Autowired GenericSearchRepository genericSearchRepository;
	@Override
	public void save(Comodities bean) throws ServiceException {
		comoditiesRepository.save(bean);
	}

	@Override
	public void save(List<Comodities> beans) throws ServiceException {
		comoditiesRepository.saveAll(beans);
	}

	@Override
	public boolean update(Comodities bean) throws ServiceException {
		comoditiesRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
 		return comoditiesRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Comodities> search(SearchRequest request) {
 		return (List<Comodities>) genericSearchRepository.search(request, Comodities.class);
	}
	
	@Override
	public long searchCount(SearchRequest request) {
 		return   genericSearchRepository.searchCount(request, Comodities.class);
	}

	@Override
	public Comodities findByid(String id) {
 		return comoditiesRepository.findByid(id);
	}

	@Override
	public void deleteById(String id) {
		// TODO Auto-generated method stub
		comoditiesRepository.deleteById(id);
	}
	
	 
}
