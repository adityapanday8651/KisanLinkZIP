package com.kisanlink.mongo.manager;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Output;
import com.kisanlink.service.core.AbstractService;

public interface OutputManager extends AbstractService<Output> {
	long searchCount(SearchRequest request);
	public Output findByid(String id);
}
