package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.FarmersConfiguration;
import com.kisanlink.service.core.AbstractService;

public interface FarmersConfigurationManager extends AbstractService<FarmersConfiguration>{
	List<FarmersConfiguration> findAll();

	FarmersConfiguration findByFarmerId(int farmerId);
}
