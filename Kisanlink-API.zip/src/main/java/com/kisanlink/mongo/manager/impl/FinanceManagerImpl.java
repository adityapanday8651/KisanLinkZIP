package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Finance;
import com.kisanlink.mongo.manager.FinanceManager;
import com.kisanlink.mongo.repository.FinanceRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("FinanceManager")
public class FinanceManagerImpl implements FinanceManager {
    @Autowired FinanceRepository financeRepository;
    @Autowired GenericSearchRepository genericSearchRepository;
	@Override
	public void save(Finance bean) throws ServiceException {
		financeRepository.save(bean);
	}

	@Override
	public void save(List<Finance> beans) throws ServiceException {
		financeRepository.saveAll(beans);
	}

	@Override
	public boolean update(Finance bean) throws ServiceException {
		financeRepository.save(bean);
 		return true;
	}

	@Override
	public long getCount() throws ServiceException {
 		return financeRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Finance> search(SearchRequest request) {
 		return (List<Finance>) genericSearchRepository.search(request, Finance.class);
	}
	@Override
	public long searchCount(SearchRequest request) {
 		return  genericSearchRepository.searchCount(request, Finance.class);
	}

	@Override
	public Finance findByid(String id) {
 		return financeRepository.findByid(id);
	}

}
