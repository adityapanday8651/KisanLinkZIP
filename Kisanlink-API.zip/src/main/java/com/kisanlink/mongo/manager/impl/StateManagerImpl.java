package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.State;
import com.kisanlink.mongo.manager.StateManager;
import com.kisanlink.mongo.repository.StateRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("StateManager")
public class StateManagerImpl implements StateManager{

	@Autowired StateRepository stateRepository;
	@Autowired GenericSearchRepository searchRepository;
	
	@Override
	public void save(State bean) throws ServiceException {
		stateRepository.save(bean);
	}

	@Override
	public void save(List<State> beans) throws ServiceException {
		stateRepository.saveAll(beans);
	}

	@Override
	public boolean update(State bean) throws ServiceException {
		stateRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return stateRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<State> search(SearchRequest request) {
		return (List<State>) searchRepository.search(request, State.class);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return searchRepository.searchCount(request, State.class);
	}

	@Override
	public List<State> findAll() {
		return stateRepository.findAll();
	}

	@Override
	public State findByStateId(int stateId) {
		return stateRepository.findByStateId(stateId);
	}

}
