package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Services;
import com.kisanlink.mongo.manager.ServicesManager;
import com.kisanlink.mongo.repository.ServicesRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("ServicesManager")
public class ServicesManagerImpl implements ServicesManager{
	@Autowired ServicesRepository servicesRepository;
	@Autowired GenericSearchRepository searchRepository;

	@Override
	public void save(Services bean) throws ServiceException {
		servicesRepository.save(bean);
	}

	@Override
	public void save(List<Services> beans) throws ServiceException {
		servicesRepository.saveAll(beans);
	}

	@Override
	public boolean update(Services bean) throws ServiceException {
		servicesRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return servicesRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Services> search(SearchRequest request) {
		return (List<Services>) searchRepository.search(request, Services.class);
	}

	@Override
	public Services findByFarmerId(String farmerId) {
		return servicesRepository.findByFarmerId(farmerId);
	}

	@Override
	public List<Services> findAll() {
		return servicesRepository.findAll();
	}

	@Override
	public long searchCount(SearchRequest request) {
		return 0;
	}

}
