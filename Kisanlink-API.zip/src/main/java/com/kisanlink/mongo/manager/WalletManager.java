package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.Wallet;
import com.kisanlink.service.core.AbstractService;

public interface WalletManager extends AbstractService<Wallet>{
	List<Wallet> findAll();

	Wallet findByWalletId(String walletId);
}
