package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.Reports;
import com.kisanlink.service.core.AbstractService;

public interface ReportsManager extends AbstractService<Reports>{
	List<Reports> findAll();
	Reports findByReportId(String reportId);
}
