package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Issue;
import com.kisanlink.mongo.manager.IssueManager;
import com.kisanlink.mongo.repository.IssueRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("IssueManager")
public class IssueManagerImpl implements IssueManager{
	@Autowired IssueRepository issueRepository;
	@Autowired GenericSearchRepository searchRepository;

	@Override
	public void save(Issue bean) throws ServiceException {
		issueRepository.save(bean);
	}

	@Override
	public void save(List<Issue> beans) throws ServiceException {
		issueRepository.saveAll(beans);
	}

	@Override
	public boolean update(Issue bean) throws ServiceException {
		issueRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return issueRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Issue> search(SearchRequest request) {
		return (List<Issue>) searchRepository.search(request, Issue.class);
	}

	@Override
	public List<Issue> findAll() {
		return issueRepository.findAll();
	}

	@Override
	public Issue findByFarmerId(String farmerId) {
		return issueRepository.findByFarmerId(farmerId);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return 0;
	}

}
