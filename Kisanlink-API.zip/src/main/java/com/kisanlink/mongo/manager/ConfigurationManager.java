package com.kisanlink.mongo.manager;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Configuration;
import com.kisanlink.service.core.AbstractService;

public interface ConfigurationManager extends AbstractService<Configuration>{
	Configuration findByKey(String key);
	String findValueByKey(String key);
	long searchCount(SearchRequest request);
}
