package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.AreaManagers;
import com.kisanlink.service.core.AbstractService;

public interface AreaManagersManager extends AbstractService<AreaManagers>{
	List<AreaManagers> findAll();
	AreaManagers findByAreaManagerId(int areaManagerId);
	void deleteById(String id);
}
