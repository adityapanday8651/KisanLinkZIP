package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.RewardsEarned;
import com.kisanlink.service.core.AbstractService;

public interface RewardsEarnedManager extends AbstractService<RewardsEarned>{
	List<RewardsEarned> findAll();

	RewardsEarned findByReferralCode(String referralCode);
}
