package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.State;
import com.kisanlink.service.core.AbstractService;

public interface StateManager extends AbstractService<State>{
	List<State> findAll();

	State findByStateId(int stateId);
}
