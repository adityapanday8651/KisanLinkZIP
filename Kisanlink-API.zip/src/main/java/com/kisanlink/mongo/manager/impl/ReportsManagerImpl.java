package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Reports;
import com.kisanlink.mongo.manager.ReportsManager;
import com.kisanlink.mongo.repository.ReportsRepository;

@Service("ReportsManager")
public class ReportsManagerImpl implements ReportsManager{

	@Autowired ReportsRepository reportsRepository;
	
	@Override
	public void save(Reports bean) throws ServiceException {
		reportsRepository.save(bean);
	}

	@Override
	public void save(List<Reports> beans) throws ServiceException {
		reportsRepository.saveAll(beans);
	}

	@Override
	public boolean update(Reports bean) throws ServiceException {
		reportsRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return reportsRepository.count();
	}

	@Override
	public List<Reports> search(SearchRequest request) {
		return null;
	}

	@Override
	public List<Reports> findAll() {
		return reportsRepository.findAll();
	}

	@Override
	public Reports findByReportId(String reportId) {
		return reportsRepository.findByReportId(reportId);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return 0;
	}
	

}
