package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Promotions;
import com.kisanlink.mongo.manager.PromotionsManager;
import com.kisanlink.mongo.repository.PromotionsRepository;

@Service("PromotionsManager")
public class PromotionsManagerImpl implements PromotionsManager{
	
	@Autowired PromotionsRepository promotionsRepository;
	
	@Override
	public void save(Promotions bean) throws ServiceException {
		promotionsRepository.save(bean);
	}

	@Override
	public void save(List<Promotions> beans) throws ServiceException {
		promotionsRepository.saveAll(beans);
	}

	@Override
	public boolean update(Promotions bean) throws ServiceException {
		promotionsRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return promotionsRepository.count();
	}

	@Override
	public List<Promotions> search(SearchRequest request) {
		return null;
	}

	@Override
	public List<Promotions> findAll() {
		return promotionsRepository.findAll();
	}

	@Override
	public Promotions findByCampaignId(String campaignId) {
		return promotionsRepository.findByCampaignId(campaignId);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return 0;
	}

}
