package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.Loan;
import com.kisanlink.service.core.AbstractService;

public interface LoanManager extends AbstractService<Loan>{
	List<Loan> findAll();

	Loan findByFarmerId(String farmerId);
	
}
