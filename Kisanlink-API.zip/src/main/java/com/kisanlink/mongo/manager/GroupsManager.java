package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.Groups;
import com.kisanlink.service.core.AbstractService;

public interface GroupsManager extends AbstractService<Groups>{
	List<Groups> findAll();

	Groups findByGroupName(String groupName);
}
