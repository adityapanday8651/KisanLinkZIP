package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Groups;
import com.kisanlink.mongo.manager.GroupsManager;
import com.kisanlink.mongo.repository.GroupsRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("GroupsManager")
public class GroupsManagerImpl implements GroupsManager{
	
	@Autowired GroupsRepository groupsRepository;
	@Autowired GenericSearchRepository searchRepository;
	
	@Override
	public void save(Groups bean) throws ServiceException {
		groupsRepository.save(bean);
	}

	@Override
	public void save(List<Groups> beans) throws ServiceException {
		groupsRepository.saveAll(beans);
	}

	@Override
	public boolean update(Groups bean) throws ServiceException {
		groupsRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return groupsRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Groups> search(SearchRequest request) {
		return (List<Groups>) searchRepository.search(request, Groups.class);
	}

	@Override
	public List<Groups> findAll() {
		return groupsRepository.findAll();
	}

	@Override
	public Groups findByGroupName(String groupName) {
		return groupsRepository.findByGroupName(groupName);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return searchRepository.searchCount(request, Groups.class);
	}
}
