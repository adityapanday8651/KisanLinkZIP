package com.kisanlink.mongo.manager;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Finance;
import com.kisanlink.service.core.AbstractService;

public interface FinanceManager extends AbstractService<Finance> {
	 long searchCount(SearchRequest request);
	 public Finance findByid(String id);
}
