package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Output;
import com.kisanlink.mongo.manager.OutputManager;
import com.kisanlink.mongo.repository.OutputRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("OutputManager")
public class OutputManagerImpl implements OutputManager {
	@Autowired OutputRepository outputRepository;
	@Autowired GenericSearchRepository genericSearchRepository;
	@Override
	public void save(Output bean) throws ServiceException {
		outputRepository.save(bean);
	}

	@Override
	public void save(List<Output> beans) throws ServiceException {
		outputRepository.saveAll(beans);
	}

	@Override
	public boolean update(Output bean) throws ServiceException {
		outputRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return outputRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Output> search(SearchRequest request) {
		return (List<Output>) genericSearchRepository.search(request,Output.class);
	}
	@Override
	public long searchCount(SearchRequest request) {
		return   genericSearchRepository.searchCount(request,Output.class);
	}

	@Override
	public Output findByid(String id) {
 		return outputRepository.findByid(id);
	}

}
