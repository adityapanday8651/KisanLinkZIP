package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.AreaManagers;
import com.kisanlink.mongo.manager.AreaManagersManager;
import com.kisanlink.mongo.repository.AreaManagersRepository;
import com.kisanlink.service.core.GenericSearchRepository;
@Service("AreaManagers")
public class AreaManagersManagerImpl implements AreaManagersManager{
	
	@Autowired AreaManagersRepository areaManagersRepository;
	@Autowired GenericSearchRepository searchRepository;
	
	@Override
	public void save(AreaManagers bean) throws ServiceException {
		areaManagersRepository.save(bean);
	}

	@Override
	public void save(List<AreaManagers> beans) throws ServiceException {
		areaManagersRepository.saveAll(beans);
	}

	@Override
	public boolean update(AreaManagers bean) throws ServiceException {
		areaManagersRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return areaManagersRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AreaManagers> search(SearchRequest request) {
		return (List<AreaManagers>) searchRepository.search(request, AreaManagers.class);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return searchRepository.searchCount(request, AreaManagers.class);
	}

	@Override
	public List<AreaManagers> findAll() {
		return areaManagersRepository.findAll();
	}

	@Override
	public AreaManagers findByAreaManagerId(int areaManagerId) {
		return areaManagersRepository.findByAreaManagerId(areaManagerId);
	}

	@Override
	public void deleteById(String id) {
		areaManagersRepository.deleteById(id);
	}
}
