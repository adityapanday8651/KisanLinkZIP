package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.Products;
import com.kisanlink.service.core.AbstractService;

public interface ProductsManager extends AbstractService<Products>{
	List<Products> findAll();
	Products findByProductId(int productId);
	void findById(String id);
}
