package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Farmers;
import com.kisanlink.mongo.manager.FarmersManager;
import com.kisanlink.mongo.repository.FarmersRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("FarmersManager")
public class FarmersManagerImpl implements FarmersManager{
	@Autowired FarmersRepository farmersRepository;
	@Autowired GenericSearchRepository searchRepository;

	@Override
	public void save(Farmers bean) throws ServiceException {
		farmersRepository.save(bean);
	}

	@Override
	public void save(List<Farmers> beans) throws ServiceException {
		farmersRepository.saveAll(beans);
	}

	@Override
	public boolean update(Farmers bean) throws ServiceException {
		farmersRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return farmersRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Farmers> search(SearchRequest request) {
		return (List<Farmers>) searchRepository.search(request, Farmers.class);
	}

	@Override
	public List<Farmers> findAll() {
		return farmersRepository.findAll();
	}

	@Override
	public Farmers findByMobileNumber(long farmerId) {
		return farmersRepository.findByMobileNumber(farmerId);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return 0;
	}

	@Override
	public void deleteById(String id) {
		farmersRepository.deleteById(id);
	}

	@Override
	public Farmers findByFarmerId(int farmerId) {
		return farmersRepository.findByFarmerId(farmerId);
	}
}