package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Payment;
import com.kisanlink.mongo.manager.PaymentManager;
import com.kisanlink.mongo.repository.PaymentRepository;
import com.kisanlink.service.core.GenericSearchRepository;
@Service("PaymentManager")
public class PaymentManagerImpl implements PaymentManager{
    
	@Autowired PaymentRepository paymentRepository;
	@Autowired GenericSearchRepository genericSearchRepository;
	@Override
	public void save(Payment bean) throws ServiceException {
		paymentRepository.save(bean);		
	}

	@Override
	public void save(List<Payment> beans) throws ServiceException {
		paymentRepository.saveAll(beans);
	}

	@Override
	public boolean update(Payment bean) throws ServiceException {
		paymentRepository.save(bean);
 		return true;
	}

	@Override
	public long getCount() throws ServiceException {
 		return paymentRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Payment> search(SearchRequest request) {
 		return (List<Payment>) genericSearchRepository.search(request,Payment.class);
	}
	@Override
	public long searchCount(SearchRequest request) {
 		return genericSearchRepository.searchCount(request,Payment.class);
	}

	@Override
	public Payment findByid(String id) {
 		return paymentRepository.findByid(id);
	}

}
