package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Configuration;
import com.kisanlink.mongo.manager.ConfigurationManager;
import com.kisanlink.mongo.repository.ConfigurationRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("ConfigurationManager")
public class ConfigurationManagerImpl implements ConfigurationManager {
	@Autowired private ConfigurationRepository repository;
	@Autowired GenericSearchRepository searchRepo;

	@Override
	public void save(Configuration bean) throws ServiceException {
		repository.save(bean);
	}

	@Override
	public void save(List<Configuration> beans) throws ServiceException {
		repository.saveAll(beans);
	}

	@Override
	public boolean update(Configuration bean) throws ServiceException {
		repository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return repository.count();
	}

	@Override @Cacheable
	public Configuration findByKey(String key) {
		return repository.findByKey(key);
	}

	@Override @Cacheable
	public String findValueByKey(String key) {
		Configuration config = repository.findByKey(key);
		return (config != null?config.getValue():null);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return searchRepo.searchCount(request, Configuration.class);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Configuration> search(SearchRequest request) {
 		return (List<Configuration>) searchRepo.search(request, Configuration.class);
	}
}

