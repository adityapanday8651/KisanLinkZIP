package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.Agricenter;
import com.kisanlink.service.core.AbstractService;

public interface AgricenterManager extends AbstractService<Agricenter>{
	List<Agricenter> findAll();
	Agricenter findByName(String name);
}
