package com.kisanlink.mongo.manager;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.OTPDetails;
import com.kisanlink.service.core.AbstractService;

public interface OTPDetailsManager extends AbstractService<OTPDetails>{

	OTPDetails findByMobileNumber(long id);

	long searchCount(SearchRequest request);

}
