package com.kisanlink.mongo.manager;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Subsidies;
import com.kisanlink.service.core.AbstractService;

public interface SubsidiesManager extends AbstractService<Subsidies> {
	public Subsidies findByid(String id);
	long searchCount(SearchRequest request);
}
