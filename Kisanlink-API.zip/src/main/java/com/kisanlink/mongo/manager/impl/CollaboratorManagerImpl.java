package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Collaborator;
import com.kisanlink.mongo.manager.CollaboratorManager;
import com.kisanlink.mongo.repository.CollaboratorRepository;
import com.kisanlink.service.core.GenericSearchRepository;
@Service("CollaboratorManager")
public class CollaboratorManagerImpl implements CollaboratorManager {
    @Autowired CollaboratorRepository collaboratorRepository;
    @Autowired GenericSearchRepository genericSearchRepository;
	@Override
	public void save(Collaborator bean) throws ServiceException {
		collaboratorRepository.save(bean);
	}

	@Override
	public void save(List<Collaborator> beans) throws ServiceException {
		collaboratorRepository.saveAll(beans);
	}

	@Override
	public boolean update(Collaborator bean) throws ServiceException {
		collaboratorRepository.save(bean);
 		return true;
	}

	@Override
	public long getCount() throws ServiceException {
 		return collaboratorRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Collaborator> search(SearchRequest request) {
 		return (List<Collaborator>) genericSearchRepository.search(request,  Collaborator.class);
	}
	
	public long searchCount(SearchRequest request) {
 		return genericSearchRepository.searchCount(request,  Collaborator.class);
	}

	@Override
	public Collaborator findByid(String id) {
 		return collaboratorRepository.findByid(id);
	}

}
