package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.FranchiseCentres;
import com.kisanlink.mongo.manager.FranchiseManager;
import com.kisanlink.mongo.repository.FranchiseRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("FranchiseManager")
public class FranchiseManagerImpl implements FranchiseManager{
	@Autowired FranchiseRepository franchiseRepository;
	@Autowired GenericSearchRepository genericSearchRepository;
	@Override
	public void save(FranchiseCentres bean) throws ServiceException {
		franchiseRepository.save(bean);		
	}

	@Override
	public void save(List<FranchiseCentres> beans) throws ServiceException {
		franchiseRepository.saveAll(beans);	
	}

	@Override
	public boolean update(FranchiseCentres bean) throws ServiceException {
		franchiseRepository.save(bean);
 		return true;
	}

	@Override
	public long getCount() throws ServiceException {
 		return franchiseRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<FranchiseCentres> search(SearchRequest request) {
 		return (List<FranchiseCentres>) genericSearchRepository.search(request,FranchiseCentres.class);
	}

	@Override
	public FranchiseCentres findByid(String id) {
 		return franchiseRepository.findByid(id);
	}

	@Override
	public long searchCount(SearchRequest request) {
 		return genericSearchRepository.searchCount(request,FranchiseCentres.class);
	}

}
