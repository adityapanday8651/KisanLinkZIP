package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.Interests;
import com.kisanlink.service.core.AbstractService;

public interface InterestsManager extends AbstractService<Interests>{
	List<Interests> findAll();
	Interests findByInterestId(String interestId);
	
}
