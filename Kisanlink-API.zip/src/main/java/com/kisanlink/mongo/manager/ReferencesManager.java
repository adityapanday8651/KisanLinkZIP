package com.kisanlink.mongo.manager;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.References;
import com.kisanlink.service.core.AbstractService;

public interface ReferencesManager extends AbstractService<References> {
	References findByid(String id);
	long searchCount(SearchRequest request);
}
