package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Categories;
import com.kisanlink.mongo.manager.CategoriesManager;
import com.kisanlink.mongo.repository.CategoriesRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("CategoriesManager")
public class CategoriesManagerImpl implements CategoriesManager{
	
	@Autowired CategoriesRepository categoriesRepository;
	@Autowired GenericSearchRepository searchRepository;

	@Override
	public void save(Categories bean) throws ServiceException {
		// TODO Auto-generated method stub
		categoriesRepository.save(bean);
	}

	@Override
	public void save(List<Categories> beans) throws ServiceException {
		// TODO Auto-generated method stub
		categoriesRepository.saveAll(beans);
	}

	@Override
	public boolean update(Categories bean) throws ServiceException {
		// TODO Auto-generated method stub
		categoriesRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return categoriesRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Categories> search(SearchRequest request) {
		return (List<Categories>) searchRepository.search(request, Categories.class);
	}

	@Override
	public List<Categories> findAll() {
		return categoriesRepository.findAll();
	}

	@Override
	public Categories findByCategoryId(int categoryId) {
		return categoriesRepository.findByCategoryId(categoryId);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return searchRepository.searchCount(request, Categories.class);
	}
	
	@Override
	public void deleteById(String id) {
		// TODO Auto-generated method stub
		categoriesRepository.deleteById(id);
	}
}
