package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.PersonalDetails;
import com.kisanlink.mongo.manager.PersonalDetailsManager;
import com.kisanlink.mongo.repository.PersonalDetailsRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("PersonalDetailsManager")
public class PersonalDetailsManagerImpl implements PersonalDetailsManager{
	
	@Autowired PersonalDetailsRepository personalDetailsRepository;
	@Autowired GenericSearchRepository searchRepository;

	@Override
	public void save(PersonalDetails bean) throws ServiceException {
		personalDetailsRepository.save(bean);
		
	}

	@Override
	public void save(List<PersonalDetails> beans) throws ServiceException {
		personalDetailsRepository.saveAll(beans);
	}

	@Override
	public boolean update(PersonalDetails bean) throws ServiceException {
		personalDetailsRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return personalDetailsRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PersonalDetails> search(SearchRequest request) {
		return (List<PersonalDetails>) searchRepository.search(request, PersonalDetails.class);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return searchRepository.searchCount(request, PersonalDetails.class);
	}

	@Override
	public List<PersonalDetails> findAll() {
		return personalDetailsRepository.findAll();
	}

	@Override
	public PersonalDetails findByUserId(String userId) {
		return personalDetailsRepository.findByUserId(userId);
	}

}
