package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Wallet;
import com.kisanlink.mongo.manager.WalletManager;
import com.kisanlink.mongo.repository.WalletRepository;

@Service("WalletManager")
public class WalletManagerImpl implements WalletManager{
	
	@Autowired WalletRepository walletRepository;
	
	@Override
	public void save(Wallet bean) throws ServiceException {
		walletRepository.save(bean);
	}

	@Override
	public void save(List<Wallet> beans) throws ServiceException {
		walletRepository.saveAll(beans);
	}

	@Override
	public boolean update(Wallet bean) throws ServiceException {
		walletRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return walletRepository.count();
	}

	@Override
	public List<Wallet> search(SearchRequest request) {
		return null;
	}

	@Override
	public List<Wallet> findAll() {
		return walletRepository.findAll();
	}

	@Override
	public Wallet findByWalletId(String walletId) {
		return walletRepository.findByWalletId(walletId);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return 0;
	}

}
