package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.Courses;
import com.kisanlink.service.core.AbstractService;

public interface CoursesManager extends AbstractService<Courses>{
	List<Courses> findAll();

	Courses findByCourseId(String courseId);
}
