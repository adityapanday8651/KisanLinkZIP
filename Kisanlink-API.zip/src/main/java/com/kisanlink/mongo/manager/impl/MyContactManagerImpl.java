package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.MyContact;
import com.kisanlink.mongo.manager.MyContactManager;
import com.kisanlink.mongo.repository.MyContactRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("MyContactManager")
public class MyContactManagerImpl implements MyContactManager{
	
	@Autowired MyContactRepository myContactRepository;
	@Autowired GenericSearchRepository searchRepository;
	
	
	@Override
	public void save(MyContact bean) throws ServiceException {
		myContactRepository.save(bean);
	}

	@Override
	public void save(List<MyContact> beans) throws ServiceException {
		myContactRepository.saveAll(beans);
	}

	@Override
	public boolean update(MyContact bean) throws ServiceException {
		myContactRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return myContactRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<MyContact> search(SearchRequest request) {
		return (List<MyContact>) searchRepository.search(request, MyContact.class);
	}

	@Override
	public List<MyContact> findAll() {
		return myContactRepository.findAll();
	}

	@Override
	public MyContact findByMobileNumber(String mobileNumber) {
		return myContactRepository.findByMobileNumber(mobileNumber);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return searchRepository.searchCount(request, MyContact.class);
	}

}
