package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.CheckOut;
import com.kisanlink.service.core.AbstractService;

public interface CheckOutManager extends AbstractService<CheckOut>{
	List<CheckOut> findAll();

	CheckOut findByFarmerId(String farmerId);
}
