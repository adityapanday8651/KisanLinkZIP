package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.AllIdConfiguration;
import com.kisanlink.mongo.manager.AllIdConfigurationManager;
import com.kisanlink.mongo.repository.AllIdConfigurationRepository;

@Service("AllIdConfigurationManager")
public class AllIdConfigurationManagerImpl implements AllIdConfigurationManager{
	@Autowired AllIdConfigurationRepository allIdConfigurationRepository;

	@Override
	public void save(AllIdConfiguration bean) throws ServiceException {
		allIdConfigurationRepository.save(bean);
	}

	@Override
	public void save(List<AllIdConfiguration> beans) throws ServiceException {
		allIdConfigurationRepository.saveAll(beans);
	}

	@Override
	public boolean update(AllIdConfiguration bean) throws ServiceException {
		allIdConfigurationRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return allIdConfigurationRepository.count();
	}

	@Override
	public List<AllIdConfiguration> search(SearchRequest request) {
		return null;
	}

	@Override
	public List<AllIdConfiguration> findAll() {
		return allIdConfigurationRepository.findAll();
	}

	@Override
	public AllIdConfiguration findByName(String name) {
		return allIdConfigurationRepository.findByName(name);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return 0;
	}
}