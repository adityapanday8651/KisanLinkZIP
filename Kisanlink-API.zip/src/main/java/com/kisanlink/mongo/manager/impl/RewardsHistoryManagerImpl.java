package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.RewardsHistory;
import com.kisanlink.mongo.manager.RewardsHistoryManager;
import com.kisanlink.mongo.repository.RewardsHistoryRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("RewardsHistoryManager")
public class RewardsHistoryManagerImpl implements RewardsHistoryManager{
	
	@Autowired RewardsHistoryRepository rewardsHistoryRepository;
	@Autowired GenericSearchRepository searchRepository;
	
	@Override
	public void save(RewardsHistory bean) throws ServiceException {
		rewardsHistoryRepository.save(bean);
	}

	@Override
	public void save(List<RewardsHistory> beans) throws ServiceException {
		rewardsHistoryRepository.saveAll(beans);
	}

	@Override
	public boolean update(RewardsHistory bean) throws ServiceException {
		rewardsHistoryRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return rewardsHistoryRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<RewardsHistory> search(SearchRequest request) {
		return (List<RewardsHistory>) searchRepository.search(request, RewardsHistory.class);
	}

	@Override
	public List<RewardsHistory> findAll() {
		return rewardsHistoryRepository.findAll();
	}

	@Override
	public RewardsHistory findByName(String name) {
		return rewardsHistoryRepository.findByName(name);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return 0;
	}

}
