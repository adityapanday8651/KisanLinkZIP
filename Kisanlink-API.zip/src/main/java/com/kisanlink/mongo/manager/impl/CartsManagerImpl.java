package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Carts;
import com.kisanlink.mongo.manager.CartsManager;
import com.kisanlink.mongo.repository.CartsRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("CartsManager")
public class CartsManagerImpl implements CartsManager{
	
	@Autowired CartsRepository cartsRepository;
	@Autowired GenericSearchRepository searchRepository;

	@Override
	public void save(Carts bean) throws ServiceException {
		cartsRepository.save(bean);	
	}

	@Override
	public void save(List<Carts> beans) throws ServiceException {
		cartsRepository.saveAll(beans);
		
	}

	@Override
	public boolean update(Carts bean) throws ServiceException {
		cartsRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return cartsRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Carts> search(SearchRequest request) {
		return (List<Carts>) searchRepository.search(request, Carts.class);
	}

	@Override
	public List<Carts> findAll() {
		return cartsRepository.findAll();
	}

	@Override
	public Carts findByCategoryId(String categoryId) {
		return cartsRepository.findByCategoryId(categoryId);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return 0;
	}

}
