package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.Crop;
import com.kisanlink.service.core.AbstractService;

public interface CropManager extends AbstractService<Crop>{
	List<Crop> findAll();

	Crop findByCropId(int cropId);

	void deleteByCropId(int cropId);
}
