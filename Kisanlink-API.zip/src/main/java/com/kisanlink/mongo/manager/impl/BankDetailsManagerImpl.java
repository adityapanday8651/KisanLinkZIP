package com.kisanlink.mongo.manager.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.BankDetails;
import com.kisanlink.mongo.manager.BankDetailsManager;
import com.kisanlink.mongo.repository.BankDetailsRepository;
import com.kisanlink.service.core.GenericSearchRepository;
@Service("BankDetailsManager")
public class BankDetailsManagerImpl implements BankDetailsManager {

	@Autowired BankDetailsRepository bankDetailsrepository;
	@Autowired GenericSearchRepository genericSearchRepository;
	@Override
	public void save(BankDetails bean) throws ServiceException {
		bankDetailsrepository.save(bean);
	}

	@Override
	public void save(List<BankDetails> beans) throws ServiceException {
		bankDetailsrepository.saveAll(beans);
	}

	@Override
	public boolean update(BankDetails bean) throws ServiceException {
		bankDetailsrepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return bankDetailsrepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BankDetails> search(SearchRequest request) {
		return (List<BankDetails>) genericSearchRepository.search(request, BankDetails.class);
	}

	@Override
	public BankDetails findByAccountNumber(String accountNumber) {
		return bankDetailsrepository.findByAccountNumber(accountNumber);
	}

	@Override
	public Optional<BankDetails> findById(String bankId) {
		return bankDetailsrepository.findById(bankId);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return genericSearchRepository.searchCount(request, BankDetails.class);
	}

	@Override
	public BankDetails findByUserId(String id) {
		return bankDetailsrepository.findByUserId(id);
	}
}