package com.kisanlink.mongo.manager.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Variants;
import com.kisanlink.mongo.manager.VariantsManager;
import com.kisanlink.mongo.repository.VariantsRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("variantsManager")
public class VariantsManagerImpl implements VariantsManager{
	
	@Autowired VariantsRepository variantsRepository;
	@Autowired GenericSearchRepository searchRepository;

	@Override
	public void save(Variants bean) throws ServiceException {
		variantsRepository.save(bean);
	}

	@Override
	public void save(List<Variants> beans) throws ServiceException {
		variantsRepository.saveAll(beans);
	}

	@Override
	public boolean update(Variants bean) throws ServiceException {
		variantsRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return variantsRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Variants> search(SearchRequest request) {
		return (List<Variants>) searchRepository.search(request, Variants.class);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return searchRepository.searchCount(request, Variants.class);
	}

	@Override
	public List<Variants> findAll() {
		return variantsRepository.findAll();
	}

	@Override
	public Variants findById(String variantId) {
		
		Optional<Variants> s = variantsRepository.findById(variantId);
		Variants vs = null;
		if(s.isPresent()) {
			vs = s.get();
		}
		return vs;
	}
}
