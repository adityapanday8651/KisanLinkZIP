package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.PersonalDetails;
import com.kisanlink.service.core.AbstractService;

public interface PersonalDetailsManager extends AbstractService<PersonalDetails>{
	List<PersonalDetails> findAll();
	PersonalDetails findByUserId(String userId);
}
