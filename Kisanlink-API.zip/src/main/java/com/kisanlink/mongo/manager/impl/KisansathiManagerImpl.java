package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Kisansathi;
import com.kisanlink.mongo.manager.KisansathiManager;
import com.kisanlink.mongo.repository.KisansathiRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("KisansathiManager")
public class KisansathiManagerImpl implements KisansathiManager {
    @Autowired KisansathiRepository kisansathiRepository;
    @Autowired GenericSearchRepository genericSearchRepository;
	@Override
	public void save(Kisansathi bean) throws ServiceException {
		kisansathiRepository.save(bean);
	}

	@Override
	public void save(List<Kisansathi> beans) throws ServiceException {
		kisansathiRepository.saveAll(beans);
	}

	@Override
	public boolean update(Kisansathi bean) throws ServiceException {
		kisansathiRepository.save(bean);
 		return true;
	}

	@Override
	public long getCount() throws ServiceException {
 		return kisansathiRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Kisansathi> search(SearchRequest request) {
 		return (List<Kisansathi>) genericSearchRepository.search(request, Kisansathi.class );
	}
	@Override
	public long searchCount(SearchRequest request) {
 		return genericSearchRepository.searchCount(request, Kisansathi.class );
	}

	@Override
	public Kisansathi findByid(String id) {
 		return kisansathiRepository.findByid(id);
	}

}
