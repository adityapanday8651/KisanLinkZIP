package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.SoilTesting;
import com.kisanlink.mongo.manager.SoilTestingManager;
import com.kisanlink.mongo.repository.SoilTestingRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("SoilTestingManager")
public class SoilTestingManagerImpl implements SoilTestingManager{
	@Autowired SoilTestingRepository soilTestingRepository;
	@Autowired GenericSearchRepository searchRepository;

	@Override
	public void save(SoilTesting bean) throws ServiceException {
		soilTestingRepository.save(bean);
	}

	@Override
	public void save(List<SoilTesting> beans) throws ServiceException {
		soilTestingRepository.saveAll(beans);
	}

	@Override
	public boolean update(SoilTesting bean) throws ServiceException {
		soilTestingRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return soilTestingRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SoilTesting> search(SearchRequest request) {
		return (List<SoilTesting>) searchRepository.search(request, SoilTesting.class);
	}

	@Override
	public List<SoilTesting> findAll() {
		return soilTestingRepository.findAll();
	}

	@Override
	public SoilTesting findByid(String id) {
		return soilTestingRepository.findByid(id);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return searchRepository.searchCount(request, SoilTesting.class);
	}

	@Override
	public void deleteById(String id) {
		soilTestingRepository.deleteById(id);
	}

}
