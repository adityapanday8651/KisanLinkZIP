package com.kisanlink.mongo.manager;

import com.kisanlink.mongo.User;
import com.kisanlink.service.core.AbstractService;

public interface UserManager extends AbstractService<User>{

	User findByMobileNumber(long mobileNumber);
	void deleteByUserId(String id);
	User findByKisanSathiId(int kisanSathiId);

}