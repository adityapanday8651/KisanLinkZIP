package com.kisanlink.mongo.manager.impl;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Orders;
import com.kisanlink.mongo.manager.OrdersManager;
import com.kisanlink.mongo.repository.OrdersRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("OrdersManager")
public class OrdersManagerImpl implements OrdersManager{
	
	@Autowired OrdersRepository ordersRepository;
	@Autowired GenericSearchRepository searchRepository;

	@Override
	public void save(Orders bean) throws ServiceException {
		ordersRepository.save(bean);
	}

	@Override
	public void save(List<Orders> beans) throws ServiceException {
		ordersRepository.saveAll(beans);
	}

	@Override
	public boolean update(Orders bean) throws ServiceException {
		ordersRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return ordersRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Orders> search(SearchRequest request) {
		return (List<Orders>) searchRepository.search(request, Orders.class);
	}

	@Override
	public List<Orders> findAll() {
		return ordersRepository.findAll();
	}

	@Override
	public long searchCount(SearchRequest request) {
 		return searchRepository.searchCount(request, Orders.class);
	}

	@Override
	public Orders findByOrderId(int orderId) {
		return ordersRepository.findByOrderId(orderId);
	}
}
