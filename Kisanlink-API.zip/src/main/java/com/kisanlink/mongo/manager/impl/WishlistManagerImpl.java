package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.WishList;
import com.kisanlink.mongo.manager.WishListManager;
import com.kisanlink.mongo.repository.WishListRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("WishListManager")
public class WishlistManagerImpl implements WishListManager{
	
	@Autowired WishListRepository wishListRepository;
	@Autowired GenericSearchRepository searchRepository;
	
	
	@Override
	public void save(WishList bean) throws ServiceException {
		wishListRepository.save(bean);
	}

	@Override
	public void save(List<WishList> beans) throws ServiceException {
		wishListRepository.saveAll(beans);
	}

	@Override
	public boolean update(WishList bean) throws ServiceException {
		wishListRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return wishListRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<WishList> search(SearchRequest request) {
		return (List<WishList>) searchRepository.search(request, WishList.class);
	}

	@Override
	public List<WishList> findAll() {
		return wishListRepository.findAll();
	}

	@Override
	public WishList findByFarmerId(String farmerId) {
		return wishListRepository.findByFarmerId(farmerId);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return 0;
	}

}
