package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.RewardsHistory;
import com.kisanlink.service.core.AbstractService;

public interface RewardsHistoryManager extends AbstractService<RewardsHistory>{
	List<RewardsHistory> findAll();

	RewardsHistory findByName(String name);
}
