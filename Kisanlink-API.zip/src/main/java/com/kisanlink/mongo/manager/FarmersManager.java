package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.Farmers;
import com.kisanlink.service.core.AbstractService;

public interface FarmersManager extends AbstractService<Farmers>{
	List<Farmers> findAll();
	Farmers findByMobileNumber(long farmerId);
	void deleteById(String id);
	Farmers findByFarmerId(int farmerId);
}
