package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.References;
import com.kisanlink.mongo.manager.ReferencesManager;
import com.kisanlink.mongo.repository.ReferencesRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("ReferencesManager")
public class ReferencesManagerIml implements ReferencesManager {
	@Autowired ReferencesRepository referencesRepository;
	@Autowired GenericSearchRepository genericSearchRepository;
	@Override
	public void save(References bean) throws ServiceException {
		referencesRepository.save(bean);
	}

	@Override
	public void save(List<References> beans) throws ServiceException {
		referencesRepository.saveAll(beans);
	}

	@Override
	public boolean update(References bean) throws ServiceException {
		referencesRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return referencesRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<References> search(SearchRequest request) {
		return (List<References>) genericSearchRepository.search(request, References.class);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return genericSearchRepository.searchCount(request, References.class);
	}

	@Override
	public References findByid(String id) {
		return referencesRepository.findByid(id);
	}

}
