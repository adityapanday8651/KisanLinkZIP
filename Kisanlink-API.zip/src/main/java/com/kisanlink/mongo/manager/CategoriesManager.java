package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.Categories;
import com.kisanlink.service.core.AbstractService;

public interface CategoriesManager extends AbstractService<Categories>{
	List<Categories> findAll();

	Categories findByCategoryId(int categoryId);
	void deleteById(String id);
}
