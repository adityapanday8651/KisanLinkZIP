package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.FarmsIncentive;
import com.kisanlink.service.core.AbstractService;

public interface FarmsIncentiveManager extends AbstractService<FarmsIncentive>{
	List<FarmsIncentive> findAll();

	FarmsIncentive findByFarmerName(String farmerName);

	String findByFarmerType(String farmerType);
}
