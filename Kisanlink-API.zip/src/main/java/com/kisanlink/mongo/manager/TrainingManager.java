package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.Training;
import com.kisanlink.service.core.AbstractService;

public interface TrainingManager extends AbstractService<Training>{
	List<Training> findAll();

	Training findByFarmerId(String farmerId);
}
