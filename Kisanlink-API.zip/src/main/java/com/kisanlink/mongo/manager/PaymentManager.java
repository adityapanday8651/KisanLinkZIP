package com.kisanlink.mongo.manager;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Payment;
import com.kisanlink.service.core.AbstractService;
public interface PaymentManager extends AbstractService<Payment> {
	public Payment findByid(String id);
	public long searchCount(SearchRequest request);
}
