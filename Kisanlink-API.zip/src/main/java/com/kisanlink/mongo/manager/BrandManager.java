package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.Brand;
import com.kisanlink.service.core.AbstractService;

public interface BrandManager extends AbstractService<Brand>{
	List<Brand> findAll();

	Brand findByName(String name);
	void deleteById(String id);

}
