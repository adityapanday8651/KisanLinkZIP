package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.WishList;
import com.kisanlink.service.core.AbstractService;

public interface WishListManager extends AbstractService<WishList>{
	List<WishList> findAll();

	WishList findByFarmerId(String farmerId);
}
