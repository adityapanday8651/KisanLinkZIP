package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.LoginHistory;
import com.kisanlink.mongo.manager.LoginHistoryManager;
import com.kisanlink.mongo.repository.LoginHistoryRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("LoginHistoryManager")
public class LoginHistoryManagerImpl implements LoginHistoryManager {
	
	@Autowired LoginHistoryRepository repository;
	@Autowired GenericSearchRepository searchRepo;

	@Override
	public void save(LoginHistory bean) throws ServiceException {
		repository.save(bean);
	}

	@Override
	public void save(List<LoginHistory> beans) throws ServiceException {
		repository.saveAll(beans);
	}

	@Override
	public boolean update(LoginHistory bean) throws ServiceException {
		repository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return repository.count();
	}

	@Override
	public long searchCount(SearchRequest request) {
		return searchRepo.searchCount(request, LoginHistory.class);
	}

	@Override
	public List<LoginHistory> findByUserId(String userId) {
		return repository.findByUserId(userId);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<LoginHistory> search(SearchRequest request) {
 		return (List<LoginHistory>) searchRepo.search(request, LoginHistory.class);
	}	
	
}