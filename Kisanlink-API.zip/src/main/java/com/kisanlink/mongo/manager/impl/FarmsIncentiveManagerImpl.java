package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.FarmsIncentive;
import com.kisanlink.mongo.manager.FarmsIncentiveManager;
import com.kisanlink.mongo.repository.FarmsIncentiveRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("FarmsIncentiveManager")
public class FarmsIncentiveManagerImpl implements FarmsIncentiveManager{
	@Autowired FarmsIncentiveRepository farmsIncentiveRepository;
	@Autowired GenericSearchRepository searchRepository;

	@Override
	public void save(FarmsIncentive bean) throws ServiceException {
		farmsIncentiveRepository.save(bean);	
	}

	@Override
	public void save(List<FarmsIncentive> beans) throws ServiceException {
		farmsIncentiveRepository.saveAll(beans);
	}

	@Override
	public boolean update(FarmsIncentive bean) throws ServiceException {
		farmsIncentiveRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return farmsIncentiveRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<FarmsIncentive> search(SearchRequest request) {
		return (List<FarmsIncentive>) searchRepository.search(request, FarmsIncentive.class);
	}

	@Override
	public List<FarmsIncentive> findAll() {
		return farmsIncentiveRepository.findAll();
	}

	@Override
	public FarmsIncentive findByFarmerName(String farmerName) {
		return farmsIncentiveRepository.findByFarmerName(farmerName);
	}

	@Override
	public String findByFarmerType(String farmerType) {
		return farmsIncentiveRepository.findByFarmerType(farmerType);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return 0;
	}

}
