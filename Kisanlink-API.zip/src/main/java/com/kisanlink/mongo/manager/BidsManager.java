package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.Bids;
import com.kisanlink.service.core.AbstractService;

public interface BidsManager extends AbstractService<Bids>{
	List<Bids> findAll();

	Bids findByProductName(String productName);
}
