package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.MyContact;
import com.kisanlink.service.core.AbstractService;

public interface MyContactManager extends AbstractService<MyContact>{
	List<MyContact> findAll();

	MyContact findByMobileNumber(String mobileNumber);
}
