package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Insurance;
import com.kisanlink.mongo.manager.InsuranceManager;
import com.kisanlink.mongo.repository.InsuranceRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("InsuranceManager")
public class InsuranceManagerImpl implements InsuranceManager {
    @Autowired InsuranceRepository insuranceRepository;
    @Autowired GenericSearchRepository genericSearchRepository;
	@Override
	public void save(Insurance bean) throws ServiceException {
		insuranceRepository.save(bean);
	}

	@Override
	public void save(List<Insurance> beans) throws ServiceException {
		insuranceRepository.saveAll(beans);
	}

	@Override
	public boolean update(Insurance bean) throws ServiceException {
		insuranceRepository.save(bean);
 		return true;
	}

	@Override
	public long getCount() throws ServiceException {
 		return insuranceRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Insurance> search(SearchRequest request) {
 		return (List<Insurance>) genericSearchRepository.search(request, Insurance.class);
	}
	@Override
	public long searchCount(SearchRequest request) {
 		return   genericSearchRepository.searchCount(request, Insurance.class);
	}

	@Override
	public Insurance findByid(String id) {
 		return insuranceRepository.findByid(id);
	}

}
