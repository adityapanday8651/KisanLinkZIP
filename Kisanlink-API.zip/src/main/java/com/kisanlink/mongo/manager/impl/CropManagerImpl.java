package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Crop;
import com.kisanlink.mongo.manager.CropManager;
import com.kisanlink.mongo.repository.CropRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("CropManager")
public class CropManagerImpl implements CropManager{

	@Autowired CropRepository cropRepository;
	@Autowired GenericSearchRepository searchRepository;
	
	@Override
	public void save(Crop bean) throws ServiceException {
		cropRepository.save(bean);
	}

	@Override
	public void save(List<Crop> beans) throws ServiceException {
		cropRepository.saveAll(beans);
	}

	@Override
	public boolean update(Crop bean) throws ServiceException {
		cropRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return cropRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Crop> search(SearchRequest request) {
		return (List<Crop>) searchRepository.search(request, Crop.class);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return searchRepository.searchCount(request, Crop.class);
	}

	@Override
	public List<Crop> findAll() {
		return cropRepository.findAll();
	}

	@Override
	public Crop findByCropId(int cropId) {
		return cropRepository.findByCropId(cropId);
	}

	@Override
	public void deleteByCropId(int cropId) {
		cropRepository.deleteByCropId(cropId);
	}	
}
