package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.ServiceProvider;
import com.kisanlink.service.core.AbstractService;

public interface ServiceProviderManager extends AbstractService<ServiceProvider>{
	List<ServiceProvider> findAll();

	ServiceProvider findByFarmerId(String farmerId);
}
