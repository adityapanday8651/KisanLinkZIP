package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Courses;
import com.kisanlink.mongo.manager.CoursesManager;
import com.kisanlink.mongo.repository.CoursesRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("CoursesManager")
public class CoursesManagerImpl implements CoursesManager{
	
	@Autowired CoursesRepository coursesRepository;
	@Autowired GenericSearchRepository searchRepository;

	@Override
	public void save(Courses bean) throws ServiceException {
		coursesRepository.save(bean);
	}

	@Override
	public void save(List<Courses> beans) throws ServiceException {
		coursesRepository.saveAll(beans);
	}

	@Override
	public boolean update(Courses bean) throws ServiceException {
		coursesRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return coursesRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Courses> search(SearchRequest request) {
		return (List<Courses>) searchRepository.search(request, Courses.class);
	}

	@Override
	public List<Courses> findAll() {
		return coursesRepository.findAll();
	}

	@Override
	public Courses findByCourseId(String courseId) {
		return coursesRepository.findByCourseId(courseId);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return 0;
	}

}
