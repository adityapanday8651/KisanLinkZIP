package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.Variants;
import com.kisanlink.service.core.AbstractService;

public interface VariantsManager extends AbstractService<Variants>{
	List<Variants> findAll();
	Variants findById(String variantId);
}
