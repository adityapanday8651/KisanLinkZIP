package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Dashboard;
import com.kisanlink.mongo.manager.DashboardManager;
import com.kisanlink.mongo.repository.DashboardRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("DashboardManager")
public class DashboardManagerImpl implements DashboardManager {
    @Autowired DashboardRepository dashboardRepository;
    @Autowired GenericSearchRepository genericSearchRepository;
	@Override
	public void save(Dashboard bean) throws ServiceException {
		dashboardRepository.save(bean);		
	}

	@Override
	public void save(List<Dashboard> beans) throws ServiceException {
		dashboardRepository.saveAll(beans);		
	}

	@Override
	public boolean update(Dashboard bean) throws ServiceException {
		dashboardRepository.save(bean);
 		return true;
	}

	@Override
	public long getCount() throws ServiceException {
 		return dashboardRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Dashboard> search(SearchRequest request) {
 		return (List<Dashboard>) genericSearchRepository.search(request, Dashboard.class);
	}
	
	public long searchCount(SearchRequest request) {
 		return  genericSearchRepository.searchCount(request, Dashboard.class);
	}

	@Override
	public Dashboard findByid(String id) {
 		return dashboardRepository.findByid(id);
	}

	@Override
	public Dashboard findOne() {
		List<Dashboard> s = dashboardRepository.findAll();
		if(!s.isEmpty()) {
			return s.get(0);
		}else {
			return null;
		}
		//return (s != null?s.get(0):null);
	}

}
