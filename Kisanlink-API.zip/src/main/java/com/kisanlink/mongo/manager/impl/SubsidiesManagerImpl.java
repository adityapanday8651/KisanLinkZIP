package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Subsidies;
import com.kisanlink.mongo.manager.SubsidiesManager;
import com.kisanlink.mongo.repository.SubsidiesRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("SubsidiesManager")
public class SubsidiesManagerImpl implements SubsidiesManager {
    @Autowired SubsidiesRepository subsidiesRepository;
    @Autowired GenericSearchRepository genericSearchRepository;
	@Override
	public void save(Subsidies bean) throws ServiceException {
		subsidiesRepository.save(bean);	
	}

	@Override
	public void save(List<Subsidies> beans) throws ServiceException {
		subsidiesRepository.saveAll(beans);		
	}

	@Override
	public boolean update(Subsidies bean) throws ServiceException {
		subsidiesRepository.save(bean);
 		return true;
	}

	@Override
	public long getCount() throws ServiceException {
 		return subsidiesRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Subsidies> search(SearchRequest request) {
 		return (List<Subsidies>) genericSearchRepository.search(request,Subsidies.class);
	}

	@Override
	public Subsidies findByid(String id) {
 		return subsidiesRepository.findByid(id);
	}

	@Override
	public long searchCount(SearchRequest request) {
 		return genericSearchRepository.searchCount(request,Subsidies.class);
	}

}
