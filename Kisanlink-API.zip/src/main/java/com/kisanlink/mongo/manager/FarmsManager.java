package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.Farms;
import com.kisanlink.service.core.AbstractService;

public interface FarmsManager extends AbstractService<Farms>{
	List<Farms> findAll();
	Farms findById(String farmerId);
	
}
