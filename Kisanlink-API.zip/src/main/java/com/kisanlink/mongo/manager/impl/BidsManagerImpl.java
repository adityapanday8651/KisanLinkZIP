package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Bids;
import com.kisanlink.mongo.manager.BidsManager;
import com.kisanlink.mongo.repository.BidsRepository;

@Service("BidsManager")
public class BidsManagerImpl implements BidsManager{
	
	@Autowired BidsRepository bidsRepository;

	@Override
	public void save(Bids bean) throws ServiceException {
		bidsRepository.save(bean);
	}

	@Override
	public void save(List<Bids> beans) throws ServiceException {
		bidsRepository.saveAll(beans);
	}

	@Override
	public boolean update(Bids bean) throws ServiceException {
		bidsRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return bidsRepository.count();
	}

	@Override
	public List<Bids> search(SearchRequest request) {
		return null;
	}

	@Override
	public List<Bids> findAll() {
		return bidsRepository.findAll();
	}

	@Override
	public Bids findByProductName(String productName) {
		return bidsRepository.findByProductName(productName);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return 0;
	}

}
