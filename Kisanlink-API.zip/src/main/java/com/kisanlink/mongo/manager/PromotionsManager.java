package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.Promotions;
import com.kisanlink.service.core.AbstractService;

public interface PromotionsManager extends AbstractService<Promotions>{
	List<Promotions> findAll();

	Promotions findByCampaignId(String campaignId);
}
