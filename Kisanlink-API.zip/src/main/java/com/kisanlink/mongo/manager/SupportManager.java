package com.kisanlink.mongo.manager;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Support;
import com.kisanlink.service.core.AbstractService;

public interface SupportManager extends AbstractService<Support> {
	long searchCount(SearchRequest request);

	Support findBySupportId(String supportId);
}
