package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.Carts;
import com.kisanlink.service.core.AbstractService;

public interface CartsManager extends AbstractService<Carts>{
	List<Carts> findAll();

	Carts findByCategoryId(String categoryId);

}
