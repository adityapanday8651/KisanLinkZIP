package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.MostSelling;
import com.kisanlink.service.core.AbstractService;

public interface MostSellingManager extends AbstractService<MostSelling>{
	List<MostSelling> findAll();

	MostSelling findByProductName(String productName);
}
