package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.FavouriteFarmers;
import com.kisanlink.mongo.manager.FavouriteFarmersManager;
import com.kisanlink.mongo.repository.FavouriteFarmersRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("FavouriteFarmersManager")
public class FavouriteFarmersManagerImpl implements FavouriteFarmersManager{
	@Autowired FavouriteFarmersRepository favouriteFarmersRepository;
	@Autowired GenericSearchRepository searchRepository;

	@Override
	public void save(FavouriteFarmers bean) throws ServiceException {
		favouriteFarmersRepository.save(bean);
	}

	@Override
	public void save(List<FavouriteFarmers> beans) throws ServiceException {
		favouriteFarmersRepository.saveAll(beans);
	}

	@Override
	public boolean update(FavouriteFarmers bean) throws ServiceException {
		favouriteFarmersRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return favouriteFarmersRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<FavouriteFarmers> search(SearchRequest request) {
		return (List<FavouriteFarmers>) searchRepository.search(request, FavouriteFarmers.class);
	}

	@Override
	public List<FavouriteFarmers> findAll() {
		return favouriteFarmersRepository.findAll();
	}

	@Override
	public FavouriteFarmers findByFarmerName(String farmerName) {
		return favouriteFarmersRepository.findByFarmerName(farmerName);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return searchRepository.searchCount(request, FavouriteFarmers.class);
	}

	@Override
	public FavouriteFarmers findByFarmerId(int farmerId) {
		return favouriteFarmersRepository.findByFarmerId(farmerId);
	}
}
