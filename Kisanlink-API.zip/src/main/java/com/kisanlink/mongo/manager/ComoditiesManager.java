package com.kisanlink.mongo.manager;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Comodities;
import com.kisanlink.service.core.AbstractService;

public interface ComoditiesManager extends AbstractService<Comodities> {
	Comodities findByid(String id);
	long searchCount(SearchRequest request);
	void deleteById(String id);
}
