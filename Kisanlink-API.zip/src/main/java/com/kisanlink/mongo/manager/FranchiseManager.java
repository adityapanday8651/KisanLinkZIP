package com.kisanlink.mongo.manager;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.FranchiseCentres;
import com.kisanlink.service.core.AbstractService;

public interface FranchiseManager extends AbstractService<FranchiseCentres> {

	FranchiseCentres findByid(String id);

	long searchCount(SearchRequest request);

}
