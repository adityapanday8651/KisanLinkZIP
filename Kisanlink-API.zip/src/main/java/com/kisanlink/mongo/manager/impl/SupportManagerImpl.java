package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Support;
import com.kisanlink.mongo.manager.SupportManager;
import com.kisanlink.mongo.repository.SupportRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("SupportManager")
public class SupportManagerImpl implements SupportManager{
	@Autowired  SupportRepository supportReposiory;
	@Autowired  GenericSearchRepository genericSearchRepository;
	
	public void save(Support bean) throws ServiceException {
		supportReposiory.save(bean);

	}

	@Override
	public void save(List<Support> beans) throws ServiceException {
		supportReposiory.saveAll(beans);
	}

	@Override
	public boolean update(Support bean) throws ServiceException {
		supportReposiory.save(bean);
 		return true;
	}

	@Override
	public long getCount() throws ServiceException {
 		return supportReposiory.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Support> search(SearchRequest request) {
 		return (List<Support>) genericSearchRepository.search(request, Support.class);
	}
	@Override
	public long searchCount(SearchRequest request) {
 		return genericSearchRepository.searchCount(request, Support.class);
	}

	@Override
	public Support findBySupportId(String supportId) {
 		return supportReposiory.findBySupportId(supportId);
	}

}
