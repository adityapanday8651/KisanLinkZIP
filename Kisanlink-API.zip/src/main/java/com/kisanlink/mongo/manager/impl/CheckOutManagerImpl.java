package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.CheckOut;
import com.kisanlink.mongo.manager.CheckOutManager;
import com.kisanlink.mongo.repository.CheckOutRepository;

@Service("CheckOutManager")
public class CheckOutManagerImpl implements CheckOutManager{
	
	@Autowired CheckOutRepository checkOutRepository;

	@Override
	public void save(CheckOut bean) throws ServiceException {
		checkOutRepository.save(bean);
	}

	@Override
	public void save(List<CheckOut> beans) throws ServiceException {
		checkOutRepository.saveAll(beans);
	}

	@Override
	public boolean update(CheckOut bean) throws ServiceException {
		checkOutRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return checkOutRepository.count();
	}

	@Override
	public List<CheckOut> search(SearchRequest request) {
		return null;
	}

	@Override
	public List<CheckOut> findAll() {
		return checkOutRepository.findAll();
	}

	@Override
	public CheckOut findByFarmerId(String farmerId) {

		return checkOutRepository.findByFarmerId(farmerId);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return 0;
	}

}
