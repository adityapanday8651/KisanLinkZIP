package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.SoilTesting;
import com.kisanlink.service.core.AbstractService;

public interface SoilTestingManager extends AbstractService<SoilTesting>{
	List<SoilTesting> findAll();

	SoilTesting findByid(String id);

	void deleteById(String id);
}
