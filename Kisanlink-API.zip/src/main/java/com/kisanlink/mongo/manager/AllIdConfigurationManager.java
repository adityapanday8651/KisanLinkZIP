package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.AllIdConfiguration;
import com.kisanlink.service.core.AbstractService;

public interface AllIdConfigurationManager extends AbstractService<AllIdConfiguration>{
	List<AllIdConfiguration> findAll();
	AllIdConfiguration findByName(String name);
}
