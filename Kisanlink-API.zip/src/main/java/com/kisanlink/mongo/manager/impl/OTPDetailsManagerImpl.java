package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.OTPDetails;
import com.kisanlink.mongo.manager.OTPDetailsManager;
import com.kisanlink.mongo.repository.OTPDetailsRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("OTPDetailsManager")
public class OTPDetailsManagerImpl implements OTPDetailsManager {

	@Autowired private OTPDetailsRepository repository;
	@Autowired GenericSearchRepository searchRepository;

	@Override
	public void save(OTPDetails bean) throws ServiceException {
		repository.save(bean);
		
	}

	@Override
	public void save(List<OTPDetails> beans) throws ServiceException {
		repository.saveAll(beans);
		
	}

	@Override
	public boolean update(OTPDetails bean) throws ServiceException {
		repository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return repository.count();
	}

	@Override
	public long searchCount(SearchRequest request) {
		return searchRepository.searchCount(request, OTPDetails.class);
	}

	@Override
	public OTPDetails findByMobileNumber(long phoneNumber) {
		return repository.findByMobileNumber(phoneNumber);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<OTPDetails> search(SearchRequest request) {
 		return (List<OTPDetails>) searchRepository.search(request, OTPDetails.class);
	}

}
