package com.kisanlink.mongo.manager;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.NodalCentres;
import com.kisanlink.service.core.AbstractService;

public interface NodalCentresManager extends AbstractService<NodalCentres> {

	NodalCentres findByid(String id);

	long searchCount(SearchRequest request);

}
