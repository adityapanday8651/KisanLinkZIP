package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Drone;
import com.kisanlink.service.core.AbstractService;

public interface DroneManager extends AbstractService<Drone> {
	long searchCount(SearchRequest request);
	public Drone findByid(String id);
	List<Drone> findAll();
} 
