package com.kisanlink.mongo.manager.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Goals;
import com.kisanlink.mongo.manager.GoalsManager;
import com.kisanlink.mongo.repository.GoalsRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("GoalsManager")
public class GoalsManagerImpl implements GoalsManager {
	@Autowired GoalsRepository goalsRepository;
	@Autowired GenericSearchRepository genericSearchRepository;
	@Override
	public void save(Goals bean) throws ServiceException {
		goalsRepository.save(bean);

	}

	@Override
	public void save(List<Goals> beans) throws ServiceException {
		goalsRepository.saveAll(beans);
	}

	@Override
	public boolean update(Goals bean) throws ServiceException {
		goalsRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return goalsRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Goals> search(SearchRequest request) {
		return (List<Goals>) genericSearchRepository.search(request, Goals.class);
	}
	@Override
	public long searchCount(SearchRequest request) {
		return genericSearchRepository.searchCount(request, Goals.class);
	}

	@Override
	public Optional<Goals> findById(String goalId) {
		return goalsRepository.findById(goalId);
	}


}
