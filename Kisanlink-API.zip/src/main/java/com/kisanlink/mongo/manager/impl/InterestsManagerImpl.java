package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Interests;
import com.kisanlink.mongo.manager.InterestsManager;
import com.kisanlink.mongo.repository.InterestsRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("InterestsManager")
public class InterestsManagerImpl implements InterestsManager{
	
	@Autowired InterestsRepository interestsRepository;
	@Autowired GenericSearchRepository searchRepository;
	
	@Override
	public void save(Interests bean) throws ServiceException {
		interestsRepository.save(bean);
	}

	@Override
	public void save(List<Interests> beans) throws ServiceException {
		interestsRepository.saveAll(beans);
	}

	@Override
	public boolean update(Interests bean) throws ServiceException {
		interestsRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return interestsRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Interests> search(SearchRequest request) {
		return (List<Interests>) searchRepository.search(request, Interests.class);
	}

	@Override
	public List<Interests> findAll() {
		return interestsRepository.findAll();
	}

	@Override
	public Interests findByInterestId(String interestId) {
		return interestsRepository.findByInterestId(interestId);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return 0;
	}
}
