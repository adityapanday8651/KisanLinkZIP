package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Loan;
import com.kisanlink.mongo.manager.LoanManager;
import com.kisanlink.mongo.repository.LoanRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("LoanManager")
public class LoanManagerImpl implements LoanManager{
	@Autowired LoanRepository loanRepository;
	@Autowired GenericSearchRepository searchRepository;

	@Override
	public void save(Loan bean) throws ServiceException {
		loanRepository.save(bean);
	}

	@Override
	public void save(List<Loan> beans) throws ServiceException {
		loanRepository.saveAll(beans);
	}

	@Override
	public boolean update(Loan bean) throws ServiceException {
		loanRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return loanRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Loan> search(SearchRequest request) {
		return (List<Loan>) searchRepository.search(request, Loan.class);
	}

	@Override
	public List<Loan> findAll() {
		return loanRepository.findAll();
	}

	@Override
	public Loan findByFarmerId(String farmerId) {
		return loanRepository.findByFarmerId(farmerId);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return 0;
	}

}
