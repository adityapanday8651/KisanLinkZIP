package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.FarmersConfiguration;
import com.kisanlink.mongo.manager.FarmersConfigurationManager;
import com.kisanlink.mongo.repository.FarmersConfigurationRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("FarmersConfigurationManager")
public class FarmersConfigurationManagerImpl implements FarmersConfigurationManager{
	
	@Autowired FarmersConfigurationRepository farmersConfigurationRepository;
	@Autowired GenericSearchRepository searchRepository;
	
	@Override
	public void save(FarmersConfiguration bean) throws ServiceException {
		farmersConfigurationRepository.save(bean);
	}

	@Override
	public void save(List<FarmersConfiguration> beans) throws ServiceException {
		farmersConfigurationRepository.saveAll(beans);
	}

	@Override
	public boolean update(FarmersConfiguration bean) throws ServiceException {
		
		farmersConfigurationRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return farmersConfigurationRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<FarmersConfiguration> search(SearchRequest request) {
		return (List<FarmersConfiguration>) searchRepository.search(request, FarmersConfiguration.class);
	}

	@Override
	public List<FarmersConfiguration> findAll() {
		return farmersConfigurationRepository.findAll();
	}

	@Override
	public FarmersConfiguration findByFarmerId(int farmerId) {
		return farmersConfigurationRepository.findByFarmerId(farmerId);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return 0;
	}

}
