package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Brand;
import com.kisanlink.mongo.manager.BrandManager;
import com.kisanlink.mongo.repository.BrandRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("BrandManager")
public class BrandManagerImpl implements BrandManager{
	
	@Autowired BrandRepository brandRepository;
	@Autowired GenericSearchRepository searchRepository;
	
	@Override
	public void save(Brand bean) throws ServiceException {
		brandRepository.save(bean);
	}

	@Override
	public void save(List<Brand> beans) throws ServiceException {
		brandRepository.saveAll(beans);
	}

	@Override
	public boolean update(Brand bean) throws ServiceException {
		brandRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return brandRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Brand> search(SearchRequest request) {
		return (List<Brand>) searchRepository.search(request, Brand.class);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return searchRepository.searchCount(request, Brand.class);
	}

	@Override
	public List<Brand> findAll() {
		return brandRepository.findAll();
	}

	@Override
	public Brand findByName(String name) {
		return brandRepository.findByName(name);
	}
	
	@Override
	public void deleteById(String id) {
		brandRepository.deleteById(id);
	}
}
