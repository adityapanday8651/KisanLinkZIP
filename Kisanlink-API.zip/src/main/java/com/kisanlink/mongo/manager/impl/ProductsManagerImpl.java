package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Products;
import com.kisanlink.mongo.manager.ProductsManager;
import com.kisanlink.mongo.repository.ProductsRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("ProductsManager")
public class ProductsManagerImpl implements ProductsManager{
	
	@Autowired ProductsRepository productsRepository;
	@Autowired GenericSearchRepository searchRepository;

	@Override
	public void save(Products bean) throws ServiceException {
		productsRepository.save(bean);
		
	}

	@Override
	public void save(List<Products> beans) throws ServiceException {
		productsRepository.saveAll(beans);
	}

	@Override
	public boolean update(Products bean) throws ServiceException {
		productsRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return productsRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Products> search(SearchRequest request) {
		return (List<Products>) searchRepository.search(request,Products.class);
	}

	@Override
	public List<Products> findAll() {
		return productsRepository.findAll();
	}

	@Override
	public long searchCount(SearchRequest request) {
		return searchRepository.searchCount(request, Products.class);
	}

	@Override
	public Products findByProductId(int productId) {
		return productsRepository.findByProductId(productId);
	}

	@Override
	public void findById(String id) {
		productsRepository.deleteById(id);
	}
}
