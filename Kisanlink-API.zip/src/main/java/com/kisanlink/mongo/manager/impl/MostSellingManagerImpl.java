package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.MostSelling;
import com.kisanlink.mongo.manager.MostSellingManager;
import com.kisanlink.mongo.repository.MostSellingRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("MostSellingManager")
public class MostSellingManagerImpl implements MostSellingManager{
	@Autowired MostSellingRepository mostSellingRepository;
	@Autowired GenericSearchRepository searchRepository;

	@Override
	public void save(MostSelling bean) throws ServiceException {
		mostSellingRepository.save(bean);
	}

	@Override
	public void save(List<MostSelling> beans) throws ServiceException {
		mostSellingRepository.saveAll(beans);
	}

	@Override
	public boolean update(MostSelling bean) throws ServiceException {
		mostSellingRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return mostSellingRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<MostSelling> search(SearchRequest request) {
		return (List<MostSelling>) searchRepository.search(request, MostSelling.class);
	}

	@Override
	public List<MostSelling> findAll() {
		return mostSellingRepository.findAll();
	}

	@Override
	public MostSelling findByProductName(String productName) {
		return mostSellingRepository.findByProductName(productName);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return searchRepository.searchCount(request, MostSelling.class);
	}

}
