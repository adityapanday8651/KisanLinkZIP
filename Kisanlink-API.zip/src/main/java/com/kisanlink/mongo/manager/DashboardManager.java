package com.kisanlink.mongo.manager;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Dashboard;
import com.kisanlink.service.core.AbstractService;

public interface DashboardManager extends AbstractService<Dashboard> {
	 long searchCount(SearchRequest request);
	 public Dashboard findByid(String id);
	 Dashboard findOne();
}
