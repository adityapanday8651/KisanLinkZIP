package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Drone;
import com.kisanlink.mongo.manager.DroneManager;
import com.kisanlink.mongo.repository.DroneRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("DroneManager")
public class DroneManagerImpl implements DroneManager {
	@Autowired DroneRepository droneRepository;
	@Autowired GenericSearchRepository genericSearchRepository;
	@Override
	public void save(Drone bean) throws ServiceException {
		droneRepository.save(bean);
	}

	@Override
	public void save(List<Drone> beans) throws ServiceException {
		droneRepository.saveAll(beans);
	}

	@Override
	public boolean update(Drone bean) throws ServiceException {
		droneRepository.save(bean);
 		return true;
	}

	@Override
	public long getCount() throws ServiceException {
 		return droneRepository.count();
	}

	@CrossOrigin
	@SuppressWarnings("unchecked")
	@Override
	public List<Drone> search(SearchRequest request) {
 		return (List<Drone>) genericSearchRepository.search(request, Drone.class);
	}
	
	@Override
	public long searchCount(SearchRequest request) {
 		return  genericSearchRepository.searchCount(request, Drone.class);
	}

	@Override
	public Drone findByid(String id) {
 		return droneRepository.findByid(id);
	}

	@Override
	public List<Drone> findAll() {
		return droneRepository.findAll();
	}

}
