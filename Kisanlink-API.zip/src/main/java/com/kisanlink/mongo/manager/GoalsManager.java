package com.kisanlink.mongo.manager;

import java.util.Optional;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Goals;
import com.kisanlink.service.core.AbstractService;

public interface GoalsManager extends AbstractService<Goals> {
	long searchCount(SearchRequest request);
	Optional<Goals> findById(String goalId);
}
