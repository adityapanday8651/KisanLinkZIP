package com.kisanlink.mongo.manager;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Collaborator;
import com.kisanlink.service.core.AbstractService;

public interface CollaboratorManager extends AbstractService<Collaborator> {
	public Collaborator findByid(String id);
	public long searchCount(SearchRequest searchRequest);
}