package com.kisanlink.mongo.manager;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Insurance;
import com.kisanlink.service.core.AbstractService;

public interface InsuranceManager extends AbstractService<Insurance> {
	long searchCount(SearchRequest request);
	public Insurance findByid(String id);
}
