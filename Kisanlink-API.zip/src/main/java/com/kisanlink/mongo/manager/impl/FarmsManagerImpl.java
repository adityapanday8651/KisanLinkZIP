package com.kisanlink.mongo.manager.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Farms;
import com.kisanlink.mongo.manager.FarmsManager;
import com.kisanlink.mongo.repository.FarmsRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("FarmsManager")
public class FarmsManagerImpl implements FarmsManager{

	@Autowired FarmsRepository farmsRepository;
	@Autowired GenericSearchRepository searchRepository; 

	@Override
	public void save(Farms bean) throws ServiceException {
		farmsRepository.save(bean);
	}

	@Override
	public void save(List<Farms> beans) throws ServiceException {
		farmsRepository.saveAll(beans);
	}

	@Override
	public boolean update(Farms bean) throws ServiceException {
		farmsRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return farmsRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Farms> search(SearchRequest request) {
		return (List<Farms>) searchRepository.search(request, Farms.class);
	}

	@Override
	public List<Farms> findAll() {
		return farmsRepository.findAll();
	}

	@Override
	public Farms findById(String farmerId) {
		Optional<Farms> s = farmsRepository.findById(farmerId);
		Farms farm = null;
		if(s.isPresent()) {
			farm = s.get();
		}
		return farm;
	}

	@Override
	public long searchCount(SearchRequest request) {
		return 0;
	}

}
