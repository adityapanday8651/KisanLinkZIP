package com.kisanlink.mongo.manager;

import java.util.List;

import com.kisanlink.mongo.Services;

import com.kisanlink.service.core.AbstractService;

public interface ServicesManager extends AbstractService<Services>{

	Services findByFarmerId(String farmerId);

	List<Services> findAll();

}
