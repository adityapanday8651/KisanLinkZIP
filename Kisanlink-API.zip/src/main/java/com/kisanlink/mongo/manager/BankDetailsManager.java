package com.kisanlink.mongo.manager;

import java.util.Optional;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.BankDetails;
import com.kisanlink.service.core.AbstractService;

public interface BankDetailsManager extends AbstractService<BankDetails> {
	public BankDetails findByAccountNumber(String accountNumber);
	public  Optional<BankDetails> findById(String bankId);
	public long searchCount(SearchRequest request);
	public BankDetails findByUserId(String id);
}
