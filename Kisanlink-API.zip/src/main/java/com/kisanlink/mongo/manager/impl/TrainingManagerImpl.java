package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.Training;
import com.kisanlink.mongo.manager.TrainingManager;
import com.kisanlink.mongo.repository.TrainingRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("TrainingManager")
public class TrainingManagerImpl implements TrainingManager{
	@Autowired TrainingRepository trainingRepository;
	@Autowired GenericSearchRepository searchRepository;

	@Override
	public void save(Training bean) throws ServiceException {
		trainingRepository.save(bean);
	}

	@Override
	public void save(List<Training> beans) throws ServiceException {
		trainingRepository.saveAll(beans);
	}

	@Override
	public boolean update(Training bean) throws ServiceException {
		trainingRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return trainingRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Training> search(SearchRequest request) {
		return (List<Training>) searchRepository.search(request, Training.class);
	}

	@Override
	public List<Training> findAll() {
		return trainingRepository.findAll();
	}

	@Override
	public Training findByFarmerId(String farmerId) {
		return trainingRepository.findByFarmerId(farmerId);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return 0;
	}

}
