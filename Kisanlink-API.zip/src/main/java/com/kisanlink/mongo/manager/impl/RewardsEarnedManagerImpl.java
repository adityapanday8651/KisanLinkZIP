package com.kisanlink.mongo.manager.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.mongo.RewardsEarned;
import com.kisanlink.mongo.manager.RewardsEarnedManager;
import com.kisanlink.mongo.repository.RewardsEarnedRepository;
import com.kisanlink.service.core.GenericSearchRepository;

@Service("RewardsEarnedManager")
public class RewardsEarnedManagerImpl implements RewardsEarnedManager{
	
	@Autowired RewardsEarnedRepository rewardsEarnedRepository;
	@Autowired GenericSearchRepository searchRepository;

	@Override
	public void save(RewardsEarned bean) throws ServiceException {
		rewardsEarnedRepository.save(bean);
	}

	@Override
	public void save(List<RewardsEarned> beans) throws ServiceException {
		rewardsEarnedRepository.saveAll(beans);
	}

	@Override
	public boolean update(RewardsEarned bean) throws ServiceException {
		rewardsEarnedRepository.save(bean);
		return true;
	}

	@Override
	public long getCount() throws ServiceException {
		return rewardsEarnedRepository.count();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<RewardsEarned> search(SearchRequest request) {
		return (List<RewardsEarned>) searchRepository.search(request, RewardsEarned.class);
	}

	@Override
	public List<RewardsEarned> findAll() {
		return rewardsEarnedRepository.findAll();
	}

	@Override
	public RewardsEarned findByReferralCode(String referralCode) {
		return rewardsEarnedRepository.findByReferralCode(referralCode);
	}

	@Override
	public long searchCount(SearchRequest request) {
		return 0;
	}

}
