package com.kisanlink.mongo;

public enum ERole {
	  ROLE_USER,
	  ROLE_MODERATOR,
	  ROLE_ADMIN
	}
