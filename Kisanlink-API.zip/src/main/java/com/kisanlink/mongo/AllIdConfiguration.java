package com.kisanlink.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="AllIdConfiguration")
public class AllIdConfiguration extends BaseModel{
	@Id
	private String id;
	private String name;
	private int lastGeneratedId;
	
	public String getId() {
		return id;
	}
	public int getLastGeneratedId() {
		return lastGeneratedId;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setLastGeneratedId(int lastGeneratedId) {
		this.lastGeneratedId = lastGeneratedId;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "AllIdConfiguration [id=" + id + ", name=" + name + ", lastGeneratedId=" + lastGeneratedId + "]";
	}
}
