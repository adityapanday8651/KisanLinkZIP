package com.kisanlink.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Brand")
public class Brand extends BaseModel{
	@Id
	private String id;
	private String logo;
	private String name;
	
	public String getId() {
		return id;
	}
	public String getLogo() {
		return logo;
	}
	public String getName() {
		return name;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Brand [id=" + id + ", logo=" + logo + ", name=" + name + "]";
	}
}
