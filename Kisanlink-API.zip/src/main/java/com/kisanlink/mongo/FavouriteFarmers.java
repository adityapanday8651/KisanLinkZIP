package com.kisanlink.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="FavouriteFarmers")
public class FavouriteFarmers extends BaseModel{
	
	@Id
	private String id;
	private String image;
	private String farmerName;
	private int farmerId;
	private String status;
	private int kisansathiId;
	
	public int getKisansathiId() {
		return kisansathiId;
	}
	public void setKisansathiId(int kisansathiId) {
		this.kisansathiId = kisansathiId;
	}
	public int getFarmerId() {
		return farmerId;
	}
	public void setFarmerId(int farmerId) {
		this.farmerId = farmerId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getId() {
		return id;
	}
	public String getFarmerName() {
		return farmerName;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setFarmerName(String farmerName) {
		this.farmerName = farmerName;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	@Override
	public String toString() {
		return "FavouriteFarmers [id=" + id + ", image=" + image + ", farmerName=" + farmerName + ", farmerId="
				+ farmerId + ", status=" + status + ", kisansathiId=" + kisansathiId + "]";
	}
}
