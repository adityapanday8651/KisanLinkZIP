package com.kisanlink.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Issue")
public class Issue extends BaseModel{
	@Id
	private String id;
	private String farmerId;
	private String farmerName;
	private String farmId;
	private String area;
	private String image;
	private String description;
	
	public String getId() {
		return id;
	}
	public String getFarmerId() {
		return farmerId;
	}
	public String getFarmerName() {
		return farmerName;
	}
	public String getFarmId() {
		return farmId;
	}
	public String getArea() {
		return area;
	}
	public String getImage() {
		return image;
	}
	public String getDescription() {
		return description;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setFarmerId(String farmerId) {
		this.farmerId = farmerId;
	}
	public void setFarmerName(String farmerName) {
		this.farmerName = farmerName;
	}
	public void setFarmId(String farmId) {
		this.farmId = farmId;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public String toString() {
		return "Issue [id=" + id + ", farmerId=" + farmerId + ", farmerName=" + farmerName + ", farmId=" + farmId
				+ ", area=" + area + ", image=" + image + ", description=" + description + "]";
	}
}
