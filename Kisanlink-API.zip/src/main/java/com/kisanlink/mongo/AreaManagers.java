package com.kisanlink.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="AreaManagers")
public class AreaManagers extends BaseModel{
	@Id
	private String id;
	private int areaManagerId;
	private String area;
	private String address;
	private String district;
	private String state;
	private String areaManagerName;
	private String contactNumber;
	private String soilTestingMachine;
	private String drone;
	
	public String getId() {
		return id;
	}
	public int getAreaManagerId() {
		return areaManagerId;
	}
	public String getArea() {
		return area;
	}
	public String getAddress() {
		return address;
	}
	public String getDistrict() {
		return district;
	}
	public String getState() {
		return state;
	}
	public String getAreaManagerName() {
		return areaManagerName;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public String getSoilTestingMachine() {
		return soilTestingMachine;
	}
	public String getDrone() {
		return drone;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setAreaManagerId(int areaManagerId) {
		this.areaManagerId = areaManagerId;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public void setState(String state) {
		this.state = state;
	}
	public void setAreaManagerName(String areaManagerName) {
		this.areaManagerName = areaManagerName;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public void setSoilTestingMachine(String soilTestingMachine) {
		this.soilTestingMachine = soilTestingMachine;
	}
	public void setDrone(String drone) {
		this.drone = drone;
	}
	@Override
	public String toString() {
		return "AreaManagers [id=" + id + ", areaManagerId=" + areaManagerId + ", area=" + area + ", address=" + address
				+ ", district=" + district + ", state=" + state + ", areaManagerName=" + areaManagerName
				+ ", contactNumber=" + contactNumber + ", soilTestingMachine=" + soilTestingMachine + ", drone=" + drone
				+ "]";
	}
}
