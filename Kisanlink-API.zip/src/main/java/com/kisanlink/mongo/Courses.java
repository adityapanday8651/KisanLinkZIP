package com.kisanlink.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Courses")
public class Courses extends BaseModel{
	@Id
	private String id;
	private String courseId;
	private String principleOfOrganicFarming;
	private String courseIncluded;
	private String courseFees;
	private String guideBy;
	
	public String getId() {
		return id;
	}
	public String getCourseId() {
		return courseId;
	}
	public String getPrincipleOfOrganicFarming() {
		return principleOfOrganicFarming;
	}
	public String getCourseIncluded() {
		return courseIncluded;
	}
	public String getCourseFees() {
		return courseFees;
	}
	public String getGuideBy() {
		return guideBy;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}
	public void setPrincipleOfOrganicFarming(String principleOfOrganicFarming) {
		this.principleOfOrganicFarming = principleOfOrganicFarming;
	}
	public void setCourseIncluded(String courseIncluded) {
		this.courseIncluded = courseIncluded;
	}
	public void setCourseFees(String courseFees) {
		this.courseFees = courseFees;
	}
	public void setGuideBy(String guideBy) {
		this.guideBy = guideBy;
	}
	
	@Override
	public String toString() {
		return "Courses [id=" + id + ", courseId=" + courseId + ", principleOfOrganicFarming="
				+ principleOfOrganicFarming + ", courseIncluded=" + courseIncluded + ", courseFees=" + courseFees
				+ ", guideBy=" + guideBy + "]";
	}
}
