package com.kisanlink.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Variants")
public class Variants extends BaseModel{
	@Id
	private String id;
	private int variantId;
	private String image;
	private String name;
	
	public String getId() {
		return id;
	}
	public int getVariantId() {
		return variantId;
	}
	public String getImage() {
		return image;
	}
	public String getName() {
		return name;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setVariantId(int variantId) {
		this.variantId = variantId;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Variants [id=" + id + ", variantId=" + variantId + ", image=" + image + ", name=" + name + "]";
	}
}
