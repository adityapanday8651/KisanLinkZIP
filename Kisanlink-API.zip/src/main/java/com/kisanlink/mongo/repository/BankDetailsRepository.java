package com.kisanlink.mongo.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.kisanlink.mongo.BankDetails;

@Repository
public interface BankDetailsRepository extends MongoRepository<BankDetails, String> {
   public BankDetails findByAccountNumber(String accountNumber);
   public Optional<BankDetails> findById(String bankId);
   public BankDetails findByUserId(String id);
}
