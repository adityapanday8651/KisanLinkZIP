package com.kisanlink.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.kisanlink.mongo.Agricenter;

@Repository
public interface AgricenterRepository extends MongoRepository<Agricenter, String>{
	Agricenter findByName(String name);
}
