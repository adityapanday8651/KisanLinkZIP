package com.kisanlink.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.kisanlink.mongo.Courses;

public interface CoursesRepository extends MongoRepository<Courses, String>{

	Courses findByCourseId(String courseId);

}
