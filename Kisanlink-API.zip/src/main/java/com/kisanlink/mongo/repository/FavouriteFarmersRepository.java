package com.kisanlink.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.kisanlink.mongo.FavouriteFarmers;

public interface FavouriteFarmersRepository extends MongoRepository<FavouriteFarmers, String>{

	FavouriteFarmers findByFarmerName(String farmerName);
	FavouriteFarmers findByFarmerId(int farmerId);

}