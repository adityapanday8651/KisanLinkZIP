package com.kisanlink.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.kisanlink.mongo.WishList;

@Repository
public interface WishListRepository extends MongoRepository<WishList, String>{

	WishList findByFarmerId(String farmerId);

}
