package com.kisanlink.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.kisanlink.mongo.ServiceProvider;

@Repository
public interface ServiceProviderRepository extends MongoRepository<ServiceProvider, String>{

	ServiceProvider findByFarmerId(String farmerId);

}
