package com.kisanlink.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.kisanlink.mongo.Orders;

public interface OrdersRepository extends MongoRepository<Orders,String>{
	Orders findByOrderId(int orderId);
}
