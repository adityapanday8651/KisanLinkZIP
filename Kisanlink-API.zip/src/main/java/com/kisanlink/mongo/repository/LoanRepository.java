package com.kisanlink.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.kisanlink.mongo.Loan;

public interface LoanRepository extends MongoRepository<Loan, String>{

	Loan findByFarmerId(String farmerId);

}
