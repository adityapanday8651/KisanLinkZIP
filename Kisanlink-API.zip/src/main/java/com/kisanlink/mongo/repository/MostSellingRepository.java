package com.kisanlink.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.kisanlink.mongo.MostSelling;

public interface MostSellingRepository extends MongoRepository<MostSelling, String>{

	MostSelling findByProductName(String productName);

}
