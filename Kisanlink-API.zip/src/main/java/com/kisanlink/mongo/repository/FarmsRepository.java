package com.kisanlink.mongo.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.kisanlink.mongo.Farms;

@Repository
public interface FarmsRepository extends MongoRepository<Farms, String>{

	Optional<Farms> findById(String farmerId);

}
