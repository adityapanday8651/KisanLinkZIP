package com.kisanlink.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.kisanlink.mongo.Reports;

public interface ReportsRepository extends MongoRepository<Reports, String>{
	Reports findByReportId(String reportId);

}
