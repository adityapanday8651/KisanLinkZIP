package com.kisanlink.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.kisanlink.mongo.CheckOut;

public interface CheckOutRepository extends MongoRepository<CheckOut, String>{

	CheckOut findByFarmerId(String farmerId);

}
