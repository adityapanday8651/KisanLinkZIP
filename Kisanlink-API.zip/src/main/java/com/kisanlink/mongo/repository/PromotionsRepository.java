package com.kisanlink.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.kisanlink.mongo.Promotions;

@Repository
public interface PromotionsRepository extends MongoRepository<Promotions, String>{

	Promotions findByCampaignId(String campaignId);

}
