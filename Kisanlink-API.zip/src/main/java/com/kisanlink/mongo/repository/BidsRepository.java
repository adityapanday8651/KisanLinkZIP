package com.kisanlink.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.kisanlink.mongo.Bids;

public interface BidsRepository extends MongoRepository<Bids, String>{

	Bids findByProductName(String productName);
	
}
