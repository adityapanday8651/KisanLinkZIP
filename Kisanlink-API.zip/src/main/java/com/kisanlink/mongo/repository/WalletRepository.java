package com.kisanlink.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.kisanlink.mongo.Wallet;

public interface WalletRepository extends MongoRepository<Wallet, String>{

	Wallet findByWalletId(String walletId);

}
