package com.kisanlink.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.kisanlink.mongo.Farmers;

@Repository
public interface FarmersRepository extends MongoRepository<Farmers,String>{

	Farmers findByMobileNumber(long farmerId);
	Farmers findByFarmerId(int farmerId);
}
