package com.kisanlink.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.kisanlink.mongo.Groups;

@Repository
public interface GroupsRepository extends MongoRepository<Groups, String>{

	Groups findByGroupName(String groupName);

}
