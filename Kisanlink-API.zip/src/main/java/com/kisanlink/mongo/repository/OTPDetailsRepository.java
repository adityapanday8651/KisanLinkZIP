package com.kisanlink.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.kisanlink.mongo.OTPDetails;

@Repository
public interface OTPDetailsRepository extends MongoRepository<OTPDetails, String>{
	public OTPDetails findByMobileNumber(long phoneNumber);
}
