package com.kisanlink.mongo.repository;



import org.springframework.data.mongodb.repository.MongoRepository;

import com.kisanlink.mongo.Products;

public interface ProductsRepository extends MongoRepository<Products,String>{

	Products findByProductId(int productId);

}
