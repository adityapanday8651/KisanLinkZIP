package com.kisanlink.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.kisanlink.mongo.Carts;

public interface CartsRepository extends MongoRepository<Carts, String>{

	Carts findByCategoryId(String categoryId);

}
