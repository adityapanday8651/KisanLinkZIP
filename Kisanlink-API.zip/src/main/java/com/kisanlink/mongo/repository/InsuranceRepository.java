package com.kisanlink.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.kisanlink.mongo.Insurance;

@Repository
public interface InsuranceRepository extends MongoRepository<Insurance, String> {
   public Insurance findByid(String id);
}
