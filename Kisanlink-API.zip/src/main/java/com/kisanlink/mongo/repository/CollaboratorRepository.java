package com.kisanlink.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.kisanlink.mongo.Collaborator;

@Repository
public interface CollaboratorRepository extends MongoRepository<Collaborator, String> {
	public Collaborator findByid(String id);
}
