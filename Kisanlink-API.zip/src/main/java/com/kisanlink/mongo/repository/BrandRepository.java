package com.kisanlink.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.kisanlink.mongo.Brand;

public interface BrandRepository extends MongoRepository<Brand, String>{

	Brand findByName(String name);

}
