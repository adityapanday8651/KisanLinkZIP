package com.kisanlink.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.kisanlink.mongo.State;

public interface StateRepository extends MongoRepository<State, String>{

	State findByStateId(int stateId);

}
