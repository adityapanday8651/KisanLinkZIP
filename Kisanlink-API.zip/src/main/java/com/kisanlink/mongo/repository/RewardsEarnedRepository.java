package com.kisanlink.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.kisanlink.mongo.RewardsEarned;

@Repository
public interface RewardsEarnedRepository extends MongoRepository<RewardsEarned, String>{

	RewardsEarned findByReferralCode(String referralCode);
	
}
