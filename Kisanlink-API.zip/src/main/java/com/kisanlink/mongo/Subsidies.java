package com.kisanlink.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Subsidies")
public class Subsidies extends BaseModel {
	@Id
	private String id;
	private String name;
	private String eligibility;
	private String timeline;
	private String benefits;
	private String document;
	
	public String getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public String getEligibility() {
		return eligibility;
	}
	public String getTimeline() {
		return timeline;
	}
	public String getBenefits() {
		return benefits;
	}
	public String getDocument() {
		return document;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setEligibility(String eligibility) {
		this.eligibility = eligibility;
	}
	public void setTimeline(String timeline) {
		this.timeline = timeline;
	}
	public void setBenefits(String benefits) {
		this.benefits = benefits;
	}
	public void setDocument(String document) {
		this.document = document;
	}
	@Override
	public String toString() {
		return "Subsidies [id=" + id + ", name=" + name + ", eligibility=" + eligibility + ", timeline=" + timeline
				+ ", benefits=" + benefits + ", document=" + document + "]";
	}
}
