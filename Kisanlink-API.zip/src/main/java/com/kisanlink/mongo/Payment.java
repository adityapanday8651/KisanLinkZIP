package com.kisanlink.mongo;

import java.util.GregorianCalendar;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Payment")
public class Payment extends BaseModel {
	
	@Id
	private String id;
	private int paymentId;
	private String referenceId;
	private GregorianCalendar date;
	private String refernceName;
	private String image;
	private String orders;
	private String incentive;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}
	public String getReferenceId() {
		return referenceId;
	}
	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}
	public GregorianCalendar getDate() {
		return date;
	}
	public void setDate(GregorianCalendar date) {
		this.date = date;
	}
	public String getRefernceName() {
		return refernceName;
	}
	public void setRefernceName(String refernceName) {
		this.refernceName = refernceName;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getOrders() {
		return orders;
	}
	public void setOrders(String orders) {
		this.orders = orders;
	}
	public String getIncentive() {
		return incentive;
	}
	public void setIncentive(String incentive) {
		this.incentive = incentive;
	}
	@Override
	public String toString() {
		return "Payment [id=" + id + ", paymentId=" + paymentId + ", referenceId=" + referenceId + ", date=" + date
				+ ", refernceName=" + refernceName + ", image=" + image + ", orders=" + orders + ", incentive="
				+ incentive + "]";
	}
}
