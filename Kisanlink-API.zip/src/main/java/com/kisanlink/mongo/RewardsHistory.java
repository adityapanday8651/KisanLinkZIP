package com.kisanlink.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="RewardsHistory")
public class RewardsHistory extends BaseModel{
	@Id
	private String id;
	private String name;
	private double earnMoney;
	private String date;
	
	public String getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public String getDate() {
		return date;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public double getEarnMoney() {
		return earnMoney;
	}
	public void setEarnMoney(double earnMoney) {
		this.earnMoney = earnMoney;
	}
	@Override
	public String toString() {
		return "RewardsHistory [id=" + id + ", name=" + name + ", earnMoney=" + earnMoney + ", date=" + date + "]";
	}
}
