package com.kisanlink.mongo;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "OTPDetails")
public class OTPDetails extends BaseModel {

	@Id
	private String id;
	private long mobileNumber;
	private Date createdDate;
	private String otp;

	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	@Override
	public String toString() {
		return "OTPDetails [id=" + id + ", mobileNumber=" + mobileNumber + ", createdDate=" + createdDate + ", otp="
				+ otp + "]";
	}
}