package com.kisanlink.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Kisansathi")
public class Kisansathi extends BaseModel{
   
	@Id
	private String id;
	private String name;
	private int kisansathiId;
	private String Image;
	private String phoneNumber;
	private String nodalCenter;
	private String manager;
	private String SalesCompleted;
	private String currentOrders;
	private String coursesCompleted;
	private String status;
	private String Actions;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getKisansathiId() {
		return kisansathiId;
	}
	public void setKisansathiId(int kisansathiId) {
		this.kisansathiId = kisansathiId;
	}
	public String getImage() {
		return Image;
	}
	public void setImage(String image) {
		Image = image;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getNodalCenter() {
		return nodalCenter;
	}
	public void setNodalCenter(String nodalCenter) {
		this.nodalCenter = nodalCenter;
	}
	public String getManager() {
		return manager;
	}
	public void setManager(String manager) {
		this.manager = manager;
	}
	public String getSalesCompleted() {
		return SalesCompleted;
	}
	public void setSalesCompleted(String salesCompleted) {
		SalesCompleted = salesCompleted;
	}
	public String getCurrentOrders() {
		return currentOrders;
	}
	public void setCurrentOrders(String currentOrders) {
		this.currentOrders = currentOrders;
	}
	public String getCoursesCompleted() {
		return coursesCompleted;
	}
	public void setCoursesCompleted(String coursesCompleted) {
		this.coursesCompleted = coursesCompleted;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getActions() {
		return Actions;
	}
	public void setActions(String actions) {
		Actions = actions;
	}
	@Override
	public String toString() {
		return "Kisansathi [id=" + id + ", name=" + name + ", kisansathiId=" + kisansathiId + ", Image=" + Image
				+ ", phoneNumber=" + phoneNumber + ", nodalCenter=" + nodalCenter + ", manager=" + manager
				+ ", SalesCompleted=" + SalesCompleted + ", currentOrders=" + currentOrders + ", coursesCompleted="
				+ coursesCompleted + ", status=" + status + ", Actions=" + Actions + "]";
	}

	 
}
