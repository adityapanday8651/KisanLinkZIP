package com.kisanlink.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Crop")
public class Crop extends BaseModel{
	@Id
	private String id;
	private int cropId;
	private String cropName;
	
	public String getId() {
		return id;
	}
	public int getCropId() {
		return cropId;
	}
	public String getCropName() {
		return cropName;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setCropId(int cropId) {
		this.cropId = cropId;
	}
	public void setCropName(String cropName) {
		this.cropName = cropName;
	}
	@Override
	public String toString() {
		return "Crop [id=" + id + ", cropId=" + cropId + ", cropName=" + cropName + "]";
	}
}
