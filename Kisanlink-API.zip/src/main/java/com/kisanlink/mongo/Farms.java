package com.kisanlink.mongo;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Farms")
public class Farms extends BaseModel{
	
	@Id
	private String id;
	private int farmId;
	private int farmerId;
	private String farmerName;
	private String commodity;
	private String variant;
	private String availableFrom;
	private String status;
	private double expectedYield;
	private double price;
	private String cropCategory;
	private String crop;
	private String cropVariety;
	private Double acres;
	private Double tons;
	private String harvestDate;
	private long farmerMobileNumber;
	private String address;
	private List<Dimensions> dimensions;
	private String locality;
	private String landmark;
	private String pincode;
	private String town;
	private String city;
	private String state;
	private List<String> images;
	private int kisansathiId;
	private String kisansathiName;
	private boolean isVerified;
	private boolean farmerVerified;

	public boolean isFarmerVerified() {
		return farmerVerified;
	}

	public void setFarmerVerified(boolean farmerVerified) {
		this.farmerVerified = farmerVerified;
	}

	public boolean isVerified() {
		return isVerified;
	}

	public void setVerified(boolean isVerified) {
		this.isVerified = isVerified;
	}

	public String getKisansathiName() {
		return kisansathiName;
	}

	public void setKisansathiName(String kisansathiName) {
		this.kisansathiName = kisansathiName;
	}

	public List<String> getImages() {
		return images;
	}

	public void setImages(List<String> images) {
		this.images = images;
	}

	public List<Dimensions> getDimensions() {
		return dimensions;
	}

	public void setDimensions(List<Dimensions> dimensions) {
		this.dimensions = dimensions;
	}

	public int getKisansathiId() {
		return kisansathiId;
	}

	public void setKisansathiId(int kisansathiId) {
		this.kisansathiId = kisansathiId;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getFarmId() {
		return farmId;
	}

	public void setFarmId(int farmId) {
		this.farmId = farmId;
	}

	public int getFarmerId() {
		return farmerId;
	}

	public void setFarmerId(int farmerId) {
		this.farmerId = farmerId;
	}

	public String getFarmerName() {
		return farmerName;
	}

	public void setFarmerName(String farmerName) {
		this.farmerName = farmerName;
	}

	public String getCommodity() {
		return commodity;
	}

	public void setCommodity(String commodity) {
		this.commodity = commodity;
	}

	public String getVariant() {
		return variant;
	}

	public void setVariant(String variant) {
		this.variant = variant;
	}

	public String getAvailableFrom() {
		return availableFrom;
	}

	public void setAvailableFrom(String availableFrom) {
		this.availableFrom = availableFrom;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public double getExpectedYield() {
		return expectedYield;
	}

	public void setExpectedYield(double expectedYield) {
		this.expectedYield = expectedYield;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getCropCategory() {
		return cropCategory;
	}

	public void setCropCategory(String cropCategory) {
		this.cropCategory = cropCategory;
	}

	public String getCrop() {
		return crop;
	}

	public void setCrop(String crop) {
		this.crop = crop;
	}

	public String getCropVariety() {
		return cropVariety;
	}

	public void setCropVariety(String cropVariety) {
		this.cropVariety = cropVariety;
	}

	public Double getAcres() {
		return acres;
	}

	public void setAcres(Double acres) {
		this.acres = acres;
	}

	public Double getTons() {
		return tons;
	}

	public void setTons(Double tons) {
		this.tons = tons;
	}

	public String getHarvestDate() {
		return harvestDate;
	}

	public void setHarvestDate(String harvestDate) {
		this.harvestDate = harvestDate;
	}

	public long getFarmerMobileNumber() {
		return farmerMobileNumber;
	}

	public void setFarmerMobileNumber(long farmerMobileNumber) {
		this.farmerMobileNumber = farmerMobileNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getLocality() {
		return locality;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getTown() {
		return town;
	}

	public void setTown(String town) {
		this.town = town;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Override
	public String toString() {
		return "Farms [id=" + id + ", farmId=" + farmId + ", farmerId=" + farmerId + ", farmerName=" + farmerName
				+ ", commodity=" + commodity + ", variant=" + variant + ", availableFrom=" + availableFrom + ", status="
				+ status + ", expectedYield=" + expectedYield + ", price=" + price + ", cropCategory=" + cropCategory
				+ ", crop=" + crop + ", cropVariety=" + cropVariety + ", acres=" + acres + ", tons=" + tons
				+ ", harvestDate=" + harvestDate + ", farmerMobileNumber=" + farmerMobileNumber + ", address=" + address
				+ ", dimensions=" + dimensions + ", locality=" + locality + ", landmark=" + landmark + ", pincode="
				+ pincode + ", town=" + town + ", city=" + city + ", state=" + state + ", images=" + images
				+ ", kisansathiId=" + kisansathiId + "]";
	}


}