package com.kisanlink.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Goals")
public class Goals extends BaseModel {
	@Id
	private String id;
	private int kisanSathiId;
	private String status;
	private String month;
	private Double amount;
	private String year;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getKisanSathiId() {
		return kisanSathiId;
	}
	public void setKisanSathiId(int kisanSathiId) {
		this.kisanSathiId = kisanSathiId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	@Override
	public String toString() {
		return "Goals [id=" + id + ", kisanSathiId=" + kisanSathiId + ", status=" + status + ", month=" + month
				+ ", amount=" + amount + ", year=" + year + "]";
	}

	
}