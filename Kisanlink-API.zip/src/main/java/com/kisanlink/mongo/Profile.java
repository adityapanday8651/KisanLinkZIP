package com.kisanlink.mongo;

import org.springframework.data.annotation.Id;

public class Profile extends BaseModel{

	@Id
	private String id;
	
}