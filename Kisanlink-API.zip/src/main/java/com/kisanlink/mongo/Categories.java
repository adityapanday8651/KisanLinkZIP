package com.kisanlink.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Categories")
public class Categories extends BaseModel{
	@Id
	private String id;
	private int categoryId;
	private String categoryName;
	
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	@Override
	public String toString() {
		return "Categories [id=" + id + ", categoryId=" + categoryId + ", categoryName=" + categoryName + "]";
	}	
}
