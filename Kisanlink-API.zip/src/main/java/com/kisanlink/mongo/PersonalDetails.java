package com.kisanlink.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="PersonalDetails")
public class PersonalDetails extends BaseModel{
	@Id
	 private String id;
	 private String aadharcard;
	 private String pancard;
	 private String userId;
	 private String name;
	 
	public String getId() {
		return id;
	}
	public String getAadharcard() {
		return aadharcard;
	}
	public String getPancard() {
		return pancard;
	}
	public String getUserId() {
		return userId;
	}
	public String getName() {
		return name;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setAadharcard(String aadharcard) {
		this.aadharcard = aadharcard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "PersonalDetails [id=" + id + ", aadharcard=" + aadharcard + ", pancard=" + pancard + ", userId="
				+ userId + ", name=" + name + "]";
	}
}
