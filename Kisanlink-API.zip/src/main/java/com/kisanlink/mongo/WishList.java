package com.kisanlink.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="WishList")
public class WishList extends BaseModel{
	@Id
	private String id;
	private String categoryId;
	private String farmerId;
	private String productName;
	private String productDescription;
	private String productType;
	private boolean productLike;
	private double productPrice;
	
	public String getId() {
		return id;
	}
	public String getFarmerId() {
		return farmerId;
	}
	public String getCategoryId() {
		return categoryId;
	}
	
	public String getProductName() {
		return productName;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public String getProductType() {
		return productType;
	}
	public boolean isProductLike() {
		return productLike;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setFarmerId(String farmerId) {
		this.farmerId = farmerId;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public void setProductLike(boolean productLike) {
		this.productLike = productLike;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	@Override
	public String toString() {
		return "WishList [id=" + id + ", categoryId=" + categoryId + ", farmerId=" + farmerId + ", productName="
				+ productName + ", productDescription=" + productDescription + ", productType=" + productType
				+ ", productLike=" + productLike + ", productPrice=" + productPrice + "]";
	}
}
