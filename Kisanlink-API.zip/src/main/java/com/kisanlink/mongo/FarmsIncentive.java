package com.kisanlink.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="FarmsIncentive")
public class FarmsIncentive extends BaseModel{
	@Id
	private String id;
	private String farmerName;
	private String farmId;
	private String farmerType;
	private String date;
	
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getId() {
		return id;
	}
	public String getFarmerName() {
		return farmerName;
	}
	public String getFarmId() {
		return farmId;
	}
	public String getFarmerType() {
		return farmerType;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setFarmerName(String farmerName) {
		this.farmerName = farmerName;
	}
	public void setFarmId(String farmId) {
		this.farmId = farmId;
	}
	public void setFarmerType(String farmerType) {
		this.farmerType = farmerType;
	}
	@Override
	public String toString() {
		return "FarmsIncentive [id=" + id + ", farmerName=" + farmerName + ", farmId=" + farmId + ", farmerType="
				+ farmerType + ", date=" + date + "]";
	}
	
	
	
}
