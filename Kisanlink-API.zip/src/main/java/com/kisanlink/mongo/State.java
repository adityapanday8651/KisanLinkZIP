package com.kisanlink.mongo;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="State")
public class State extends BaseModel{
	private String id;
	private int stateId;
	private String name;
	
	public String getId() {
		return id;
	}
	public int getStateId() {
		return stateId;
	}
	public String getName() {
		return name;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setStateId(int stateId) {
		this.stateId = stateId;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "State [id=" + id + ", stateId=" + stateId + ", name=" + name + "]";
	}
}
