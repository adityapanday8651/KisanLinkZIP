package com.kisanlink.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="References")
public class References extends BaseModel{
	@Id
	private String id;
	private int referenceId;
	private String nameOfKisansathi;
	private int kisanSathiId;
	private String referenceName;
	private String dateOfReference;
	private String dateOf10thOrder;
	private int valueOf10Orders;
	private int incentive;
	private int currentOrderValue;
	public String getId() {
		return id;
	}
	public int getReferenceId() {
		return referenceId;
	}
	public String getNameOfKisansathi() {
		return nameOfKisansathi;
	}
	public int getKisanSathiId() {
		return kisanSathiId;
	}
	public String getReferenceName() {
		return referenceName;
	}
	public String getDateOfReference() {
		return dateOfReference;
	}
	public String getDateOf10thOrder() {
		return dateOf10thOrder;
	}
	public int getValueOf10Orders() {
		return valueOf10Orders;
	}
	public int getIncentive() {
		return incentive;
	}
	public int getCurrentOrderValue() {
		return currentOrderValue;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setReferenceId(int referenceId) {
		this.referenceId = referenceId;
	}
	public void setNameOfKisansathi(String nameOfKisansathi) {
		this.nameOfKisansathi = nameOfKisansathi;
	}
	public void setKisanSathiId(int kisanSathiId) {
		this.kisanSathiId = kisanSathiId;
	}
	public void setReferenceName(String referenceName) {
		this.referenceName = referenceName;
	}
	public void setDateOfReference(String dateOfReference) {
		this.dateOfReference = dateOfReference;
	}
	public void setDateOf10thOrder(String dateOf10thOrder) {
		this.dateOf10thOrder = dateOf10thOrder;
	}
	public void setValueOf10Orders(int valueOf10Orders) {
		this.valueOf10Orders = valueOf10Orders;
	}
	public void setIncentive(int incentive) {
		this.incentive = incentive;
	}
	public void setCurrentOrderValue(int currentOrderValue) {
		this.currentOrderValue = currentOrderValue;
	}
	@Override
	public String toString() {
		return "References [id=" + id + ", referenceId=" + referenceId + ", nameOfKisansathi=" + nameOfKisansathi
				+ ", kisanSathiId=" + kisanSathiId + ", referenceName=" + referenceName + ", dateOfReference="
				+ dateOfReference + ", dateOf10thOrder=" + dateOf10thOrder + ", valueOf10Orders=" + valueOf10Orders
				+ ", incentive=" + incentive + ", currentOrderValue=" + currentOrderValue + "]";
	}
}
