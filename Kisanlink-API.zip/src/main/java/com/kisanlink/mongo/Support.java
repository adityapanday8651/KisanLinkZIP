package com.kisanlink.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Support")
public class Support extends BaseModel {
   
	@Id
	private String supportId;
	private String farmerId;
	private String userName;
	private String address1;
	private String address2; 
	private String status;
	private double longitude;
	private double lattitude;
	
	public String getSupportId() {
		return supportId;
	}
	public void setSupportId(String supportId) {
		this.supportId = supportId;
	}
	public String getFarmerId() {
		return farmerId;
	}
	public void setFarmerId(String farmerId) {
		this.farmerId = farmerId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public double getLongitude() {
		return longitude;
	}
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	public double getLattitude() {
		return lattitude;
	}
	public void setLattitude(double lattitude) {
		this.lattitude = lattitude;
	}
	@Override
	public String toString() {
		return "Support [supportId=" + supportId + ", farmerId=" + farmerId + ", userName=" + userName + ", address1="
				+ address1 + ", address2=" + address2 + ", status=" + status + ", longitude=" + longitude
				+ ", lattitude=" + lattitude + "]";
	}
	
	
	
}
