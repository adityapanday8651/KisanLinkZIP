package com.kisanlink.util;

public final class APIEndpoints {

	  public static final String BASE_API_URL_V1 = "/api/v1";
}

