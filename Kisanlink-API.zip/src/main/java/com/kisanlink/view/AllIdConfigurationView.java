package com.kisanlink.view;

public class AllIdConfigurationView {
	private String id;
	private String name;
	private int lastGeneratedId;
	
	public String getId() {
		return id;
	}
	public int getLastGeneratedId() {
		return lastGeneratedId;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setLastGeneratedId(int lastGeneratedId) {
		this.lastGeneratedId = lastGeneratedId;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "AllIdConfigurationView [id=" + id + ", name=" + name + ", lastGeneratedId=" + lastGeneratedId + "]";
	}
}
