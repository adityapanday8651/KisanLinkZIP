package com.kisanlink.view;

import javax.xml.datatype.XMLGregorianCalendar;

public class ReferencesView {
	private String id;
	private int refId;
	private String nameOfKisansathi;
	private int kisanSathiId;
	private String referenceName;
	private XMLGregorianCalendar dateOfTenthOrder;
	private int valueOfTenthOrders;
	private int incentive;
	private int currentOrderValue;

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getRefId() {
		return refId;
	}
	public void setRefId(int refId) {
		this.refId = refId;
	}
	public String getNameOfKisansathi() {
		return nameOfKisansathi;
	}
	public void setNameOfKisansathi(String nameOfKisansathi) {
		this.nameOfKisansathi = nameOfKisansathi;
	}
	public int getKisanSathiId() {
		return kisanSathiId;
	}
	public void setKisanSathiId(int kisanSathiId) {
		this.kisanSathiId = kisanSathiId;
	}
	public String getReferenceName() {
		return referenceName;
	}
	public void setReferenceName(String referenceName) {
		this.referenceName = referenceName;
	}
	public XMLGregorianCalendar getDateOfTenthOrder() {
		return dateOfTenthOrder;
	}
	public void setDateOfTenthOrder(XMLGregorianCalendar dateOfTenthOrder) {
		this.dateOfTenthOrder = dateOfTenthOrder;
	}
	public int getValueOfTenthOrders() {
		return valueOfTenthOrders;
	}
	public void setValueOfTenthOrders(int valueOfTenthOrders) {
		this.valueOfTenthOrders = valueOfTenthOrders;
	}
	public int getIncentive() {
		return incentive;
	}
	public void setIncentive(int incentive) {
		this.incentive = incentive;
	}
	public int getCurrentOrderValue() {
		return currentOrderValue;
	}
	public void setCurrentOrderValue(int currentOrderValue) {
		this.currentOrderValue = currentOrderValue;
	}
	@Override
	public String toString() {
		return "ReferencesView [id=" + id + ", refId=" + refId + ", nameOfKisansathi=" + nameOfKisansathi
				+ ", kisanSathiId=" + kisanSathiId + ", referenceName=" + referenceName + ", dateOfTenthOrder="
				+ dateOfTenthOrder + ", valueOfTenthOrders=" + valueOfTenthOrders + ", incentive=" + incentive
				+ ", currentOrderValue=" + currentOrderValue + "]";
	}
}
