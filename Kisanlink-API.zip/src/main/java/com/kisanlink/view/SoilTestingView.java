package com.kisanlink.view;

public class SoilTestingView {
	
	private String id;
	private int serviceProviderId;
	private String name;
	private String address;
	private double price;
	private String areaCentre;
	private String advisory;
	private String timeForSubmission;
	private String contactPerson;
	private String contactNumber;
	private int noOfParametersInReport;
	private double incentiveForSample;
	
	public String getAreaCentre() {
		return areaCentre;
	}
	public void setAreaCentre(String areaCentre) {
		this.areaCentre = areaCentre;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public int getServiceProviderId() {
		return serviceProviderId;
	}
	public String getAddress() {
		return address;
	}
	public double getPrice() {
		return price;
	}
	public String getAdvisory() {
		return advisory;
	}
	public String getTimeForSubmission() {
		return timeForSubmission;
	}
	public String getContactPerson() {
		return contactPerson;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public int getNoOfParametersInReport() {
		return noOfParametersInReport;
	}
	public double getIncentiveForSample() {
		return incentiveForSample;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setServiceProviderId(int serviceProviderId) {
		this.serviceProviderId = serviceProviderId;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public void setAdvisory(String advisory) {
		this.advisory = advisory;
	}
	public void setTimeForSubmission(String timeForSubmission) {
		this.timeForSubmission = timeForSubmission;
	}
	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public void setNoOfParametersInReport(int noOfParametersInReport) {
		this.noOfParametersInReport = noOfParametersInReport;
	}
	public void setIncentiveForSample(double incentiveForSample) {
		this.incentiveForSample = incentiveForSample;
	}
	@Override
	public String toString() {
		return "SoilTestingView [id=" + id + ", serviceProviderId=" + serviceProviderId + ", name=" + name
				+ ", address=" + address + ", price=" + price + ", areaCentre=" + areaCentre + ", advisory=" + advisory
				+ ", timeForSubmission=" + timeForSubmission + ", contactPerson=" + contactPerson + ", contactNumber="
				+ contactNumber + ", noOfParametersInReport=" + noOfParametersInReport + ", incentiveForSample="
				+ incentiveForSample + "]";
	}
}