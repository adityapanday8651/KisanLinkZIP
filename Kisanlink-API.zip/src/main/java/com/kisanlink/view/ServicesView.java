package com.kisanlink.view;

public class ServicesView {
	private String id;
	private String farmerId;
	private String productName;
	private String description;
	private double price;
	
	
	
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getId() {
		return id;
	}
	public String getFarmerId() {
		return farmerId;
	}
	public String getDescription() {
		return description;
	}
	public double getPrice() {
		return price;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setFarmerId(String farmerId) {
		this.farmerId = farmerId;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "ServicesView [id=" + id + ", farmerId=" + farmerId + ", productName=" + productName + ", description="
				+ description + ", price=" + price + "]";
	}
	
}
