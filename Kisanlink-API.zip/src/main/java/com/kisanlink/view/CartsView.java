package com.kisanlink.view;

public class CartsView {
	private String id;
	private String categoryId;
	private String productName;
	private String productDescription;
	private String productType;
	private boolean productLike;
	private double productPrice;
	public String getId() {
		return id;
	}
	public String getCategoryId() {
		return categoryId;
	}
	public String getProductName() {
		return productName;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public String getProductType() {
		return productType;
	}
	public boolean isProductLike() {
		return productLike;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public void setProductLike(boolean productLike) {
		this.productLike = productLike;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	@Override
	public String toString() {
		return "CartsView [id=" + id + ", categoryId=" + categoryId + ", productName=" + productName
				+ ", productDescription=" + productDescription + ", productType=" + productType + ", productLike="
				+ productLike + ", productPrice=" + productPrice + "]";
	}
}
