package com.kisanlink.view;

public class InsuranceView {
	
	private String id;
	private int insuranceId;
	private String name;
	private String address;
	private String areaCentre;
	private String cropInsurance;
	
	public String getId() {
		return id;
	}
	public int getInsuranceId() {
		return insuranceId;
	}
	public String getName() {
		return name;
	}
	public String getAddress() {
		return address;
	}
	public String getAreaCentre() {
		return areaCentre;
	}
	public String getCropInsurance() {
		return cropInsurance;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setInsuranceId(int insuranceId) {
		this.insuranceId = insuranceId;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public void setAreaCentre(String areaCentre) {
		this.areaCentre = areaCentre;
	}
	public void setCropInsurance(String cropInsurance) {
		this.cropInsurance = cropInsurance;
	}
	@Override
	public String toString() {
		return "InsuranceView [id=" + id + ", insuranceId=" + insuranceId + ", name=" + name + ", address=" + address
				+ ", areaCentre=" + areaCentre + ", cropInsurance=" + cropInsurance + "]";
	}
}
