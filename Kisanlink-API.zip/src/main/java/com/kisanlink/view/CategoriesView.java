package com.kisanlink.view;

public class CategoriesView {
	
	private String id;
	private int categoryId; 
	private String productName;
	private String productType;
	private boolean status;
	private double productPrice;
	private String categoryName;
	
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	public String getId() {
		return id;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	@Override
	public String toString() {
		return "CategoriesView [id=" + id + ", categoryId=" + categoryId + ", productName=" + productName
				+ ", productType=" + productType + ", status=" + status + ", productPrice=" + productPrice
				+ ", categoryName=" + categoryName + "]";
	}
}
