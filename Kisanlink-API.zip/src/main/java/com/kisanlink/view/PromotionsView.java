package com.kisanlink.view;

public class PromotionsView {
	
	private String id;
	private String campaignId;
	private String orderDate;
	private String companyName;
	private int productId;
	private String nodalCentre;
	private String status;
	private double salesValue;
	private double farmersReachedPrice;
	private double promotionValue;
	
	public String getId() {
		return id;
	}
	public String getCampaignId() {
		return campaignId;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public String getCompanyName() {
		return companyName;
	}
	public int getProductId() {
		return productId;
	}
	public String getNodalCentre() {
		return nodalCentre;
	}
	public String getStatus() {
		return status;
	}
	public double getSalesValue() {
		return salesValue;
	}
	public double getFarmersReachedPrice() {
		return farmersReachedPrice;
	}
	public double getPromotionValue() {
		return promotionValue;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public void setNodalCentre(String nodalCentre) {
		this.nodalCentre = nodalCentre;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setSalesValue(double salesValue) {
		this.salesValue = salesValue;
	}
	public void setFarmersReachedPrice(double farmersReachedPrice) {
		this.farmersReachedPrice = farmersReachedPrice;
	}
	public void setPromotionValue(double promotionValue) {
		this.promotionValue = promotionValue;
	}
	@Override
	public String toString() {
		return "PromotionsView [id=" + id + ", campaignId=" + campaignId + ", orderDate=" + orderDate + ", companyName="
				+ companyName + ", productId=" + productId + ", nodalCentre=" + nodalCentre + ", status=" + status
				+ ", salesValue=" + salesValue + ", farmersReachedPrice=" + farmersReachedPrice + ", promotionValue="
				+ promotionValue + "]";
	}
}
