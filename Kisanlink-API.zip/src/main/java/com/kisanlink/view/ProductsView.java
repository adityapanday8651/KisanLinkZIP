package com.kisanlink.view;

public class ProductsView {
	
	private String id;
	private int productId;
	private String nameOfProduct;
	private String productCategory;
	private String collaboratorName;
	private String address;
	private String contactPerson;
	private String contactNumber;
	private String areaManager;
	private double landingPrice;
	private double sellingPrice;
	private String leadTimeToCentre;
	private String photo;
	private boolean status;
	private String brand;
	private double discount;

	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	public String getAreaManager() {
		return areaManager;
	}
	public boolean isStatus() {
		return status;
	}
	public void setAreaManager(String areaManager) {
		this.areaManager = areaManager;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public String getLeadTimeToCentre() {
		return leadTimeToCentre;
	}
	public void setLeadTimeToCentre(String leadTimeToCentre) {
		this.leadTimeToCentre = leadTimeToCentre;
	}
	public String getId() {
		return id;
	}
	public int getProductId() {
		return productId;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public String getCollaboratorName() {
		return collaboratorName;
	}
	public String getAddress() {
		return address;
	}
	public String getContactPerson() {
		return contactPerson;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public double getLandingPrice() {
		return landingPrice;
	}
	public double getSellingPrice() {
		return sellingPrice;
	}
	public String getPhoto() {
		return photo;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public void setCollaboratorName(String collaboratorName) {
		this.collaboratorName = collaboratorName;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public void setLandingPrice(double landingPrice) {
		this.landingPrice = landingPrice;
	}
	public void setSellingPrice(double sellingPrice) {
		this.sellingPrice = sellingPrice;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public String getNameOfProduct() {
		return nameOfProduct;
	}
	public void setNameOfProduct(String nameOfProduct) {
		this.nameOfProduct = nameOfProduct;
	}
	@Override
	public String toString() {
		return "ProductsView [id=" + id + ", productId=" + productId + ", nameOfProduct=" + nameOfProduct
				+ ", productCategory=" + productCategory + ", collaboratorName=" + collaboratorName + ", address="
				+ address + ", contactPerson=" + contactPerson + ", contactNumber=" + contactNumber + ", areaManager="
				+ areaManager + ", landingPrice=" + landingPrice + ", sellingPrice=" + sellingPrice
				+ ", leadTimeToCentre=" + leadTimeToCentre + ", photo=" + photo + ", status=" + status + "]";
	}
}