package com.kisanlink.view;

public class OutputView {
	private String id;
	private long outputId;
	private String name;
	private String address;
	private String cropName;
	private String variety;
	private String areaCentre;
	private String farmgateProcurement;
	private String contactName;
	private String contactNumber;
	private String paymentTerms;
	
	public String getId() {
		return id;
	}
	public long getOutputId() {
		return outputId;
	}
	public String getName() {
		return name;
	}
	public String getAddress() {
		return address;
	}
	public String getCropName() {
		return cropName;
	}
	public String getVariety() {
		return variety;
	}
	public String getAreaCentre() {
		return areaCentre;
	}
	public String getFarmgateProcurement() {
		return farmgateProcurement;
	}
	public String getContactName() {
		return contactName;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public String getPaymentTerms() {
		return paymentTerms;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setOutputId(long outputId) {
		this.outputId = outputId;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public void setCropName(String cropName) {
		this.cropName = cropName;
	}
	public void setVariety(String variety) {
		this.variety = variety;
	}
	public void setAreaCentre(String areaCentre) {
		this.areaCentre = areaCentre;
	}
	public void setFarmgateProcurement(String farmgateProcurement) {
		this.farmgateProcurement = farmgateProcurement;
	}
	public void setContactName(String contactName) {
		this.contactName = contactName;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public void setPaymentTerms(String paymentTerms) {
		this.paymentTerms = paymentTerms;
	}
	@Override
	public String toString() {
		return "OutputView [id=" + id + ", outputId=" + outputId + ", name=" + name + ", address=" + address
				+ ", cropName=" + cropName + ", variety=" + variety + ", areaCentre=" + areaCentre
				+ ", farmgateProcurement=" + farmgateProcurement + ", contactName=" + contactName + ", contactNumber="
				+ contactNumber + ", paymentTerms=" + paymentTerms + "]";
	}
}
