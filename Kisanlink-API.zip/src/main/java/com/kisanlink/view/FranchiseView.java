package com.kisanlink.view;

public class FranchiseView {
	private String id;
	private String franchiseId;
	private String area;
	private String address;
	private String district;
	private String state;
	private String franchiseManagerName;
	private String contactNUmber;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFranchiseId() {
		return franchiseId;
	}
	public void setFranchiseId(String franchiseId) {
		this.franchiseId = franchiseId;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getFranchiseManagerName() {
		return franchiseManagerName;
	}
	public void setFranchiseManagerName(String franchiseManagerName) {
		this.franchiseManagerName = franchiseManagerName;
	}
	public String getContactNUmber() {
		return contactNUmber;
	}
	public void setContactNUmber(String contactNUmber) {
		this.contactNUmber = contactNUmber;
	}
	@Override
	public String toString() {
		return "FranchiseCentres [id=" + id + ", franchiseId=" + franchiseId + ", area=" + area + ", address=" + address
				+ ", district=" + district + ", state=" + state + ", franchiseManagerName=" + franchiseManagerName
				+ ", contactNUmber=" + contactNUmber + "]";
	} 

}
