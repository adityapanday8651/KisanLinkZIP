package com.kisanlink.view;

public class LoanView {
	private String id;
	private String farmerId;
	private String farmerName;
	private String uploadLandDocument;
	private double loanAmount;
	private String yourAnswer;
	
	public String getId() {
		return id;
	}
	public String getFarmerId() {
		return farmerId;
	}
	public String getFarmerName() {
		return farmerName;
	}
	public String getUploadLandDocument() {
		return uploadLandDocument;
	}
	public double getLoanAmount() {
		return loanAmount;
	}
	public String getYourAnswer() {
		return yourAnswer;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setFarmerId(String farmerId) {
		this.farmerId = farmerId;
	}
	public void setFarmerName(String farmerName) {
		this.farmerName = farmerName;
	}
	public void setUploadLandDocument(String uploadLandDocument) {
		this.uploadLandDocument = uploadLandDocument;
	}
	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}
	public void setYourAnswer(String yourAnswer) {
		this.yourAnswer = yourAnswer;
	}
	@Override
	public String toString() {
		return "LoanView [id=" + id + ", farmerId=" + farmerId + ", farmerName=" + farmerName + ", uploadLandDocument="
				+ uploadLandDocument + ", loanAmount=" + loanAmount + ", yourAnswer=" + yourAnswer + "]";
	}
}
