package com.kisanlink.view;

import java.util.HashSet;
import java.util.Set;

import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.data.mongodb.core.mapping.DBRef;

import com.kisanlink.mongo.BankDetails;
import com.kisanlink.mongo.PersonalDetails;

public class FarmersView {

	private String id;
	private int farmerId;
	private String image;
	private String firstName;
	private String lastName;
	private long mobileNumber;
	private String paymentId;
	private int age;
	private String address;
	private double longitude;
	private double lattitude;
	private int salesValue;
	private int kisansathiId;
	private boolean isVerified;
	private String locality;
	private String landmark;
	private String city;
	private String state;
	private int numberofFarms;
	private String kisansathiName;
	private String createdBy;
	private XMLGregorianCalendar createdAt;
	private String modifiedBy;
	private XMLGregorianCalendar modifiedAt;
	private boolean isFavorite;
	private boolean isActive;
	
	@DBRef
	private Set<String> roles = new HashSet<>();
	private PersonalDetails details;
	private BankDetails bankDetails;
	private String pincode;

	public boolean isActive() {
		return isActive;
	}
	public Set<String> getRoles() {
		return roles;
	}
	public PersonalDetails getDetails() {
		return details;
	}
	public BankDetails getBankDetails() {
		return bankDetails;
	}
	public String getPincode() {
		return pincode;
	}
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	public void setRoles(Set<String> roles) {
		this.roles = roles;
	}
	public void setDetails(PersonalDetails details) {
		this.details = details;
	}
	public void setBankDetails(BankDetails bankDetails) {
		this.bankDetails = bankDetails;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public boolean isFavorite() {
		return isFavorite;
	}
	public void setFavorite(boolean isFavorite) {
		this.isFavorite = isFavorite;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public XMLGregorianCalendar getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(XMLGregorianCalendar createdAt) {
		this.createdAt = createdAt;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public XMLGregorianCalendar getModifiedAt() {
		return modifiedAt;
	}
	public void setModifiedAt(XMLGregorianCalendar modifiedAt) {
		this.modifiedAt = modifiedAt;
	}
	public String getKisansathiName() {
		return kisansathiName;
	}
	public void setKisansathiName(String kisansathiName) {
		this.kisansathiName = kisansathiName;
	}
	public int getNumberofFarms() {
		return numberofFarms;
	}
	public void setNumberofFarms(int numberofFarms) {
		this.numberofFarms = numberofFarms;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getFarmerId() {
		return farmerId;
	}
	public void setFarmerId(int farmerId) {
		this.farmerId = farmerId;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getLongitude() {
		return longitude;
	}
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	public double getLattitude() {
		return lattitude;
	}
	public void setLattitude(double lattitude) {
		this.lattitude = lattitude;
	}
	public int getSalesValue() {
		return salesValue;
	}
	public void setSalesValue(int salesValue) {
		this.salesValue = salesValue;
	}
	public int getKisansathiId() {
		return kisansathiId;
	}
	public void setKisansathiId(int kisansathiId) {
		this.kisansathiId = kisansathiId;
	}
	public boolean isVerified() {
		return isVerified;
	}
	public void setVerified(boolean isVerified) {
		this.isVerified = isVerified;
	}
	public String getLocality() {
		return locality;
	}
	public void setLocality(String locality) {
		this.locality = locality;
	}
	public String getLandmark() {
		return landmark;
	}
	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	@Override
	public String toString() {
		return "FarmersView [id=" + id + ", farmerId=" + farmerId + ", image=" + image + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", mobileNumber=" + mobileNumber + ", paymentId=" + paymentId + ", age="
				+ age + ", address=" + address + ", longitude=" + longitude + ", lattitude=" + lattitude
				+ ", salesValue=" + salesValue + ", kisansathiId=" + kisansathiId + ", isVerified=" + isVerified
				+ ", locality=" + locality + ", landmark=" + landmark + ", city=" + city + ", state=" + state
				+ ", numberofFarms=" + numberofFarms + ", kisansathiName=" + kisansathiName + ", createdBy=" + createdBy
				+ ", createdAt=" + createdAt + ", modifiedBy=" + modifiedBy + ", modifiedAt=" + modifiedAt
				+ ", isFavorite=" + isFavorite + ", isActive=" + isActive + ", roles=" + roles + ", details=" + details
				+ ", bankDetails=" + bankDetails + ", pincode=" + pincode + "]";
	}
}