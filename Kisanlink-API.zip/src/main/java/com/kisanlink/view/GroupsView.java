package com.kisanlink.view;

import java.util.List;

public class GroupsView {
	private String id;
	private String groupName;
	private String groupAdmin;
	private int participants;
	private List<String> farmerName;
	
	public String getId() {
		return id;
	}
	public String getGroupName() {
		return groupName;
	}
	public String getGroupAdmin() {
		return groupAdmin;
	}
	public int getParticipants() {
		return participants;
	}
	public List<String> getFarmerName() {
		return farmerName;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public void setGroupAdmin(String groupAdmin) {
		this.groupAdmin = groupAdmin;
	}
	public void setParticipants(int participants) {
		this.participants = participants;
	}
	public void setFarmerName(List<String> farmerName) {
		this.farmerName = farmerName;
	}
	@Override
	public String toString() {
		return "GroupsView [id=" + id + ", groupName=" + groupName + ", groupAdmin=" + groupAdmin + ", participants="
				+ participants + ", farmerName=" + farmerName + "]";
	}
}
