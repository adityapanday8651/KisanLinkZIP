package com.kisanlink.view;

public class ReportsView {
	private String id;
	private String reportId;
	private String kisanSathiId;
	private String name;
	private String mobileNumber;
	private String nodalCenter;
	private String farmersAdded;
	private String farmsAdded;
	private String coursesCompleted;
	private double salesCompleted;
	private double currentOrderValue;
	private double orderIncentive;
	private double farmsAdditionIncentive;
	private double totalIncentive;
	
	public String getReportId() {
		return reportId;
	}
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}
	public String getId() {
		return id;
	}
	public String getKisanSathiId() {
		return kisanSathiId;
	}
	public String getName() {
		return name;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public String getNodalCenter() {
		return nodalCenter;
	}
	public String getFarmersAdded() {
		return farmersAdded;
	}
	public String getFarmsAdded() {
		return farmsAdded;
	}
	public String getCoursesCompleted() {
		return coursesCompleted;
	}
	public double getSalesCompleted() {
		return salesCompleted;
	}
	public double getCurrentOrderValue() {
		return currentOrderValue;
	}
	public double getOrderIncentive() {
		return orderIncentive;
	}
	public double getFarmsAdditionIncentive() {
		return farmsAdditionIncentive;
	}
	public double getTotalIncentive() {
		return totalIncentive;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setKisanSathiId(String kisanSathiId) {
		this.kisanSathiId = kisanSathiId;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public void setNodalCenter(String nodalCenter) {
		this.nodalCenter = nodalCenter;
	}
	public void setFarmersAdded(String farmersAdded) {
		this.farmersAdded = farmersAdded;
	}
	public void setFarmsAdded(String farmsAdded) {
		this.farmsAdded = farmsAdded;
	}
	public void setCoursesCompleted(String coursesCompleted) {
		this.coursesCompleted = coursesCompleted;
	}
	public void setSalesCompleted(double salesCompleted) {
		this.salesCompleted = salesCompleted;
	}
	public void setCurrentOrderValue(double currentOrderValue) {
		this.currentOrderValue = currentOrderValue;
	}
	public void setOrderIncentive(double orderIncentive) {
		this.orderIncentive = orderIncentive;
	}
	public void setFarmsAdditionIncentive(double farmsAdditionIncentive) {
		this.farmsAdditionIncentive = farmsAdditionIncentive;
	}
	public void setTotalIncentive(double totalIncentive) {
		this.totalIncentive = totalIncentive;
	}
	@Override
	public String toString() {
		return "ReportsView [id=" + id + ", reportId=" + reportId + ", kisanSathiId=" + kisanSathiId + ", name=" + name
				+ ", mobileNumber=" + mobileNumber + ", nodalCenter=" + nodalCenter + ", farmersAdded=" + farmersAdded
				+ ", farmsAdded=" + farmsAdded + ", coursesCompleted=" + coursesCompleted + ", salesCompleted="
				+ salesCompleted + ", currentOrderValue=" + currentOrderValue + ", orderIncentive=" + orderIncentive
				+ ", farmsAdditionIncentive=" + farmsAdditionIncentive + ", totalIncentive=" + totalIncentive + "]";
	}
}
