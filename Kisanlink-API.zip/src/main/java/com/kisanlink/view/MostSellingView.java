package com.kisanlink.view;

public class MostSellingView {
	private String id;
	private int productId;
	private String image;
	private String productName;
	private double price;
	private double discount;
	
	public String getId() {
		return id;
	}
	public int getProductId() {
		return productId;
	}
	public String getImage() {
		return image;
	}
	public String getProductName() {
		return productName;
	}
	public double getPrice() {
		return price;
	}
	public double getDiscount() {
		return discount;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	@Override
	public String toString() {
		return "MostSellingView [id=" + id + ", productId=" + productId + ", image=" + image + ", productName="
				+ productName + ", price=" + price + ", discount=" + discount + "]";
	}
}
