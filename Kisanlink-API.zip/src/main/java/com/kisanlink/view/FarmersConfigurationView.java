package com.kisanlink.view;

public class FarmersConfigurationView {
	private String id;
	private int farmerId;
	private String lastGenerated;
	public String getId() {
		return id;
	}
	public int getFarmerId() {
		return farmerId;
	}
	public String getLastGenerated() {
		return lastGenerated;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setFarmerId(int farmerId) {
		this.farmerId = farmerId;
	}
	public void setLastGenerated(String lastGenerated) {
		this.lastGenerated = lastGenerated;
	}
	@Override
	public String toString() {
		return "FarmersConfigurationView [id=" + id + ", farmerId=" + farmerId + ", lastGenerated=" + lastGenerated
				+ "]";
	}
}
