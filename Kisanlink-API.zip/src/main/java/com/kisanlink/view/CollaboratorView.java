package com.kisanlink.view;

public class CollaboratorView {
	private String id;
	private int collaboratorId;
	private String nameOfCompany;
	private String contactPersonName;
	private String contactNumber;
	private String bankDetails;
	private String GSTINNumber;
	private String productsOrServices;
	private String State;
	private String district;
	
	public String getId() {
		return id;
	}
	public int getCollaboratorId() {
		return collaboratorId;
	}
	public String getNameOfCompany() {
		return nameOfCompany;
	}
	public String getContactPersonName() {
		return contactPersonName;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public String getBankDetails() {
		return bankDetails;
	}
	public String getGSTINNumber() {
		return GSTINNumber;
	}
	public String getProductsOrServices() {
		return productsOrServices;
	}
	public String getState() {
		return State;
	}
	public String getDistrict() {
		return district;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setCollaboratorId(int collaboratorId) {
		this.collaboratorId = collaboratorId;
	}
	public void setNameOfCompany(String nameOfCompany) {
		this.nameOfCompany = nameOfCompany;
	}
	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public void setBankDetails(String bankDetails) {
		this.bankDetails = bankDetails;
	}
	public void setGSTINNumber(String gSTINNumber) {
		GSTINNumber = gSTINNumber;
	}
	public void setProductsOrServices(String productsOrServices) {
		this.productsOrServices = productsOrServices;
	}
	public void setState(String state) {
		State = state;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	@Override
	public String toString() {
		return "CollaboratorView [id=" + id + ", collaboratorId=" + collaboratorId + ", nameOfCompany=" + nameOfCompany
				+ ", contactPersonName=" + contactPersonName + ", contactNumber=" + contactNumber + ", bankDetails="
				+ bankDetails + ", GSTINNumber=" + GSTINNumber + ", productsOrServices=" + productsOrServices
				+ ", State=" + State + ", district=" + district + "]";
	}
}
