package com.kisanlink.view;

public class TrainingView {
	private String id;
	private String farmerId;
	private String farmerName;
	private String courseName;
	private String courseCategory;
	private String duration;
	private String courseCompleteStatus;
	private String courseStatus;
	
	
	public String getCourseCompleteStatus() {
		return courseCompleteStatus;
	}
	public void setCourseCompleteStatus(String courseCompleteStatus) {
		this.courseCompleteStatus = courseCompleteStatus;
	}
	public String getId() {
		return id;
	}
	public String getFarmerId() {
		return farmerId;
	}
	public String getFarmerName() {
		return farmerName;
	}
	public String getCourseName() {
		return courseName;
	}
	public String getCourseCategory() {
		return courseCategory;
	}
	public String getDuration() {
		return duration;
	}
	public String getCourseStatus() {
		return courseStatus;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setFarmerId(String farmerId) {
		this.farmerId = farmerId;
	}
	public void setFarmerName(String farmerName) {
		this.farmerName = farmerName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public void setCourseCategory(String courseCategory) {
		this.courseCategory = courseCategory;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public void setCourseStatus(String courseStatus) {
		this.courseStatus = courseStatus;
	}
	@Override
	public String toString() {
		return "TrainingView [id=" + id + ", farmerId=" + farmerId + ", farmerName=" + farmerName + ", courseName="
				+ courseName + ", courseCategory=" + courseCategory + ", duration=" + duration
				+ ", courseCompleteStatus=" + courseCompleteStatus + ", courseStatus=" + courseStatus + "]";
	}
}
