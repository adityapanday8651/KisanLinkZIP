package com.kisanlink.view;

public class FinanceView {
	private String id;
	private int financeId;
	private String name;
	private String address;
	private String typeOfFinancialServices;
	private String contactPerson;
	private String areaManager;
	private String contactNumber;
	public String getId() {
		return id;
	}
	public int getFinanceId() {
		return financeId;
	}
	public String getName() {
		return name;
	}
	public String getAddress() {
		return address;
	}
	public String getTypeOfFinancialServices() {
		return typeOfFinancialServices;
	}
	public String getContactPerson() {
		return contactPerson;
	}
	public String getAreaManager() {
		return areaManager;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setFinanceId(int financeId) {
		this.financeId = financeId;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public void setTypeOfFinancialServices(String typeOfFinancialServices) {
		this.typeOfFinancialServices = typeOfFinancialServices;
	}
	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}
	public void setAreaManager(String areaManager) {
		this.areaManager = areaManager;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	@Override
	public String toString() {
		return "FinanceView [id=" + id + ", financeId=" + financeId + ", name=" + name + ", address=" + address
				+ ", typeOfFinancialServices=" + typeOfFinancialServices + ", contactPerson=" + contactPerson
				+ ", areaManager=" + areaManager + ", contactNumber=" + contactNumber + "]";
	}	
}