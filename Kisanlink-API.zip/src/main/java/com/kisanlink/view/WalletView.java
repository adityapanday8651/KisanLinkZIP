package com.kisanlink.view;

public class WalletView {
	private String id;
	private String walletId;
	private String kisanSathiName;
	private String nodalCenterId;
	private int salesValue;
	private int currentOrderValue;
	private double walletAmount;
	private String statusRequest;
	
	public String getId() {
		return id;
	}
	public String getWalletId() {
		return walletId;
	}
	public String getKisanSathiName() {
		return kisanSathiName;
	}
	public String getNodalCenterId() {
		return nodalCenterId;
	}
	public int getSalesValue() {
		return salesValue;
	}
	public int getCurrentOrderValue() {
		return currentOrderValue;
	}
	public double getWalletAmount() {
		return walletAmount;
	}
	public String getStatusRequest() {
		return statusRequest;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setWalletId(String walletId) {
		this.walletId = walletId;
	}
	public void setKisanSathiName(String kisanSathiName) {
		this.kisanSathiName = kisanSathiName;
	}
	public void setNodalCenterId(String nodalCenterId) {
		this.nodalCenterId = nodalCenterId;
	}
	public void setSalesValue(int salesValue) {
		this.salesValue = salesValue;
	}
	public void setCurrentOrderValue(int currentOrderValue) {
		this.currentOrderValue = currentOrderValue;
	}
	public void setWalletAmount(double walletAmount) {
		this.walletAmount = walletAmount;
	}
	public void setStatusRequest(String statusRequest) {
		this.statusRequest = statusRequest;
	}
	@Override
	public String toString() {
		return "WalletView [id=" + id + ", walletId=" + walletId + ", kisanSathiName=" + kisanSathiName
				+ ", nodalCenterId=" + nodalCenterId + ", salesValue=" + salesValue + ", currentOrderValue="
				+ currentOrderValue + ", walletAmount=" + walletAmount + ", statusRequest=" + statusRequest + "]";
	}
}