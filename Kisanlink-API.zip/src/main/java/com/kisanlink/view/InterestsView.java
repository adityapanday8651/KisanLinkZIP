package com.kisanlink.view;

public class InterestsView {
	private String id;
	private String interestId;
	private String interestIn;
	
	public String getId() {
		return id;
	}
	public String getInterestId() {
		return interestId;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setInterestId(String interestId) {
		this.interestId = interestId;
	}
	public String getInterestIn() {
		return interestIn;
	}
	public void setInterestIn(String interestIn) {
		this.interestIn = interestIn;
	}
	@Override
	public String toString() {
		return "InterestsView [id=" + id + ", interestId=" + interestId + ", interestIn=" + interestIn + "]";
	}
}
