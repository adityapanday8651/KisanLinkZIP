package com.kisanlink.view;

public class StateView {
	private String id;
	private int stateId;
	private String name;
	
	public String getId() {
		return id;
	}
	public int getStateId() {
		return stateId;
	}
	public String getName() {
		return name;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setStateId(int stateId) {
		this.stateId = stateId;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "StateView [id=" + id + ", stateId=" + stateId + ", name=" + name + "]";
	}
}
