package com.kisanlink.view;

import java.util.HashSet;
import java.util.Set;

import org.springframework.data.mongodb.core.mapping.DBRef;

import com.kisanlink.mongo.BankDetails;
import com.kisanlink.mongo.PersonalDetails;

public class UserView {

	private String id;
	private String locality;
	private String landmark;
	private String city;
	private String state;
	private int kisanSathiId;
	private String firstName;
	private String lastName;
	private long mobileNumber;
	private String password;
	private String address;
	private double longitude;
	private double latitude;
	private String image;
	private String nodalCentre;
	private String areaManagerId;
	private String areaManagerName;
	private int salesCompleted;
	private String currentOrders;
	private String coursesCompleted;
	private String status;
	private String actions;
	private String userType;
	private String username;
	private String referralCode;
	private String email;
	private String pin;
	private String agricenterId;
	private String agricenterName;
	@DBRef
	private Set<String> roles = new HashSet<>();
	private PersonalDetails details;
	private BankDetails bankDetails;
	private String pincode;

	public String getAgricenterId() {
		return agricenterId;
	}
	public void setAgricenterId(String agricenterId) {
		this.agricenterId = agricenterId;
	}
	public String getAgricenterName() {
		return agricenterName;
	}
	public void setAgricenterName(String agricenterName) {
		this.agricenterName = agricenterName;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public PersonalDetails getDetails() {
		return details;
	}
	public void setDetails(PersonalDetails details) {
		this.details = details;
	}
	public BankDetails getBankDetails() {
		return bankDetails;
	}
	public void setBankDetails(BankDetails bankDetails) {
		this.bankDetails = bankDetails;
	}
	public String getLocality() {
		return locality;
	}
	public void setLocality(String locality) {
		this.locality = locality;
	}
	public String getLandmark() {
		return landmark;
	}
	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	public String getReferralCode() {
		return referralCode;
	}
	public void setReferralCode(String referralCode) {
		this.referralCode = referralCode;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getKisanSathiId() {
		return kisanSathiId;
	}
	public void setKisanSathiId(int kisanSathiId) {
		this.kisanSathiId = kisanSathiId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getLongitude() {
		return longitude;
	}
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	public double getLatitude() {
		return latitude;
	}
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getNodalCentre() {
		return nodalCentre;
	}
	public void setNodalCentre(String nodalCentre) {
		this.nodalCentre = nodalCentre;
	}
	public String getAreaManagerId() {
		return areaManagerId;
	}
	public void setAreaManagerId(String areaManagerId) {
		this.areaManagerId = areaManagerId;
	}
	public String getAreaManagerName() {
		return areaManagerName;
	}
	public void setAreaManagerName(String areaManagerName) {
		this.areaManagerName = areaManagerName;
	}
	public int getSalesCompleted() {
		return salesCompleted;
	}
	public void setSalesCompleted(int salesCompleted) {
		this.salesCompleted = salesCompleted;
	}
	public String getCurrentOrders() {
		return currentOrders;
	}
	public void setCurrentOrders(String currentOrders) {
		this.currentOrders = currentOrders;
	}
	public String getCoursesCompleted() {
		return coursesCompleted;
	}
	public void setCoursesCompleted(String coursesCompleted) {
		this.coursesCompleted = coursesCompleted;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getActions() {
		return actions;
	}
	public void setActions(String actions) {
		this.actions = actions;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Set<String> getRoles() {
		return roles;
	}
	public void setRoles(Set<String> roles) {
		this.roles = roles;
	}
	@Override
	public String toString() {
		return "UserView [id=" + id + ", locality=" + locality + ", landmark=" + landmark + ", city=" + city
				+ ", state=" + state + ", kisanSathiId=" + kisanSathiId + ", firstName=" + firstName + ", lastName="
				+ lastName + ", mobileNumber=" + mobileNumber + ", password=" + password + ", address=" + address
				+ ", longitude=" + longitude + ", latitude=" + latitude + ", image=" + image + ", nodalCentre="
				+ nodalCentre + ", areaManagerId=" + areaManagerId + ", areaManagerName=" + areaManagerName
				+ ", salesCompleted=" + salesCompleted + ", currentOrders=" + currentOrders + ", coursesCompleted="
				+ coursesCompleted + ", status=" + status + ", actions=" + actions + ", userType=" + userType
				+ ", username=" + username + ", referralCode=" + referralCode + ", email=" + email + ", pin=" + pin
				+ ", agricenterId=" + agricenterId + ", agricenterName=" + agricenterName + ", roles=" + roles
				+ ", details=" + details + ", bankDetails=" + bankDetails + ", pincode=" + pincode + "]";
	}
}