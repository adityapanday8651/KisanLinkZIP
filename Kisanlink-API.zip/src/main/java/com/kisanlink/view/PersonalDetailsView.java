package com.kisanlink.view;

public class PersonalDetailsView {
	private String id;
	 private String aadharcard;
	 private String pancard;
	 private String userId;
	 private String name;
	public String getId() {
		return id;
	}
	public String getAadharcard() {
		return aadharcard;
	}
	public String getPancard() {
		return pancard;
	}
	public String getUserId() {
		return userId;
	}
	public String getName() {
		return name;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setAadharcard(String aadharcard) {
		this.aadharcard = aadharcard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "PersonalDetailsView [id=" + id + ", aadharcard=" + aadharcard + ", pancard=" + pancard + ", userId="
				+ userId + ", name=" + name + "]";
	} 
}
