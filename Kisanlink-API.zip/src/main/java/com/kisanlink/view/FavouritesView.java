package com.kisanlink.view;

public class FavouritesView {
	private String favId;
	private String farmerId;
	private String mobileNumber;
	private String status;
	public String getFavId() {
		return favId;
	}
	public void setFavId(String favId) {
		this.favId = favId;
	}
	public String getFarmerId() {
		return farmerId;
	}
	public void setFarmerId(String farmerId) {
		this.farmerId = farmerId;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "Favourites [favId=" + favId + ", farmerId=" + farmerId + ", mobileNumber=" + mobileNumber + ", status="
				+ status + "]";
	}
	 
	
}
