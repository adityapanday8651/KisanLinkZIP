package com.kisanlink.view;

public class RewardsEarnedView {
	private String id;
	private String referralCode;
	private String earnMoney;
	
	public String getId() {
		return id;
	}
	public String getReferralCode() {
		return referralCode;
	}
	public String getEarnMoney() {
		return earnMoney;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setReferralCode(String referralCode) {
		this.referralCode = referralCode;
	}
	public void setEarnMoney(String earnMoney) {
		this.earnMoney = earnMoney;
	}
	@Override
	public String toString() {
		return "RewardsEarnedView [id=" + id + ", referralCode=" + referralCode + ", earnMoney=" + earnMoney + "]";
	}
}