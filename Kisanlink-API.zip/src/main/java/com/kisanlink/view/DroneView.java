package com.kisanlink.view;

public class DroneView {
	private String id;
	private long droneId;  
	private String name;
	private String address;
	private double pricePerAcre;
	private String areaCentre;
	private String minimumCoverage;
	private String contactPerson;
	private String contactNumber;
	private String fertiliserSpraying;
	private String pesticideSpraying;
	private double incentivePerAcre;
	public String getId() {
		return id;
	}
	public long getDroneId() {
		return droneId;
	}
	public String getName() {
		return name;
	}
	public String getAddress() {
		return address;
	}
	public double getPricePerAcre() {
		return pricePerAcre;
	}
	public String getAreaCentre() {
		return areaCentre;
	}
	public String getMinimumCoverage() {
		return minimumCoverage;
	}
	public String getContactPerson() {
		return contactPerson;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public String getFertiliserSpraying() {
		return fertiliserSpraying;
	}
	public String getPesticideSpraying() {
		return pesticideSpraying;
	}
	public double getIncentivePerAcre() {
		return incentivePerAcre;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setDroneId(long droneId) {
		this.droneId = droneId;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public void setPricePerAcre(double pricePerAcre) {
		this.pricePerAcre = pricePerAcre;
	}
	public void setAreaCentre(String areaCentre) {
		this.areaCentre = areaCentre;
	}
	public void setMinimumCoverage(String minimumCoverage) {
		this.minimumCoverage = minimumCoverage;
	}
	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public void setFertiliserSpraying(String fertiliserSpraying) {
		this.fertiliserSpraying = fertiliserSpraying;
	}
	public void setPesticideSpraying(String pesticideSpraying) {
		this.pesticideSpraying = pesticideSpraying;
	}
	public void setIncentivePerAcre(double incentivePerAcre) {
		this.incentivePerAcre = incentivePerAcre;
	}
	@Override
	public String toString() {
		return "DroneView [id=" + id + ", droneId=" + droneId + ", name=" + name + ", address=" + address
				+ ", pricePerAcre=" + pricePerAcre + ", areaCentre=" + areaCentre + ", minimumCoverage="
				+ minimumCoverage + ", contactPerson=" + contactPerson + ", contactNumber=" + contactNumber
				+ ", fertiliserSpraying=" + fertiliserSpraying + ", pesticideSpraying=" + pesticideSpraying
				+ ", incentivePerAcre=" + incentivePerAcre + "]";
	}
}
