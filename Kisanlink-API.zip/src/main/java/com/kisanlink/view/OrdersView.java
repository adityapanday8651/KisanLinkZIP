package com.kisanlink.view;

import javax.xml.datatype.XMLGregorianCalendar;

public class OrdersView {
	private String id;
	private int orderId;
	private String orderNo;
	private String orderStatus;
	private String orderDate;
	private String image;
	private String productName;
	private int quantity;
	private double totalAmount;
	private String createdBy;
	private XMLGregorianCalendar createdAt;
	private String modifiedBy;
	private XMLGregorianCalendar modifiedAt;
	private String createdByUser;
	private String modifiedByUser;
	private String farmerName;
	private int farmerId;
	private String location;
	private long mobileNumber;
	
	public String getFarmerName() {
		return farmerName;
	}
	public void setFarmerName(String farmerName) {
		this.farmerName = farmerName;
	}
	public int getFarmerId() {
		return farmerId;
	}
	public void setFarmerId(int farmerId) {
		this.farmerId = farmerId;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public XMLGregorianCalendar getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(XMLGregorianCalendar createdAt) {
		this.createdAt = createdAt;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public XMLGregorianCalendar getModifiedAt() {
		return modifiedAt;
	}
	public void setModifiedAt(XMLGregorianCalendar modifiedAt) {
		this.modifiedAt = modifiedAt;
	}
	public String getCreatedByUser() {
		return createdByUser;
	}
	public void setCreatedByUser(String createdByUser) {
		this.createdByUser = createdByUser;
	}
	public String getModifiedByUser() {
		return modifiedByUser;
	}
	public void setModifiedByUser(String modifiedByUser) {
		this.modifiedByUser = modifiedByUser;
	}
	public String getId() {
		return id;
	}
	public int getOrderId() {
		return orderId;
	}
	public String getOrderNo() {
		return orderNo;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public String getImage() {
		return image;
	}
	public String getProductName() {
		return productName;
	}
	public int getQuantity() {
		return quantity;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	@Override
	public String toString() {
		return "OrdersView [id=" + id + ", orderId=" + orderId + ", orderNo=" + orderNo + ", orderStatus=" + orderStatus
				+ ", orderDate=" + orderDate + ", image=" + image + ", productName=" + productName + ", quantity="
				+ quantity + ", totalAmount=" + totalAmount + ", createdBy=" + createdBy + ", createdAt=" + createdAt
				+ ", modifiedBy=" + modifiedBy + ", modifiedAt=" + modifiedAt + ", createdByUser=" + createdByUser
				+ ", modifiedByUser=" + modifiedByUser + "]";
	}
}
