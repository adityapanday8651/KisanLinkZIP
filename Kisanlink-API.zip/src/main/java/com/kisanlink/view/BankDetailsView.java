package com.kisanlink.view;

public class BankDetailsView {
	private String id;
	private String bankName;
	private String accountHolderName;
	private String accountNumber;
	private String ifscCode;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	@Override
	public String toString() {
		return "BankDetailsView [id=" + id + ", bankName=" + bankName + ", accountHolderName=" + accountHolderName
				+ ", accountNumber=" + accountNumber + ", ifscCode=" + ifscCode + "]";
	}

	 
}
