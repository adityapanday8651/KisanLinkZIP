package com.kisanlink.view;

public class ServiceProviderView {
	private String id;
	private String farmerId;
	private String farmerName;
	private String farmAreaImage;
	private String date;
	private String acresSprayed;
	private double amount;
	private String productSupply;
	
	public String getId() {
		return id;
	}
	public String getFarmerId() {
		return farmerId;
	}
	public String getFarmerName() {
		return farmerName;
	}
	public String getFarmAreaImage() {
		return farmAreaImage;
	}
	public String getDate() {
		return date;
	}
	public String getAcresSprayed() {
		return acresSprayed;
	}
	public double getAmount() {
		return amount;
	}
	public String getProductSupply() {
		return productSupply;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setFarmerId(String farmerId) {
		this.farmerId = farmerId;
	}
	public void setFarmerName(String farmerName) {
		this.farmerName = farmerName;
	}
	public void setFarmAreaImage(String farmAreaImage) {
		this.farmAreaImage = farmAreaImage;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public void setAcresSprayed(String acresSprayed) {
		this.acresSprayed = acresSprayed;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public void setProductSupply(String productSupply) {
		this.productSupply = productSupply;
	}
	@Override
	public String toString() {
		return "ServiceProviderView [id=" + id + ", farmerId=" + farmerId + ", farmerName=" + farmerName
				+ ", farmAreaImage=" + farmAreaImage + ", date=" + date + ", acresSprayed=" + acresSprayed + ", amount="
				+ amount + ", productSupply=" + productSupply + "]";
	}
}
