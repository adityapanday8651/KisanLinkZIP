package com.kisanlink.view;

import java.util.Date;

public class OTPDetailsView {
	private String id;
	private long mobileNumber;
	private Date createdDate;
	private String otp;

	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	@Override
	public String toString() {
		return "OTPDetails [id=" + id + ", mobileNumber=" + mobileNumber + ", createdDate=" + createdDate + ", otp="
				+ otp + "]";
	}
}
