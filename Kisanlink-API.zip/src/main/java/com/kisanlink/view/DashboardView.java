package com.kisanlink.view;

public class DashboardView {
	private String id;
	private long kisanSathis;
	private long farmers;
	private long Collaborators;
	private long nodalCentres;
	private long franchiseCentres;
	private long currentOrders;
	private double salesValue;
	private long completedOrders;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public long getKisanSathis() {
		return kisanSathis;
	}
	public void setKisanSathis(long kisanSathis) {
		this.kisanSathis = kisanSathis;
	}
	public long getFarmers() {
		return farmers;
	}
	public void setFarmers(long farmers) {
		this.farmers = farmers;
	}
	public long getCollaborators() {
		return Collaborators;
	}
	public void setCollaborators(long collaborators) {
		Collaborators = collaborators;
	}
	public long getNodalCentres() {
		return nodalCentres;
	}
	public void setNodalCentres(long nodalCentres) {
		this.nodalCentres = nodalCentres;
	}
	public long getFranchiseCentres() {
		return franchiseCentres;
	}
	public void setFranchiseCentres(long franchiseCentres) {
		this.franchiseCentres = franchiseCentres;
	}
	public long getCurrentOrders() {
		return currentOrders;
	}
	public void setCurrentOrders(long currentOrders) {
		this.currentOrders = currentOrders;
	}
	public double getSalesValue() {
		return salesValue;
	}
	public void setSalesValue(double salesValue) {
		this.salesValue = salesValue;
	}
	public long getCompletedOrders() {
		return completedOrders;
	}
	public void setCompletedOrders(long completedOrders) {
		this.completedOrders = completedOrders;
	}
	@Override
	public String toString() {
		return "Dashboard [id=" + id + ", kisanSathis=" + kisanSathis + ", farmers=" + farmers + ", Collaborators="
				+ Collaborators + ", nodalCentres=" + nodalCentres + ", franchiseCentres=" + franchiseCentres
				+ ", currentOrders=" + currentOrders + ", salesValue=" + salesValue + ", completedOrders="
				+ completedOrders + "]";
	}

}
