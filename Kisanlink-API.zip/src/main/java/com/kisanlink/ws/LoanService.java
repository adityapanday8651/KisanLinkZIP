package com.kisanlink.ws;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.mongo.Loan;
import com.kisanlink.mongo.manager.LoanManager;
import com.kisanlink.service.core.GenericSearchRepository;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.LoanView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping("/loan")
public class LoanService extends GenericService{
	private static VCLogger logger = VCLogManager.getLogger(LoanService.class);

	@Autowired LoanManager loanManager;
	@Autowired GenericSearchRepository searchRepository;

	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> saveLoan(@RequestBody LoanView view, HttpServletRequest request){
		logger.info("loan save service call started - {0}", new Date());
		ResponseView res=new ResponseView();

		Loan loan = null;
		try {
			loan = loanManager.findByFarmerId(view.getFarmerId());
			if(loan==null) {
				loan = new Loan();
				BeanUtils.copyProperties(view, loan);
				DateUtils.setBaseData(loan, "System");
				res.setMessage("Loan added successfully");
				res.setStatus(true);
			}else{
				BeanUtils.copyProperties(view, loan,"id");
				DateUtils.setModifiedBaseData(loan, "System");
				res.setMessage("Loan updated successfully");
			}
			res.setStatus(true);
			loanManager.save(loan);
		}catch(Exception e) {
			logger.error("Exception while loan save info - {0}", e, e.getMessage());
			res.setMessage("Saving Loan Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("loan save service call completed - {0}", new Date());
		return toSuccess(res);
	}
	
	@GetMapping(value="/list", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getAllLoans(){
		List<Loan> list=loanManager.findAll();
		return toSuccess(new ListResponseView(list.size(), list));
	}
	
	@GetMapping(value="/find/{farmerId}", produces=MediaType.APPLICATION_JSON_VALUE)
	public Loan findLoanByFarmerId(@PathVariable("farmerId") String farmerId) {
		return loanManager.findByFarmerId(farmerId);
	}
	
	@SuppressWarnings("unchecked")
	@PostMapping(value="/search", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> searchLoan(@RequestBody SearchRequest searchRequest){
		List<Loan> searchLoan=(List<Loan>) searchRepository.search(searchRequest, Loan.class);
		return toSuccess(new ListResponseView(searchLoan.size(), searchLoan));	
	}
}
