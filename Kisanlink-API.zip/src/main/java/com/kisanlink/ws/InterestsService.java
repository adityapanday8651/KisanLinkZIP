package com.kisanlink.ws;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.mongo.Interests;
import com.kisanlink.mongo.manager.InterestsManager;
import com.kisanlink.service.core.GenericSearchRepository;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.InterestsView;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(path="/interests")
public class InterestsService extends GenericService{
	private static VCLogger logger = VCLogManager.getLogger(InterestsService.class);
	
	@Autowired InterestsManager interestsManager;
	@Autowired GenericSearchRepository searchRepository;
	

	String methodName=null;

	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> saveInterests(@RequestBody InterestsView view, HttpServletRequest request){
		logger.info("interests save service call started - {0}", new Date());
		ResponseView res=new ResponseView();
		Interests interests = null;
		try {

			interests = interestsManager.findByInterestId(view.getInterestId());
			if(interests==null) {
				interests = new Interests();
				BeanUtils.copyProperties(view, interests);
				DateUtils.setBaseData(interests, "System");
				res.setMessage("Interests added successfully");
				res.setStatus(true);
			}else{
				BeanUtils.copyProperties(view, interests,"id");
				DateUtils.setModifiedBaseData(interests, "System");
				res.setMessage("Interests updated successfully");
			}
			res.setStatus(true);
			interestsManager.save(interests);
		}catch(Exception e) {
			logger.error("Exception while interests save info - {0}", e, e.getMessage());
			res.setMessage("Saving Interests Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("interests save service call completed - {0}", new Date());
		return toSuccess(res);
	}
	
	@SuppressWarnings("unchecked")
	@PostMapping(value="/search", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> searchInterestIn(@RequestBody SearchRequest searchRequest){
		List<Interests> searchInterests=(List<Interests>) searchRepository.search(searchRequest, Interests.class);
		return toSuccess(new ListResponseView(searchInterests.size(), searchInterests));	
	}
	
	@GetMapping(value="/list", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getAllInterests(){
		List<Interests> list=interestsManager.findAll();
		return toSuccess(new ListResponseView(list.size(), list));
	}
	
	@GetMapping(value="/find/{interestId}", produces=MediaType.APPLICATION_JSON_VALUE)
	public Interests findInterestsByInterestsId(@PathVariable("interestId") String interestId) {
		return interestsManager.findByInterestId(interestId);
	}
	
}
