package com.kisanlink.ws;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.mongo.Dashboard;
import com.kisanlink.mongo.manager.DashboardManager;
import com.kisanlink.util.APIEndpoints;

@RestController
@RequestMapping(path=APIEndpoints.BASE_API_URL_V1+"/dashboard")
public class DashboardService extends GenericService {
	
	@Autowired DashboardManager dashboardManager;

	private static VCLogger logger = VCLogManager.getLogger(DashboardService.class);

	@CrossOrigin
	@GetMapping(value = "/data", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> dashboard() throws ServiceException {
		Dashboard dash = dashboardManager.findOne();
		return toSuccess(dash);
	}
}
