package com.kisanlink.ws;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.mongo.ServiceProvider;
import com.kisanlink.mongo.manager.ServiceProviderManager;
import com.kisanlink.service.core.GenericSearchRepository;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;
import com.kisanlink.view.ServiceProviderView;

@RestController
@RequestMapping(path="/serviceProvider")
public class ServiceProviderService extends GenericService{
	private static VCLogger logger = VCLogManager.getLogger(ServiceProviderService.class);
	
	@Autowired ServiceProviderManager serviceProviderManager;
	@Autowired GenericSearchRepository searchRepository;
	
	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> saveServiceProvider(@RequestBody ServiceProviderView view, HttpServletRequest request){
		logger.info("serviceProvider save service call started - {0}", new Date());
		ResponseView res=new ResponseView();
		
		ServiceProvider serviceProvider = null;
		try {
			//products = productsManager.findByProductName(view.getId());
			serviceProvider =serviceProviderManager.findByFarmerId(view.getFarmerId());
			if(serviceProvider==null) {
				serviceProvider = new ServiceProvider();
				BeanUtils.copyProperties(view, serviceProvider);
				DateUtils.setBaseData(serviceProvider, "System");
				res.setMessage("ServiceProvider added successfully");
				res.setStatus(true);
			}else{
				BeanUtils.copyProperties(view, serviceProvider,"id");
				DateUtils.setModifiedBaseData(serviceProvider, "System");
				res.setMessage("ServiceProvider updated successfully");
			}
			res.setStatus(true);
			serviceProviderManager.save(serviceProvider);
		}catch(Exception e) {
			logger.error("Exception while serviceProvider save info - {0}", e, e.getMessage());
			res.setMessage("ServiceProvider products Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("serviceProvider save service call completed - {0}", new Date());
		return toSuccess(res);
	}
	
	@GetMapping(value="/list", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getAllServiceProvider(){
		List<ServiceProvider> list=serviceProviderManager.findAll();
		return toSuccess(new ListResponseView(list.size(), list));
	}
	
	@SuppressWarnings("unchecked")
	@PostMapping(value="/search", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> searchServiceProvider(@RequestBody SearchRequest searchRequest){
		List<ServiceProvider> serviceProvider=(List<ServiceProvider>) searchRepository.search(searchRequest, ServiceProvider.class);
		return toSuccess(new ListResponseView(serviceProvider.size(), serviceProvider));
	}

}
