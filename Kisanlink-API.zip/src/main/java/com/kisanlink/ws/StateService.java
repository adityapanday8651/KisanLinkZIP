package com.kisanlink.ws;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.State;
import com.kisanlink.mongo.manager.StateManager;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;
import com.kisanlink.view.StateView;

@RestController
@RequestMapping(path=APIEndpoints.BASE_API_URL_V1+"/state")
public class StateService extends GenericService{
	private static VCLogger logger = VCLogManager.getLogger(StateService.class);
	
	@Autowired StateManager stateManager;
	
	
	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> saveState(@RequestBody StateView view, HttpServletRequest request){
		logger.info("mostSelling save service call started - {0}", new Date());
		ResponseView res=new ResponseView();
		State state = null;
		try {
			state = stateManager.findByStateId(view.getStateId());
			if(state==null) {
				state = new State();
				BeanUtils.copyProperties(view, state);
				DateUtils.setBaseData(state, "System");
				res.setMessage("State added successfully");
				res.setStatus(true);
			}else{
				BeanUtils.copyProperties(view, state,"id");
				DateUtils.setModifiedBaseData(state, "System");
				res.setMessage("State updated successfully");
			}
			res.setStatus(true);
			stateManager.save(state);
		}catch(Exception e) {
			logger.error("Exception while state save info - {0}", e, e.getMessage());
			res.setMessage("Saving State Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("state save service call completed - {0}", new Date());
		return toSuccess(res);
	}
	
	@PostMapping(value="/list",produces= MediaType.APPLICATION_JSON_VALUE)
	ResponseEntity<Message> searchState(@RequestBody SearchRequest searchRequest, HttpServletRequest request)
	{
		List<State> list = stateManager.search(searchRequest);
		long count = stateManager.searchCount(searchRequest);
		List<StateView> views = new ArrayList<>();
		for(State state:list)
		{
			StateView view = new StateView();
			BeanUtils.copyProperties(state, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(count, views));
	}	
}
