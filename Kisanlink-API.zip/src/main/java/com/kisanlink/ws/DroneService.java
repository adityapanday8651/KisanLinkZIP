package com.kisanlink.ws;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.AllIdConfiguration;
import com.kisanlink.mongo.Drone;
import com.kisanlink.mongo.manager.AllIdConfigurationManager;
import com.kisanlink.mongo.manager.DroneManager;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.DroneView;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(path=APIEndpoints.BASE_API_URL_V1+"/drone")
public class DroneService extends GenericService {
	@Autowired DroneManager droneManager;
	@Autowired AllIdConfigurationManager allIdConfigurationManager;
	private static VCLogger logger = VCLogManager.getLogger(DroneService.class);
	String methodName=null;
	String apiUrl="kisanlink"+APIEndpoints.BASE_API_URL_V1+"/drone";
	@PostMapping(value="/save", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> save(@RequestBody DroneView view, HttpServletRequest request)
	{
		logger.info("drone save service call started - {0}", new Date());
		ResponseView res = new ResponseView();
		Drone drone = null;
		try {
			AllIdConfiguration config = allIdConfigurationManager.findByName("droneApplication");
			drone = droneManager.findByid(view.getId());
			if(drone==null)
			{
				drone = new Drone();
				BeanUtils.copyProperties(view, drone);
				DateUtils.setBaseData(drone, "System");
				res.setMessage("drone save successfully");
			}
			else
			{
				BeanUtils.copyProperties(view, drone, "id");
				DateUtils.setModifiedBaseData(drone, "System");
				res.setMessage("drone updated successfully");
			}
			
			if(config==null) {
				config=new AllIdConfiguration();
				config.setLastGeneratedId(90000);
				drone.setDroneId(config.getLastGeneratedId());
				DateUtils.setBaseData(config, "System");
			}else {
				drone.setDroneId(config.getLastGeneratedId()+1);
				config.setLastGeneratedId(config.getLastGeneratedId()+1);
				DateUtils.setModifiedBaseData(config, "System");
			}
			res.setStatus(true);
			allIdConfigurationManager.save(config);
			droneManager.save(drone);
		}catch(Exception e)
		{
			logger.error("Exception while saving drone info - {0}", e, e.getMessage());
			res.setMessage("drone save failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("drone save service call completed - {0}", new Date());
		return toSuccess(res);

	}

	@PostMapping(value="/list", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> list(@RequestBody SearchRequest request)
	{
		List<Drone> list = droneManager.search(request);
		long count = droneManager.searchCount(request);
		List<DroneView> views = new ArrayList<>();
		for(Drone drone : list)
		{
			DroneView view = new DroneView();
			BeanUtils.copyProperties(drone, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(count, views));

	}
}
