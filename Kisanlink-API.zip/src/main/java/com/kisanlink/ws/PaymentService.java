package com.kisanlink.ws;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.AllIdConfiguration;
import com.kisanlink.mongo.Payment;
import com.kisanlink.mongo.manager.AllIdConfigurationManager;
import com.kisanlink.mongo.manager.PaymentManager;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.PaymentView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(value=APIEndpoints.BASE_API_URL_V1+"/payment")
public class PaymentService extends GenericService {
	@Autowired PaymentManager paymentmanager;
	@Autowired AllIdConfigurationManager allIdConfigurationManager;
	private static VCLogger logger = VCLogManager.getLogger(PaymentService.class);
	String mehodName = null;
	String apiUrl = "kisanlink"+APIEndpoints.BASE_API_URL_V1+"/payment";
	
	@PostMapping(value="/save")
	public ResponseEntity<Object> save(@RequestBody PaymentView view, HttpServletRequest request)
	{
		logger.info("payment service call started - {0}", new Date());
		ResponseView res = new ResponseView();
		Payment payment = null;
		try {
			payment = paymentmanager.findByid(view.getId());
			AllIdConfiguration config=allIdConfigurationManager.findByName("payment");
			if(payment==null)
			{
				payment = new Payment();
				BeanUtils.copyProperties(view, payment);
				DateUtils.setBaseData(payment, "System");
				res.setMessage("payment saved successfully");
			}
			else
			{
				BeanUtils.copyProperties(view, payment, "id");
				DateUtils.setModifiedBaseData(payment, "Ssytem");
				res.setMessage("payment update successfully");
			}
			int i=1;
			if(config==null) {
				config = new AllIdConfiguration();
				config.setLastGeneratedId(40000);
				payment.setPaymentId(config.getLastGeneratedId());
				DateUtils.setBaseData(config, "System");
			}else {
				payment.setPaymentId(config.getLastGeneratedId()+i);
				config.setLastGeneratedId(config.getLastGeneratedId()+i);
				DateUtils.setModifiedBaseData(config, "System");
			}
			res.setStatus(true);
			allIdConfigurationManager.save(config);
			paymentmanager.save(payment);
		}
		catch(Exception e)
		{
			logger.error("Exception while saving payment info - {0}", e, e.getMessage());
			res.setMessage("payment saving failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("payment service call completed - {0}", new Date());
		return toSuccess(res);

	}

	@PostMapping(value="/list", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> list(@RequestBody SearchRequest request)
	{
		List<PaymentView> views = new ArrayList<>();
		List<Payment> list = paymentmanager.search(request);
		long count = paymentmanager.searchCount(request);
		for(Payment payment: list)
		{
			PaymentView view = new PaymentView();
			BeanUtils.copyProperties(payment, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(count, views));

	}
}

