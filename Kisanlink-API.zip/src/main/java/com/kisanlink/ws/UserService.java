package com.kisanlink.ws;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.http.HttpUtil;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.BankDetails;
import com.kisanlink.mongo.User;
import com.kisanlink.mongo.manager.BankDetailsManager;
import com.kisanlink.mongo.manager.ConfigurationManager;
import com.kisanlink.mongo.manager.OTPDetailsManager;
import com.kisanlink.mongo.manager.UserManager;
import com.kisanlink.mongo.repository.UserRepository;
import com.kisanlink.service.core.GenericSearchRepository;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.Constants1;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.BankDetailsView;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;
import com.kisanlink.view.UserView;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(path=APIEndpoints.BASE_API_URL_V1+"/user")
public class UserService extends GenericService {
	private static VCLogger logger = VCLogManager.getLogger(UserService.class);

	@Autowired UserManager userManager;
	@Autowired ConfigurationManager configurationManager;
	@Autowired OTPDetailsManager otpManager;
	@Autowired HttpUtil util;
	@Autowired BankDetailsManager bankDetailsManager;
	@Autowired GenericSearchRepository searchRepository;
	@Autowired UserRepository userRepository;


	@GetMapping(value = "/user/info/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> sendUserInfo(@PathVariable("id") String id) {
		logger.info("send user info service call started - {0}", new Date());
		User user = userManager.findByMobileNumber(Long.parseLong(id));
		UserView view = new UserView();
		BeanUtils.copyProperties(user, view);
		logger.info("send user info service call completed - {0}", new Date());
		return toSucess(view);
	}

	@GetMapping(value = "/info")
	public ResponseEntity<Object> getUserInfo() {
		logger.info("get user info service call started - {0}", new Date());
		UserView userView=null;
		User user = userManager.findByMobileNumber(Long.parseLong(getLoggedInUserName()));
		if(user!=null) {
			userView=new UserView();
			BeanUtils.copyProperties(user, userView,"password","passCode","userId","focusId");
			//userView.setUserId(user.getId());
		}
		logger.info("get user info service call completed - {0}", new Date());
		return toSuccess(userView);
	}

	@CrossOrigin
	@PostMapping(value = "/list", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> getAll(@RequestBody SearchRequest searchRequest) {
		List<UserView> views = new ArrayList<>();
		List<User> userList = userManager.search(searchRequest);
		long count = userManager.searchCount(searchRequest);
		for(User user : userList) {
			UserView view = new UserView();
			BeanUtils.copyProperties(user, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(count, views));
	}

	@PostMapping(value="/update", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> userSave(@RequestBody UserView view, HttpServletRequest request){
		logger.info("updaye user service call started - {0}", new Date());
		ResponseView res = new ResponseView();
		if(view.getUsername() == null || view.getUsername().equalsIgnoreCase("")) {
			res.setMessage("Bad Request");
			res.setStatus(false);
			return toError400(res);
		}
		Optional<User> user = Optional.empty();
		User usr = null;
		try {
			user = userRepository.findByUsername(view.getUsername());
			if(user.isPresent()) {
				usr = user.get();
			}else {
				res.setMessage("Bad Request");
				res.setStatus(false);
				return toError400(res);
			}

			BeanUtils.copyProperties(view, usr, Constants1.PASSWORD, Constants1.USER_ID, Constants1.KISANSATHIID, Constants1.USERNAME,
					Constants1.MOBILENUMBER, Constants1.REFERRALCODE, Constants1.USERTYPE, Constants1.ROLES, Constants1.PIN);
			res.setMessage("User updated successfully");
			res.setStatus(true);
			userManager.save(usr);
		} catch (Exception e) {
			logger.error("Exception while register user info - {0}", e, e.getMessage());
			res.setMessage("User update failed");
			res.setStatus(false);
			return toError500(res);
		}
		logger.info("update user service call completed - {0}", new Date());
		return toSucessCreate(res);
	}

	@PostMapping(value="/areamanager", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> areaManagerUpdate(@RequestBody UserView view){
		logger.info("updaye user service call started - {0}", new Date());
		ResponseView res = new ResponseView();
		try {
			User user = userManager.findByKisanSathiId(view.getKisanSathiId());
			user.setAreaManagerId(view.getAreaManagerId());
			user.setAreaManagerName(user.getAreaManagerName());
			res.setMessage("User updated successfully");
			res.setStatus(true);
			userManager.save(user);
		} catch (Exception e) {
			logger.error("Exception while register user info - {0}", e, e.getMessage());
			res.setMessage("User update failed");
			res.setStatus(false);
			return toError500(res);
		}
		logger.info("update user service call completed - {0}", new Date());
		return toSucessCreate(res);
	}

	@PostMapping(value="/bankSave", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> groundSave(@RequestBody BankDetailsView view, HttpServletRequest request){
		logger.info("bankDetails save service call started - {0}", new Date());
		ResponseView res = new ResponseView();
		Optional<BankDetails> bankDetails = null;
		BankDetails details = null;
		try {
			bankDetails = bankDetailsManager.findById(view.getId());
			if(bankDetails.isPresent()) {
				details = bankDetails.get();
			}
			if(details==null) {
				details = new BankDetails();
				BeanUtils.copyProperties(view, details);
				DateUtils.setBaseData(details, "System");
				res.setMessage("bank details  added successfully");
			}else{
				BeanUtils.copyProperties(view, details,"id");
				DateUtils.setModifiedBaseData(details, "System");
				res.setMessage("bank details updated successfully");
			}
			res.setStatus(true);
			bankDetailsManager.save(details);
		}catch(Exception e) {
			logger.error("Exception while bank details save info - {0}", e, e.getMessage());
			res.setMessage("Saving bankDetails Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("bank details save service call completed - {0}", new Date());
		return toSuccess(res);
	}

	@CrossOrigin
	@PostMapping(value = "/bankList", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> getAllBankList(@RequestBody SearchRequest searchRequest) {
		List<BankDetailsView> views = new ArrayList<>();
		List<BankDetails> bankList = bankDetailsManager.search(searchRequest);
		long count = bankDetailsManager.searchCount(searchRequest);
		for(BankDetails bankDetails : bankList) {
			BankDetailsView view = new BankDetailsView();
			BeanUtils.copyProperties(bankDetails, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(count, views));
	}


	@GetMapping(value = "/info/{id}")
	@ApiOperation(value="This API is to get user profile information", 
	notes="Mandatory fields - NA",
	response = User.class)
	public ResponseEntity<Object> getUserInfo(@PathVariable("id") String id) {	
		Optional<User> user = userRepository.findByUsername(id);
		logger.info("End getUserInfo - {0}", new Date());
		return toSuccess(user);
	}
}