package com.kisanlink.ws;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.mongo.RewardsEarned;
import com.kisanlink.mongo.manager.RewardsEarnedManager;
import com.kisanlink.service.core.GenericSearchRepository;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;
import com.kisanlink.view.RewardsEarnedView;


@RestController
@RequestMapping(path="/rewardsEarned")
public class RewardsEarnedService extends GenericService{
	private static VCLogger logger = VCLogManager.getLogger(RewardsEarnedService.class);
	
	@Autowired RewardsEarnedManager rewardsEarnedManager;
	@Autowired GenericSearchRepository searchRepository;
	
	
	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> saveRewardsEarned(@RequestBody RewardsEarnedView view, HttpServletRequest request){
		logger.info("rewardsEarned save service call started - {0}", new Date());
		ResponseView res=new ResponseView();
		
		RewardsEarned rewardsEarned = null;
		try {
			
			rewardsEarned =rewardsEarnedManager.findByReferralCode(view.getReferralCode());
			if(rewardsEarned==null) {
				rewardsEarned = new RewardsEarned();
				BeanUtils.copyProperties(view, rewardsEarned);
				DateUtils.setBaseData(rewardsEarned, "System");
				res.setMessage("RewardsEarned added successfully");
				res.setStatus(true);
			}else{
				BeanUtils.copyProperties(view, rewardsEarned,"id");
				DateUtils.setModifiedBaseData(rewardsEarned, "System");
				res.setMessage("RewardsEarned updated successfully");
			}
			res.setStatus(true);
			rewardsEarnedManager.save(rewardsEarned);
		}catch(Exception e) {
			logger.error("Exception while rewardsEarned save info - {0}", e, e.getMessage());
			res.setMessage("RewardsEarned Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("rewardsEarned save service call completed - {0}", new Date());
		return toSuccess(res);
	}
	
	@SuppressWarnings("unchecked")
	@PostMapping(value="/search", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> searchRewardsEarned(@RequestBody SearchRequest searchRequest){
		List<RewardsEarned> searchrewardsEarned=(List<RewardsEarned>) searchRepository.search(searchRequest, RewardsEarned.class);
		return toSuccess(new ListResponseView(searchrewardsEarned.size(), searchrewardsEarned));	
	}
	
	@GetMapping(value="/list", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getAllRewardsEarned(){
		List<RewardsEarned> list=rewardsEarnedManager.findAll();
		return toSuccess(new ListResponseView(list.size(), list));
	}
}
