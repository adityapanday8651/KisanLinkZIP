package com.kisanlink.ws;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.FranchiseCentres;
import com.kisanlink.mongo.manager.FranchiseManager;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.FranchiseView;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(value=APIEndpoints.BASE_API_URL_V1+"/franchise")
public class FranchiseService extends GenericService {
	@Autowired FranchiseManager franchiseManager;
	private static VCLogger logger = VCLogManager.getLogger(NodalCentresService.class);
	String methodName=null;
	String apiUrl="kisanlink"+APIEndpoints.BASE_API_URL_V1+"/franchise";

	@PostMapping(value="/save", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> save(@RequestBody FranchiseView view, HttpServletRequest request)
	{
		logger.info("FranchiseCentres service call started - {0}", new Date());
		ResponseView res = new ResponseView();
		FranchiseCentres franchiseCentres = null;
		try {
			franchiseCentres = franchiseManager.findByid(view.getId());
			if(franchiseCentres==null)
			{
				franchiseCentres = new FranchiseCentres();
				BeanUtils.copyProperties(view, franchiseCentres);
				DateUtils.setBaseData(franchiseCentres, "System");
				res.setMessage("FranchiseCentres save successfully");
			}
			else
			{
				BeanUtils.copyProperties(view, franchiseCentres, "id");
				DateUtils.setModifiedBaseData(franchiseCentres, "Ssytem");
				res.setMessage("FranchiseCentres update successfully");
			}
			res.setStatus(true);
			franchiseManager.save(franchiseCentres);
		}
		catch(Exception e)
		{
			logger.error("Exception while saving FranchiseCentres info - {0}", e, e.getMessage());
			res.setMessage("FranchiseCentres saving failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("FranchiseCentres service call completed - {0}", new Date());
		return toSuccess(res);

	}

	@PostMapping(value="/list", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> list(@RequestBody SearchRequest request)
	{
		List<FranchiseView> views = new ArrayList<>();
		List<FranchiseCentres> list = franchiseManager.search(request);
		long count = franchiseManager.searchCount(request);
		for(FranchiseCentres franchiseCentres: list)
		{
			FranchiseView view = new FranchiseView();
			BeanUtils.copyProperties(franchiseCentres, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(count, views));

	}
}
