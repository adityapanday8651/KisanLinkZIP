package com.kisanlink.ws;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.AllIdConfiguration;
import com.kisanlink.mongo.Orders;
import com.kisanlink.mongo.manager.AllIdConfigurationManager;
import com.kisanlink.mongo.manager.OrdersManager;
import com.kisanlink.service.core.GenericSearchRepository;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.OrdersView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(path=APIEndpoints.BASE_API_URL_V1+"/orders")
public class OrdersService extends GenericService{
	private static VCLogger logger = VCLogManager.getLogger(OrdersService.class);
	@Autowired OrdersManager ordersManager;
	@Autowired GenericSearchRepository searchRepository;
	@Autowired AllIdConfigurationManager allIdConfigurationManager;

	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> userSave(@RequestBody OrdersView view, HttpServletRequest request){
		logger.info("Orders save service call started - {0}", new Date());
		ResponseView res=new ResponseView();
		Orders orders = null;
		try {
			orders = ordersManager.findByOrderId(view.getOrderId());

			AllIdConfiguration config=	allIdConfigurationManager.findByName("order");

			if(orders==null) {
				orders = new Orders();
				BeanUtils.copyProperties(view, orders);
				DateUtils.setBaseData(orders, getLoggedInUserName());
				orders.setOrderDate(new Date().toString());
				res.setMessage("Orders added successfully");
				res.setStatus(true);
			}else{
				BeanUtils.copyProperties(view, orders, "id");
				DateUtils.setModifiedBaseData(orders, getLoggedInUserName());
				res.setMessage("Orders updated successfully");
			}

			if(config==null) {
				config=new AllIdConfiguration();
				config.setLastGeneratedId(30000);
				orders.setOrderId(config.getLastGeneratedId());
				DateUtils.setBaseData(config, "System");
			}else {
				orders.setOrderId(config.getLastGeneratedId()+1);
				config.setLastGeneratedId(config.getLastGeneratedId()+1);
				DateUtils.setModifiedBaseData(config, "System");
			}

			allIdConfigurationManager.save(config);
			res.setStatus(true);
			ordersManager.save(orders);
		}catch(Exception e) {
			logger.error("Exception while orders save info - {0}", e, e.getMessage());
			res.setMessage("Saving Orders Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("Orders save service call completed - {0}", new Date());
		return toSuccess(res);
	}

	@PostMapping(value="/list",produces=MediaType.APPLICATION_JSON_VALUE)
	ResponseEntity<Message> searchOrders(@RequestBody SearchRequest searchRequest, HttpServletRequest request)
	{
		List<Orders> list = ordersManager.search(searchRequest);
		long count = ordersManager.searchCount(searchRequest);
		List<OrdersView> views = new ArrayList<>();
		for(Orders orders:list)
		{
			OrdersView view = new OrdersView();
			BeanUtils.copyProperties(orders, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(count, views));
	}	
}