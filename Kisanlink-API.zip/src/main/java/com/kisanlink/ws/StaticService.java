package com.kisanlink.ws;

import java.net.URLEncoder;
import java.util.Date;
import java.util.StringJoiner;

import org.apache.commons.lang.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.http.HttpRequest;
import com.kisanlink.model.http.HttpUtil;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.OTPDetails;
import com.kisanlink.mongo.User;
import com.kisanlink.mongo.manager.AllIdConfigurationManager;
import com.kisanlink.mongo.manager.ConfigurationManager;
import com.kisanlink.mongo.manager.OTPDetailsManager;
import com.kisanlink.mongo.manager.UserManager;
import com.kisanlink.mongo.repository.UserRepository;
import com.kisanlink.utilities.ConfigurationConstants1;
import com.kisanlink.view.OTPDetailsView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping("/static")
public class StaticService extends GenericService {
	private static VCLogger logger = VCLogManager.getLogger(StaticService.class);

	@Autowired UserManager userManager;
	@Autowired ConfigurationManager configurationManager;
	@Autowired OTPDetailsManager otpManager;
	@Autowired HttpUtil util;
	@Autowired UserRepository userRepository;
	@Autowired AllIdConfigurationManager allIdConfigurationManager;
	@Autowired private PasswordEncoder encoder;

	@GetMapping(value = "/user/signup/otp/{phoneNumber}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> requestSignupOtp(@PathVariable("phoneNumber") String phoneNumber) throws ServiceException {
		logger.info("register user service call with otp started - {0}", new Date());
		String otp="";
		String message=null;
		ResponseView res = new ResponseView();
		if(phoneNumber.equalsIgnoreCase("8885299977")) {
			otp="8858";
		}else {
			otp = RandomStringUtils.randomNumeric(4);
		}
		message=otp+" "+configurationManager.findValueByKey(ConfigurationConstants1.SMS_VERIFICATION_MSG);		
		OTPDetails details = otpManager.findByMobileNumber(Long.parseLong(phoneNumber));
		if(details==null) details = new OTPDetails();
		details.setMobileNumber(Long.parseLong(phoneNumber));
		details.setCreatedDate(new Date());
		details.setOtp(otp);
		otpManager.save(details);
		sendOtp(phoneNumber,message);
		res.setMessage(otp);
		res.setStatus(true);
		logger.info("register user service call with otp completed - {0}", new Date());
		return toSuccess(res);
	}

	@GetMapping(value = "/user/login/otp/{phoneNumber}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> requestLoginOtp(@PathVariable("phoneNumber") String phoneNumber) throws ServiceException {
		logger.info("register user service call with otp started - {0}", new Date());
		String otp="";
		User user = userManager.findByMobileNumber(Long.parseLong(phoneNumber));
		String message=null;
		ResponseView res = new ResponseView();
		if(user != null) {
			if(phoneNumber.equalsIgnoreCase("8885299977")) {
				otp="8858";
			}else {
				otp = RandomStringUtils.randomNumeric(4);
			}
			message=otp+" "+configurationManager.findValueByKey(ConfigurationConstants1.SMS_VERIFICATION_MSG);		
			OTPDetails details = otpManager.findByMobileNumber(Long.parseLong(phoneNumber));
			if(details==null) details = new OTPDetails();
			details.setMobileNumber(Long.parseLong(phoneNumber));
			details.setCreatedDate(new Date());
			details.setOtp(otp);
			otpManager.save(details);
			sendOtp(phoneNumber,message);
			res.setMessage(otp);
			res.setStatus(true);
		}else {
			res.setMessage("No user exists");
			res.setStatus(false);
		}
		logger.info("register user service call with otp completed - {0}", new Date());
		return toSuccess(res);
	}

	private void sendOtp(String phoneNumber,String message) {
		logger.info("send Otp service call started - {0}", new Date());
		String encodedMassage=URLEncoder.encode(message);
		StringJoiner joiner = new StringJoiner("&");
		joiner.add("AUTH_KEY="+configurationManager.findValueByKey(ConfigurationConstants1.AUTH_KEY));
		joiner.add("message="+encodedMassage);
		joiner.add("senderId="+configurationManager.findValueByKey(ConfigurationConstants1.SENDER_ID));
		joiner.add("routeId="+configurationManager.findValueByKey(ConfigurationConstants1.ROUTE_ID));
		joiner.add("mobileNos="+phoneNumber);
		joiner.add("smsContentType="+configurationManager.findValueByKey(ConfigurationConstants1.SMS_CONTENT_TYPE));		

		HttpRequest request=new HttpRequest();
		request.setUrl(new StringBuilder().append(configurationManager.findValueByKey(ConfigurationConstants1.SMS_URL)).append("?").append(joiner.toString()).toString());

		try {
			util.get(request);
		} catch (Exception e) {		
			logger.error("Exception while send otp info - {0}", e, e.getMessage());
		}
		logger.info("send Otp service call completed - {0}", new Date());
	}

	@GetMapping(value = "/user/exists/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> checkUser(@PathVariable("id") String id) {
		logger.info("check user service call started - {0}", new Date());
		User user = userManager.findByMobileNumber(Long.parseLong(id));
		if(user != null) {
			return toSucess(true);
		}
		logger.info("check user service call completed - {0}", new Date());
		return toSucess(false);
	}

	@PostMapping(value = "/user/otp/validate", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> checkOTP(@RequestBody OTPDetailsView view) {
		logger.info("check OTP service call started - {0}", new Date());
		OTPDetails details = otpManager.findByMobileNumber(view.getMobileNumber());
		ResponseView res = new ResponseView();
		if(details != null && details.getOtp().equalsIgnoreCase(view.getOtp())) {
			res.setMessage("OTP valid");
			res.setStatus(true);
		}else {
			res.setMessage("OTP invalid");
			res.setStatus(false);
		}
		logger.info("check OTP service call completed - {0}", new Date());
		return toSuccess(res);
	}
}