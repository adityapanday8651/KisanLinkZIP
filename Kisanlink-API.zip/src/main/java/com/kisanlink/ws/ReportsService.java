package com.kisanlink.ws;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.mongo.Promotions;
import com.kisanlink.mongo.Reports;
import com.kisanlink.mongo.manager.ReportsManager;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.PromotionsView;
import com.kisanlink.view.ReportsView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(path="/reports")
public class ReportsService extends GenericService{
	private static VCLogger logger = VCLogManager.getLogger(ReportsService.class);
	
	@Autowired ReportsManager reportsManager;
	
	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> userPromotions(@RequestBody ReportsView view, HttpServletRequest request){
		logger.info("reports save service call started - {0}", new Date());
		ResponseView res=new ResponseView();
		
		Reports reports = null;
		try {
			
			reports = reportsManager.findByReportId(view.getReportId());
			
			if(reports==null) {
				reports = new Reports();
				BeanUtils.copyProperties(view, reports);
				DateUtils.setBaseData(reports, "System");
				res.setMessage("Reports added successfully");
				res.setStatus(true);
			}else{
				BeanUtils.copyProperties(view, reports,"id");
				DateUtils.setModifiedBaseData(reports, "System");
				res.setMessage("Reports updated successfully");
			}
			
			res.setStatus(true);
			reportsManager.save(reports);
		}catch(Exception e) {
			logger.error("Exception while promotions save info - {0}", e, e.getMessage());
			res.setMessage("Saving Promotions Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("promotions save service call completed - {0}", new Date());
		return toSuccess(res);
	}
	
	@GetMapping(value="/list", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getAllReports(){
		List<Reports> list=reportsManager.findAll();
		return toSuccess(new ListResponseView(list.size(), list));
	}
	
}

