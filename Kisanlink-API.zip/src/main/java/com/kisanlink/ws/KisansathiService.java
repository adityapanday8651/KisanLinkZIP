package com.kisanlink.ws;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.AllIdConfiguration;
import com.kisanlink.mongo.Kisansathi;
import com.kisanlink.mongo.manager.AllIdConfigurationManager;
import com.kisanlink.mongo.manager.KisansathiManager;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.KisansathiView;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(path="/kisansathi")
public class KisansathiService extends GenericService {
	@Autowired KisansathiManager kisansathiManager;
	@Autowired AllIdConfigurationManager allIdConfigurationManager;
	private static VCLogger logger = VCLogManager.getLogger(KisansathiService.class);
	String methodName=null;
	//String apiUrl="kisanlink"+APIEndpoints.BASE_API_URL_V1+"/kisansathi";

	@PostMapping(value="/save", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> save(@RequestBody KisansathiView view, HttpServletRequest request)
	{
		logger.info("kisansathi service call started - {0}", new Date());
		ResponseView res = new ResponseView();
		Kisansathi kisansathi = null;
		try {
			AllIdConfiguration config=	allIdConfigurationManager.findByName("kisanSathi");
			kisansathi = kisansathiManager.findByid(view.getId());
			if(kisansathi==null)
			{
				kisansathi = new Kisansathi();
				BeanUtils.copyProperties(view, kisansathi);
				DateUtils.setBaseData(kisansathi, "System");
				res.setMessage("kisansathi save successfully");
			}
			else
			{
				BeanUtils.copyProperties(view, kisansathi, "id");
				DateUtils.setModifiedBaseData(kisansathi, "Ssytem");
				res.setMessage("kisansathi update successfully");
			}
			
			if(config==null) {
				config=new AllIdConfiguration();
				config.setLastGeneratedId(10000);
				kisansathi.setKisansathiId(config.getLastGeneratedId());
				DateUtils.setBaseData(config, "System");
			}else {
				kisansathi.setKisansathiId(config.getLastGeneratedId()+1);
				config.setLastGeneratedId(config.getLastGeneratedId()+1);
				DateUtils.setModifiedBaseData(config, "System");
			}
			allIdConfigurationManager.save(config);
			res.setStatus(true);
			kisansathiManager.save(kisansathi);
		}
		catch(Exception e)
		{
			logger.error("Exception while saving kisansathi info - {0}", e, e.getMessage());
			res.setMessage("kisansathi saving failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("kisansathi service call completed - {0}", new Date());
		return toSuccess(res);

	}

	@PostMapping(value="/list", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> list(@RequestBody SearchRequest request)
	{
		List<KisansathiView> views = new ArrayList<>();
		List<Kisansathi> list = kisansathiManager.search(request);
		long count = kisansathiManager.searchCount(request);
		for(Kisansathi kisansathi: list)
		{
			KisansathiView view = new KisansathiView();
			BeanUtils.copyProperties(kisansathi, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(count, views));

	}
}
