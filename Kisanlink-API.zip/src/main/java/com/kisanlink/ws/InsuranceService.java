package com.kisanlink.ws;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.AllIdConfiguration;
import com.kisanlink.mongo.Insurance;
import com.kisanlink.mongo.manager.AllIdConfigurationManager;
import com.kisanlink.mongo.manager.InsuranceManager;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.InsuranceView;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(path=APIEndpoints.BASE_API_URL_V1+"/insurance")
public class InsuranceService extends GenericService {
	private static VCLogger logger = VCLogManager.getLogger(InsuranceService.class);

	@Autowired InsuranceManager insuranceManager;
	@Autowired AllIdConfigurationManager allIdConfigurationManager;
	String methodName=null;
	String apiUrl="kisanlink"+APIEndpoints.BASE_API_URL_V1+"/insurance";

	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> save(@RequestBody InsuranceView view, HttpServletRequest request){
		logger.info("insurance save service call started - {0}", new Date());
		ResponseView res = new ResponseView();
		Insurance insurance = null;
		try {
			insurance = insuranceManager.findByid(view.getId());
			AllIdConfiguration config=allIdConfigurationManager.findByName("financeInsuranceService");
			if(insurance==null) {
				insurance = new Insurance();
				BeanUtils.copyProperties(view, insurance);
				DateUtils.setBaseData(insurance, "System");
				res.setMessage("insurance details  added successfully");
			}else{
				BeanUtils.copyProperties(view, insurance,"id");
				DateUtils.setModifiedBaseData(insurance, "System");
				res.setMessage("insurance details updated successfully");
			}
			int i=1;
			if(config==null) {
				config=new AllIdConfiguration();
				config.setLastGeneratedId(60000);
				insurance.setInsuranceId(config.getLastGeneratedId());
				DateUtils.setBaseData(insurance, "System");
			}else {
				insurance.setInsuranceId(config.getLastGeneratedId()+i);
				config.setLastGeneratedId(config.getLastGeneratedId()+i);
				DateUtils.setModifiedBaseData(insurance, "System");
			}
			res.setStatus(true);
			allIdConfigurationManager.save(config);
			insuranceManager.save(insurance);
		}catch(Exception e) {
			logger.error("Exception while insurance details save info - {0}", e, e.getMessage());
			res.setMessage("Saving insurance Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("insurance save service call completed - {0}", new Date());
		return toSuccess(res);
	}

	@CrossOrigin
	@PostMapping(value = "/list", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> list(@RequestBody SearchRequest searchRequest) {
		List<InsuranceView> views = new ArrayList<>();
		List<Insurance> list = insuranceManager.search(searchRequest);
		long count = insuranceManager.searchCount(searchRequest);
		for(Insurance insurance : list) {
			InsuranceView view = new InsuranceView();
			BeanUtils.copyProperties(insurance, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(count, views));
	}
}
