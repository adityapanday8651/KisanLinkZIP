package com.kisanlink.ws;

import java.util.ArrayList;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.MyContact;
import com.kisanlink.mongo.manager.MyContactManager;
import com.kisanlink.service.core.GenericSearchRepository;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.MyContactView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(path=APIEndpoints.BASE_API_URL_V1+"/myContact")
public class MyContactService extends GenericService{
	private static VCLogger logger = VCLogManager.getLogger(MyContactService.class);
	
	@Autowired MyContactManager myContactManager;
	@Autowired GenericSearchRepository searchRepository;
	
	String methodName=null;
	
	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> saveMyContact(@RequestBody MyContactView view, HttpServletRequest request){
		logger.info("mostSelling save service call started - {0}", new Date());
		ResponseView res=new ResponseView();

		MyContact myContact = null;
		try {

			myContact = myContactManager.findByMobileNumber(view.getMobileNumber());
			if(myContact==null) {
				myContact = new MyContact();
				BeanUtils.copyProperties(view, myContact);
				DateUtils.setBaseData(myContact, "System");
				res.setMessage("MyContact added successfully");
				res.setStatus(true);
			}else{
				BeanUtils.copyProperties(view, myContact,"id");
				DateUtils.setModifiedBaseData(myContact, "System");
				res.setMessage("MyContact updated successfully");
			}
			res.setStatus(true);
			myContactManager.save(myContact);
		}catch(Exception e) {
			logger.error("Exception while myContact save info - {0}", e, e.getMessage());
			res.setMessage("Saving MyContact Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("myContact save service call completed - {0}", new Date());
		return toSuccess(res);
	}
	
	@PostMapping(value="/list",produces= MediaType.APPLICATION_JSON_VALUE)
	ResponseEntity<Message> searchMyContact(@RequestBody SearchRequest searchRequest, HttpServletRequest request)
	{
		List<MyContact> list = myContactManager.search(searchRequest);
		long count = myContactManager.searchCount(searchRequest);
		List<MyContactView> views = new ArrayList<>();
		for(MyContact myContact:list)
		{
			MyContactView view = new MyContactView();
			BeanUtils.copyProperties(myContact, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(count, views));
	}	
}
