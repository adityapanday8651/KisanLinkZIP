package com.kisanlink.ws;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.Variants;
import com.kisanlink.mongo.manager.VariantsManager;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;
import com.kisanlink.view.VariantsView;

@RestController
@RequestMapping(path=APIEndpoints.BASE_API_URL_V1+"/variant")
public class VariantsService extends GenericService{

	private static VCLogger logger = VCLogManager.getLogger(VariantsService.class);

	@Autowired VariantsManager variantsManager;

	@CrossOrigin
	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> saveVariants(@RequestBody VariantsView view, HttpServletRequest request){
		logger.info("services save service call started - {0}", new Date());
		ResponseView res=new ResponseView();

		Variants variants = null;
		try {

			if(view.getId()!=null)variants =variantsManager.findById(view.getId());
			
			if(variants==null) {
				variants = new Variants();
				BeanUtils.copyProperties(view, variants);
				DateUtils.setBaseData(variants, "System");
				res.setMessage("Variants added successfully");
				res.setStatus(true);
			}else{
				BeanUtils.copyProperties(view, variants,"id");
				DateUtils.setModifiedBaseData(variants, "System");
				res.setMessage("Variants updated successfully");
			}
			res.setStatus(true);
			variantsManager.save(variants);
		}catch(Exception e) {
			logger.error("Exception while variants save info - {0}", e, e.getMessage());
			res.setMessage("Saving Variants Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("services save variants call completed - {0}", new Date());
		return toSuccess(res);
	}


	@CrossOrigin
	@PostMapping(value="/list",produces= MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> searchList(@RequestBody SearchRequest searchRequest, HttpServletRequest request)
	{
		List<Variants> list = variantsManager.search(searchRequest);
		long count = variantsManager.searchCount(searchRequest);
		List<VariantsView> views = new ArrayList<>();
		for(Variants variants:list)
		{
			VariantsView view = new VariantsView();
			BeanUtils.copyProperties(variants, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(count, views));
	}
}