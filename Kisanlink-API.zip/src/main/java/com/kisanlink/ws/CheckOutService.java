package com.kisanlink.ws;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.mongo.Categories;
import com.kisanlink.mongo.CheckOut;
import com.kisanlink.mongo.manager.CheckOutManager;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.CategoriesView;
import com.kisanlink.view.CheckOutView;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(path="/checkout")
public class CheckOutService extends GenericService{
	private static VCLogger logger = VCLogManager.getLogger(CheckOutService.class);

	@Autowired CheckOutManager checkOutManager;

	String methodName=null;

	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> saveCheckOut(@RequestBody CheckOutView view, HttpServletRequest request){
		logger.info("checkOut save service call started - {0}", new Date());
		ResponseView res=new ResponseView();

		CheckOut checkout = null;
		try {

			checkout = checkOutManager.findByFarmerId(view.getFarmerId());
			if(checkout==null) {
				checkout = new CheckOut();
				BeanUtils.copyProperties(view, checkout);
				DateUtils.setBaseData(checkout, "System");
				res.setMessage("CheckOut added successfully");
				res.setStatus(true);
			}else{
				BeanUtils.copyProperties(view, checkout,"id");
				DateUtils.setModifiedBaseData(checkout, "System");
				res.setMessage("CheckOut updated successfully");
			}
			res.setStatus(true);
			checkOutManager.save(checkout);
		}catch(Exception e) {
			logger.error("Exception while checkOut save info - {0}", e, e.getMessage());
			res.setMessage("Saving CheckOut Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("checkOut save service call completed - {0}", new Date());
		return toSuccess(res);
	}
	
	@GetMapping(value="/list", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getAllCheckOut(){
		List<CheckOut> list=checkOutManager.findAll();
		return toSuccess(new ListResponseView(list.size(),list));
	}
	
	@GetMapping(value="/find/{farmerId}", produces=MediaType.APPLICATION_JSON_VALUE)
	public CheckOut findCheckOutByFarmerId(@PathVariable("farmerId") String farmerId) {
		return checkOutManager.findByFarmerId(farmerId);	
	}
}
