package com.kisanlink.ws;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.AllIdConfiguration;
import com.kisanlink.mongo.Products;
import com.kisanlink.mongo.manager.AllIdConfigurationManager;
import com.kisanlink.mongo.manager.ProductsManager;
import com.kisanlink.service.core.GenericSearchRepository;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ProductsView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(path=APIEndpoints.BASE_API_URL_V1+"/products")
public class ProductsService extends GenericService{
	private static VCLogger logger = VCLogManager.getLogger(ProductsService.class);
	@Autowired GenericSearchRepository searchRepository;
	@Autowired ProductsManager productsManager;
	@Autowired AllIdConfigurationManager allIdConfigurationManager;

	@CrossOrigin
	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> userSave(@RequestBody ProductsView view, HttpServletRequest request){
		logger.info("products save service call started - {0}", new Date());
		ResponseView res=new ResponseView();

		Products products = null;
		try {
			AllIdConfiguration config=	allIdConfigurationManager.findByName("product");
			products =productsManager.findByProductId(view.getProductId());
			if(products==null) {
				products = new Products();
				BeanUtils.copyProperties(view, products);
				DateUtils.setBaseData(products, "System");
				res.setMessage("products added successfully");
				res.setStatus(true);
			}else{
				BeanUtils.copyProperties(view, products,"id");
				DateUtils.setModifiedBaseData(products, "System");
				res.setMessage("products updated successfully");
			}

			if(config==null) {
				config=new AllIdConfiguration();
				config.setLastGeneratedId(50000);
				products.setProductId(config.getLastGeneratedId());
				DateUtils.setBaseData(config, "System");
			}else {
				products.setProductId(config.getLastGeneratedId()+1);
				config.setLastGeneratedId(config.getLastGeneratedId()+1);
				DateUtils.setModifiedBaseData(config, "System");
			}
			allIdConfigurationManager.save(config);
			res.setStatus(true);
			allIdConfigurationManager.save(config);
			productsManager.save(products);
		}catch(Exception e) {
			logger.error("Exception while products save info - {0}", e, e.getMessage());
			res.setMessage("Saving products Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("prodcuts save service call completed - {0}", new Date());
		return toSuccess(res);
	}

	@CrossOrigin
	@PostMapping(value="/list",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> getAllProducts(@RequestBody SearchRequest searchRequest){
		List<ProductsView> views = new ArrayList<>();
		List<Products> list = productsManager.search(searchRequest);
		for(Products Products : list) {
			ProductsView view = new ProductsView();
			BeanUtils.copyProperties(Products, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(list.size(),list));	
	}	
	
	@CrossOrigin
	@DeleteMapping(value="/delete/{id}",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> deleteProducts(@PathVariable("id") String id){
		ResponseView res=new ResponseView();
		productsManager.findById(id);
		res.setMessage("Product Deleted Successfully");
		res.setStatus(true);
		return toSuccess(res);
	}
}