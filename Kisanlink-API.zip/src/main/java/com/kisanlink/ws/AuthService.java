package com.kisanlink.ws;

import java.net.URLEncoder;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.StringJoiner;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.jwt.mongodb.payload.request.LoginRequest;
import com.kisanlink.jwt.mongodb.payload.response.JwtResponse;
import com.kisanlink.jwt.mongodb.payload.response.MessageResponse;
import com.kisanlink.jwt.mongodb.security.jwt.JwtUtils;
import com.kisanlink.jwt.security.services.UserDetailsImpl;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.http.HttpRequest;
import com.kisanlink.model.http.HttpUtil;
import com.kisanlink.mongo.AllIdConfiguration;
import com.kisanlink.mongo.ERole;
import com.kisanlink.mongo.Role;
import com.kisanlink.mongo.User;
import com.kisanlink.mongo.manager.AllIdConfigurationManager;
import com.kisanlink.mongo.manager.ConfigurationManager;
import com.kisanlink.mongo.manager.OTPDetailsManager;
import com.kisanlink.mongo.manager.UserManager;
import com.kisanlink.mongo.repository.RoleRepository;
import com.kisanlink.mongo.repository.UserRepository;
import com.kisanlink.utilities.ConfigurationConstants1;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.UserView;

import io.swagger.annotations.ApiOperation;


@RestController
@RequestMapping("/api/auth")
public class AuthService {

	private static VCLogger logger = VCLogManager.getLogger(AuthService.class);

	@Autowired AuthenticationManager authenticationManager;
	@Autowired UserRepository userRepository;
	@Autowired RoleRepository roleRepository;
	@Autowired PasswordEncoder encoder;
	@Autowired JwtUtils jwtUtils;
	@Autowired AllIdConfigurationManager allIdConfigurationManager;
	@Autowired ConfigurationManager configurationManager;
	@Autowired OTPDetailsManager otpManager;
	@Autowired HttpUtil util;
	@Autowired UserManager userManager;

	@CrossOrigin
	@PostMapping("/signin")
	@ApiOperation(value="This API is to authenticate user", 
	notes="Mandatory fields - TBD",
	response = User.class)
	public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest) {
		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));
		SecurityContextHolder.getContext().setAuthentication(authentication);
		String jwt = jwtUtils.generateJwtToken(authentication);

		UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();		
		List<String> roles = userDetails.getAuthorities().stream()
				.map(item -> item.getAuthority())
				.collect(Collectors.toList());
		return ResponseEntity.ok(new JwtResponse(jwt,
				userDetails.getId(), 
				userDetails.getUsername(), 
				userDetails.getEmail(), 
				roles, 
				"Success"));
	}

	@CrossOrigin
	@GetMapping("/login/{id}")
	@ApiOperation(value="This API is to authenticate user using mobile number", 
	notes="Mandatory fields - TBD",
	response = User.class)
	public ResponseEntity<?> authenticateUserMobile(@PathVariable("id") String id) {
		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(id, "123456"));
		SecurityContextHolder.getContext().setAuthentication(authentication);
		String jwt = jwtUtils.generateJwtToken(authentication);

		UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();		
		List<String> roles = userDetails.getAuthorities().stream()
				.map(item -> item.getAuthority())
				.collect(Collectors.toList());
		return ResponseEntity.ok(new JwtResponse(jwt,
				userDetails.getId(), 
				userDetails.getUsername(), 
				userDetails.getEmail(), 
				roles, 
				"Success"));
	}

	@CrossOrigin
	@PostMapping("/login/pin")
	@ApiOperation(value="This API is to authenticate user using mobile number and pin", 
	notes="Mandatory fields - TBD",
	response = User.class)
	public ResponseEntity<?> authenticateUserMobile(@RequestBody UserView view) {

		User user = userManager.findByMobileNumber(view.getMobileNumber());
		if(user != null) {
			if(!encoder.matches(view.getPin(), user.getPin())) {
				return ResponseEntity.ok(new JwtResponse(null,
						null, 
						null, 
						null, 
						null,
						"Invalid pin"));
			}
		}else {
			return ResponseEntity.ok(new JwtResponse(null,
					null, 
					null, 
					null, 
					null,
					"No user found"));
		}

		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(Long.toString(view.getMobileNumber()), "123456"));
		SecurityContextHolder.getContext().setAuthentication(authentication);
		String jwt = jwtUtils.generateJwtToken(authentication);

		UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();		
		List<String> roles = userDetails.getAuthorities().stream()
				.map(item -> item.getAuthority())
				.collect(Collectors.toList());
		return ResponseEntity.ok(new JwtResponse(jwt,
				userDetails.getId(), 
				userDetails.getUsername(), 
				userDetails.getEmail(), 
				roles, 
				"Success"));
	}

	@CrossOrigin
	@PostMapping("/signup")
	@ApiOperation(value="This API is to save a user/kisansathi", 
	notes="Mandatory fields - TBD",
	response = User.class)
	public ResponseEntity<?> registerUser(@Valid @RequestBody UserView view) throws ServiceException {
		if (userRepository.existsByUsername(view.getUsername())) {
			return ResponseEntity
					.badRequest()
					.body(new MessageResponse("Error: Username is already taken!"));
		}
		if (userRepository.existsByMobileNumber(view.getMobileNumber())) {
			return ResponseEntity
					.badRequest()
					.body(new MessageResponse("Error: Mobile Number is already in use!"));
		}
		// Create new user's account
		User user = new User();
		BeanUtils.copyProperties(view, user, "password");
		user.setPassword(encoder.encode("123456"));
		user.setPin(encoder.encode(view.getPin()));
		DateUtils.setBaseData(user, "System");
		Set<String> strRoles = view.getRoles();
		Set<Role> roles = new HashSet<>();
		if (strRoles == null) {
			Role userRole = roleRepository.findByName(ERole.ROLE_USER)
					.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
			roles.add(userRole);
		} else {
			strRoles.forEach(role -> {
				switch (role) {
				case "admin":
					Role adminRole = roleRepository.findByName(ERole.ROLE_ADMIN)
					.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
					roles.add(adminRole);
					break;
				case "mod":
					Role modRole = roleRepository.findByName(ERole.ROLE_MODERATOR)
					.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
					roles.add(modRole);
					break;
				default:
					Role userRole = roleRepository.findByName(ERole.ROLE_USER)
					.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
					roles.add(userRole);
				}
			});
		}
		user.setRoles(roles);


		AllIdConfiguration config = allIdConfigurationManager.findByName("kisanSathi");
		if(config == null) {
			config = new AllIdConfiguration();
			config.setName("kisanSathi");
			config.setLastGeneratedId(10000);
			DateUtils.setBaseData(config, "System");
		}else {
			config.setLastGeneratedId(config.getLastGeneratedId()+1);
			DateUtils.setModifiedBaseData(config, "System");
		}

		user.setKisanSathiId(config.getLastGeneratedId());
		userRepository.save(user);
		allIdConfigurationManager.save(config);

		String str = user.getFirstName();
		String message= "Welcome "+str+" "+configurationManager.findValueByKey(ConfigurationConstants1.SMS_WELCOME_MSG);
		sendOtp(String.valueOf(user.getMobileNumber()),message);

		return ResponseEntity.ok(new MessageResponse("User registered successfully!"));
	}

	private void sendOtp(String phoneNumber,String message) {
		logger.info("send Otp service call started - {0}", new Date());
		String encodedMassage=URLEncoder.encode(message);
		StringJoiner joiner = new StringJoiner("&");
		joiner.add("AUTH_KEY="+configurationManager.findValueByKey(ConfigurationConstants1.AUTH_KEY));
		joiner.add("message="+encodedMassage);
		joiner.add("senderId="+configurationManager.findValueByKey(ConfigurationConstants1.SENDER_ID));
		joiner.add("routeId="+configurationManager.findValueByKey(ConfigurationConstants1.ROUTE_ID));
		joiner.add("mobileNos="+phoneNumber);
		joiner.add("smsContentType="+configurationManager.findValueByKey(ConfigurationConstants1.SMS_CONTENT_TYPE));		

		HttpRequest request=new HttpRequest();
		request.setUrl(new StringBuilder().append(configurationManager.findValueByKey(ConfigurationConstants1.SMS_URL)).append("?").append(joiner.toString()).toString());

		try {
			util.get(request);
		} catch (Exception e) {		
			logger.error("Exception while send otp info - {0}", e, e.getMessage());
		}
		logger.info("send Otp service call completed - {0}", new Date());
	}
}