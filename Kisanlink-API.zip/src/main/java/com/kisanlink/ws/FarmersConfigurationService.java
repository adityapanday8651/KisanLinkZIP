package com.kisanlink.ws;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.FarmersConfiguration;
import com.kisanlink.mongo.manager.FarmersConfigurationManager;
import com.kisanlink.service.core.GenericSearchRepository;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.FarmersConfigurationView;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(path="/farmersConfiguration")
public class FarmersConfigurationService extends GenericService{
	String methodName=null;
	
	private static VCLogger logger = VCLogManager.getLogger(FarmersService.class);
	
	@Autowired FarmersConfigurationManager farmersConfigurationManager;
	@Autowired GenericSearchRepository searchRepository;
	
	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> saveFarmersConfiguration(@RequestBody FarmersConfigurationView view, HttpServletRequest request){
		logger.info("FarmersConfiguration save service call started - {0}", new Date());
		ResponseView res=new ResponseView();
		FarmersConfiguration farmersConfig = null;
		try {
	
			farmersConfig = farmersConfigurationManager.findByFarmerId(view.getFarmerId());
			if(farmersConfig==null) {
				farmersConfig = new FarmersConfiguration();
				BeanUtils.copyProperties(view, farmersConfig);
				DateUtils.setBaseData(farmersConfig, "System");
				res.setMessage("FarmersConfiguration added successfully");
				res.setStatus(true);
			}else{
				BeanUtils.copyProperties(view, farmersConfig,"id");
				DateUtils.setModifiedBaseData(farmersConfig, "System");
				res.setMessage("FarmersConfiguration updated successfully");
			}
			res.setStatus(true);
			farmersConfigurationManager.save(farmersConfig);
		}catch(Exception e) {
			logger.error("Exception while FarmersConfiguration save info - {0}", e, e.getMessage());
			res.setMessage("Saving FarmersConfiguration Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("FarmersConfiguration save service call completed - {0}", new Date());
		return toSuccess(res);
	}
	
	@GetMapping(value="/list",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> getAllFarmersConfiguration(){
		List<FarmersConfiguration> farmersConfiguration=farmersConfigurationManager.findAll();
		return toSucess(new ListResponseView(farmersConfiguration.size(),farmersConfiguration));	
	}
	
	@GetMapping(value="/find/{farmerId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public FarmersConfiguration findFarmersConfigurationByFarmerId(@PathVariable("farmerId") int farmerId) {
		return farmersConfigurationManager.findByFarmerId(farmerId);
		
	}
	
	
	@SuppressWarnings("unchecked")
	@CrossOrigin
	@PostMapping(value="/search", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> searchFarmersConfiguration(@RequestBody SearchRequest searchRequest,String createdBy){
		List<FarmersConfiguration> farmersConfiguration=(List<FarmersConfiguration>) searchRepository.search(searchRequest, createdBy, createdBy, FarmersConfiguration.class); 
		return toSuccess(new ListResponseView(farmersConfiguration.size(),farmersConfiguration));		
	}
	

}
