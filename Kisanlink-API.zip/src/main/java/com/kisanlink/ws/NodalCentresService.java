package com.kisanlink.ws;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.AllIdConfiguration;
import com.kisanlink.mongo.NodalCentres;
import com.kisanlink.mongo.manager.AllIdConfigurationManager;
import com.kisanlink.mongo.manager.NodalCentresManager;
import com.kisanlink.service.core.GenericSearchRepository;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.NodalCentresView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(value=APIEndpoints.BASE_API_URL_V1+"/nodal")
public class NodalCentresService extends GenericService {
	@Autowired NodalCentresManager nodalCentresManager;
	@Autowired AllIdConfigurationManager allIdConfigurationManager;
	@Autowired GenericSearchRepository searchRepository;
	private static VCLogger logger = VCLogManager.getLogger(NodalCentresService.class);
	String methodName=null;
	String apiUrl="kisanlink"+APIEndpoints.BASE_API_URL_V1+"/nodal";

	@PostMapping(value="/save", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> save(@RequestBody NodalCentresView view, HttpServletRequest request)
	{
		logger.info("NodalCentres service call started - {0}", new Date());
		ResponseView res = new ResponseView();
		NodalCentres nodalCentres = null;
		try {
			nodalCentres = nodalCentresManager.findByid(view.getId());
			AllIdConfiguration config=	allIdConfigurationManager.findByName("centres");
			if(nodalCentres==null)
			{
				nodalCentres = new NodalCentres();
				BeanUtils.copyProperties(view, nodalCentres);
				DateUtils.setBaseData(nodalCentres, "System");
				res.setMessage("NodalCentres save successfully");
			}
			else
			{
				BeanUtils.copyProperties(view, nodalCentres, "id");
				DateUtils.setModifiedBaseData(nodalCentres, "Ssytem");
				res.setMessage("NodalCentres update successfully");
			}
			int i=1;
			if(config==null) {
				config=new AllIdConfiguration();
				config.setLastGeneratedId(30000);
				nodalCentres.setNodalCentreId(config.getLastGeneratedId());
				DateUtils.setBaseData(config, "System");
			}else {
				nodalCentres.setNodalCentreId(config.getLastGeneratedId()+i);
				config.setLastGeneratedId(config.getLastGeneratedId()+i);
				DateUtils.setModifiedBaseData(config, "System");
			}
			res.setStatus(true);
			allIdConfigurationManager.save(config);
			nodalCentresManager.save(nodalCentres);
		}
		catch(Exception e)
		{
			logger.error("Exception while saving NodalCentres info - {0}", e, e.getMessage());
			res.setMessage("NodalCentres saving failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("NodalCentres service call completed - {0}", new Date());
		return toSuccess(res);

	}

	@PostMapping(value="/list", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> list(@RequestBody SearchRequest request)
	{
		List<NodalCentresView> views = new ArrayList<>();
		List<NodalCentres> list = nodalCentresManager.search(request);
		long count = nodalCentresManager.searchCount(request);
		for(NodalCentres nodalCentres: list)
		{
			NodalCentresView view = new NodalCentresView();
			BeanUtils.copyProperties(nodalCentres, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(count, views));

	}
}
