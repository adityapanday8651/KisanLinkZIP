package com.kisanlink.ws;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.mongo.RewardsHistory;
import com.kisanlink.mongo.manager.RewardsHistoryManager;
import com.kisanlink.service.core.GenericSearchRepository;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;
import com.kisanlink.view.RewardsHistoryView;

@RestController
@RequestMapping(path="/rewardsHistory")
public class RewardsHistoryService extends GenericService{
	private static VCLogger logger = VCLogManager.getLogger(RewardsHistoryService.class);
	
	@Autowired RewardsHistoryManager rewardsHistoryManager;
	@Autowired GenericSearchRepository searchRepository;
	
	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> saveRewardsHistory(@RequestBody RewardsHistoryView view, HttpServletRequest request){
		logger.info("rewardsHistory save service call started - {0}", new Date());
		ResponseView res=new ResponseView();
		
		RewardsHistory rewardsHistory = null;
		try {
			
			rewardsHistory =rewardsHistoryManager.findByName(view.getName());
			if(rewardsHistory==null) {
				rewardsHistory = new RewardsHistory();
				BeanUtils.copyProperties(view, rewardsHistory);
				DateUtils.setBaseData(rewardsHistory, "System");
				res.setMessage("RewardsHistory added successfully");
				res.setStatus(true);
			}else{
				BeanUtils.copyProperties(view, rewardsHistory,"id");
				DateUtils.setModifiedBaseData(rewardsHistory, "System");
				res.setMessage("RewardsHistory updated successfully");
			}
			res.setStatus(true);
			rewardsHistoryManager.save(rewardsHistory);
		}catch(Exception e) {
			logger.error("Exception while rewardsHistory save info - {0}", e, e.getMessage());
			res.setMessage("RewardsHistory Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("rewardsHistory save service call completed - {0}", new Date());
		return toSuccess(res);
	}
	
	@SuppressWarnings("unchecked")
	@PostMapping(value="/search", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> searchRewardsHistory(@RequestBody SearchRequest searchRequest){
		List<RewardsHistory> searchRewardsHistory=(List<RewardsHistory>) searchRepository.search(searchRequest, RewardsHistory.class);
		return toSuccess(new ListResponseView(searchRewardsHistory.size(), searchRewardsHistory));	
	}
	
	@GetMapping(value="/list", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> listRewardsHistory(){
		List<RewardsHistory> list=rewardsHistoryManager.findAll();
		return toSuccess(new ListResponseView(list.size(), list));
	}
}
