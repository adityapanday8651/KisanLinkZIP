package com.kisanlink.ws;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;

import com.kisanlink.mongo.Services;
import com.kisanlink.mongo.manager.ServicesManager;
import com.kisanlink.service.core.GenericSearchRepository;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;
import com.kisanlink.view.ServicesView;

@RestController
@RequestMapping(path=APIEndpoints.BASE_API_URL_V1+"/services")
public class ServicesService extends GenericService{
	private static VCLogger logger = VCLogManager.getLogger(ServicesService.class);
	
	@Autowired ServicesManager servicesManager;
	@Autowired GenericSearchRepository searchRepository;
	
	String methodName=null;
	
	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> userServices(@RequestBody ServicesView view, HttpServletRequest request){
		logger.info("services save service call started - {0}", new Date());
		ResponseView res=new ResponseView();
		
		Services services = null;
		try {
			
			services =servicesManager.findByFarmerId(view.getFarmerId());
			if(services==null) {
				services = new Services();
				BeanUtils.copyProperties(view, services);
				DateUtils.setBaseData(services, "System");
				res.setMessage("Services added successfully");
				res.setStatus(true);
			}else{
				BeanUtils.copyProperties(view, services,"id");
				DateUtils.setModifiedBaseData(services, "System");
				res.setMessage("Services updated successfully");
			}
			res.setStatus(true);
			servicesManager.save(services);
		}catch(Exception e) {
			logger.error("Exception while services save info - {0}", e, e.getMessage());
			res.setMessage("Saving services Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("services save service call completed - {0}", new Date());
		return toSuccess(res);
	}
	
	@GetMapping(value="/list",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getAllServices(){
		List<Services> list=servicesManager.findAll();
		return toSuccess(new ListResponseView(list.size(),list));
	}
	
	@GetMapping(value="/find/{farmerId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public Services findByFarmerIdServices(@PathVariable("farmerId") String farmerId) {
		return servicesManager.findByFarmerId(farmerId);	
	}
	
}
