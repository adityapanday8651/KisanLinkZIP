package com.kisanlink.ws;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.mongo.AllIdConfiguration;
import com.kisanlink.mongo.Categories;
import com.kisanlink.mongo.manager.AllIdConfigurationManager;
import com.kisanlink.mongo.manager.CategoriesManager;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.CategoriesView;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(path=APIEndpoints.BASE_API_URL_V1+"/categories")
public class CategoriesService extends GenericService{
	private static VCLogger logger = VCLogManager.getLogger(CategoriesService.class);
	
	@Autowired CategoriesManager categoriesManager;
	@Autowired AllIdConfigurationManager allIdConfigurationManager;
	
	String methodName=null;
	
	@CrossOrigin
	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> saveCategories(@RequestBody CategoriesView view, HttpServletRequest request){
		logger.info("Categories save service call started - {0}", new Date());
		ResponseView res=new ResponseView();
		
		Categories categories = null;
		try {

			AllIdConfiguration config=allIdConfigurationManager.findByName("category");
			categories = categoriesManager.findByCategoryId(view.getCategoryId());
			if(categories==null) {
				categories = new Categories();
				BeanUtils.copyProperties(view, categories);
				DateUtils.setBaseData(categories, "System");
				res.setMessage("Categories added successfully");
				res.setStatus(true);
			}else{
				BeanUtils.copyProperties(view, categories,"id");
				DateUtils.setModifiedBaseData(categories, "System");
				res.setMessage("Categories updated successfully");
			}
			
			if(config==null) {
				config = new AllIdConfiguration();
				config.setLastGeneratedId(1);
				categories.setCategoryId(config.getLastGeneratedId());
				DateUtils.setBaseData(config, "System");
			}else {
				categories.setCategoryId(config.getLastGeneratedId()+1);
				config.setLastGeneratedId(config.getLastGeneratedId()+1);
				DateUtils.setModifiedBaseData(config, "System");
			}
			allIdConfigurationManager.save(config);
			res.setStatus(true);
			categoriesManager.save(categories);
		}catch(Exception e) {
			logger.error("Exception while Categories save info - {0}", e, e.getMessage());
			res.setMessage("Saving Categories Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("Categories save service call completed - {0}", new Date());
		return toSuccess(res);
	}
	
	@CrossOrigin
	@GetMapping(value="/list",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> listCategories(){
		List<Categories> list=categoriesManager.findAll();
		return toSuccess(new ListResponseView(list.size(), list));
	}
	
	@CrossOrigin
	@DeleteMapping(value="/delete/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> deleteCategories(@PathVariable("id") String id){
		ResponseView res=new ResponseView();
		categoriesManager.deleteById(id);
		res.setMessage("Categories Deleted Successfully");
		res.setStatus(true);
		return toSuccess(res);	
	}
}
