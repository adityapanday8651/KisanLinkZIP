package com.kisanlink.ws;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.mongo.Carts;
import com.kisanlink.mongo.Farmers;
import com.kisanlink.mongo.manager.CartsManager;
import com.kisanlink.service.core.GenericSearchRepository;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.CartsView;
import com.kisanlink.view.FarmersView;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(path="carts")
public class CartsService extends GenericService{
	private static VCLogger logger = VCLogManager.getLogger(CartsService.class);
	@Autowired CartsManager cartsManager;
	@Autowired GenericSearchRepository searchRepository;
	
	String methodName=null;
	

	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> saveCarts(@RequestBody CartsView view, HttpServletRequest request){
		logger.info("Carts save service call started - {0}", new Date());
		ResponseView res=new ResponseView();
		Carts carts = null;
		try {
	
			carts = cartsManager.findByCategoryId(view.getCategoryId());
			if(carts==null) {
				carts = new Carts();
				BeanUtils.copyProperties(view, carts);
				DateUtils.setBaseData(carts, "System");
				res.setMessage("Carts added successfully");
				res.setStatus(true);
			}else{
				BeanUtils.copyProperties(view, carts,"id");
				DateUtils.setModifiedBaseData(carts, "System");
				res.setMessage("Carts updated successfully");
			}
			res.setStatus(true);
			cartsManager.save(carts);
		}catch(Exception e) {
			logger.error("Exception while Carts save info - {0}", e, e.getMessage());
			res.setMessage("Saving Carts Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("Carts save service call completed - {0}", new Date());
		return toSuccess(res);
	}
	
	@GetMapping(value="/list", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getAllCarts(){
		List<Carts> list=cartsManager.findAll();
		return toSuccess(new ListResponseView(list.size(),list));
		
	}
	
	@GetMapping(value="/find/{categoryId}", produces=MediaType.APPLICATION_JSON_VALUE)
	public Carts findByCategoryId(@PathVariable("categoryId") String categoryId){
		 return cartsManager.findByCategoryId(categoryId);		
	}
}
