package com.kisanlink.ws;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.mongo.AllIdConfiguration;
import com.kisanlink.mongo.Promotions;
import com.kisanlink.mongo.manager.AllIdConfigurationManager;
import com.kisanlink.mongo.manager.PromotionsManager;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.PromotionsView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(path="/promotions")
public class PromotionsService extends GenericService{
	private static VCLogger logger = VCLogManager.getLogger(PromotionsService.class);
	
	@Autowired PromotionsManager promotionsManager;
	@Autowired AllIdConfigurationManager allIdConfigurationManager;
	
	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> userPromotions(@RequestBody PromotionsView view, HttpServletRequest request){
		logger.info("promotions save service call started - {0}", new Date());
		ResponseView res=new ResponseView();
		
		Promotions promotions = null;
		try {
			AllIdConfiguration config=	allIdConfigurationManager.findByName("promotionProduct");
			promotions=promotionsManager.findByCampaignId(view.getCampaignId());
			
			if(promotions==null) {
				promotions = new Promotions();
				BeanUtils.copyProperties(view, promotions);
				DateUtils.setBaseData(promotions, "System");
				res.setMessage("Promotions added successfully");
				res.setStatus(true);
			}else{
				BeanUtils.copyProperties(view, promotions,"id");
				DateUtils.setModifiedBaseData(promotions, "System");
				res.setMessage("Promotions updated successfully");
			}
			
			
			if(config==null) {
				config=new AllIdConfiguration();
				config.setLastGeneratedId(100);
				promotions.setPromotionId(config.getLastGeneratedId());
				DateUtils.setBaseData(config, "System");
			}else {
				promotions.setPromotionId(config.getLastGeneratedId()+1);
				config.setLastGeneratedId(config.getLastGeneratedId()+1);
				DateUtils.setModifiedBaseData(config, "System");
			}
			
			allIdConfigurationManager.save(config);
			res.setStatus(true);
			promotionsManager.save(promotions);
		}catch(Exception e) {
			logger.error("Exception while promotions save info - {0}", e, e.getMessage());
			res.setMessage("Saving Promotions Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("promotions save service call completed - {0}", new Date());
		return toSuccess(res);
	}
	
	@GetMapping(value="/list", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getAllPromotion(){
		List<Promotions> list=promotionsManager.findAll();
		return toSuccess(new ListResponseView(list.size(), list));	
	}	
}
