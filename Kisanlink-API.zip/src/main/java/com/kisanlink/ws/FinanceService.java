package com.kisanlink.ws;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.AllIdConfiguration;
import com.kisanlink.mongo.Finance;
import com.kisanlink.mongo.manager.AllIdConfigurationManager;
import com.kisanlink.mongo.manager.FinanceManager;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.FinanceView;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(path=APIEndpoints.BASE_API_URL_V1+"/finance")
public class FinanceService extends GenericService {
	private static VCLogger logger = VCLogManager.getLogger(FinanceService.class);

	@Autowired FinanceManager financeManager;
	@Autowired AllIdConfigurationManager allIdConfigurationManager;
	String methodName=null;
	String apiUrl="kisanlink"+APIEndpoints.BASE_API_URL_V1+"/finance";

	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> save(@RequestBody FinanceView view, HttpServletRequest request){
		logger.info("Finance save service call started - {0}", new Date());
		ResponseView res = new ResponseView();
		Finance finance = null;
		try {
			finance = financeManager.findByid(view.getId());
			AllIdConfiguration config=allIdConfigurationManager.findByName("financeInsuranceService");
			if(finance==null) {
				finance = new Finance();
				BeanUtils.copyProperties(view, finance);
				DateUtils.setBaseData(finance, "System");
				res.setMessage("finance details  added successfully");
			}else{
				BeanUtils.copyProperties(view, finance,"id");
				DateUtils.setModifiedBaseData(finance, "System");
				res.setMessage("finance details updated successfully");
			}
			int i=1;
			if(config==null) {
				config=new AllIdConfiguration();
				config.setLastGeneratedId(60000);
				finance.setFinanceId(config.getLastGeneratedId());
				DateUtils.setBaseData(finance, "System");
			}else {
				finance.setFinanceId(config.getLastGeneratedId()+i);
				config.setLastGeneratedId(config.getLastGeneratedId()+i);
				DateUtils.setModifiedBaseData(finance, "System");
			}
			res.setStatus(true);
			allIdConfigurationManager.save(config);
			financeManager.save(finance);
		}catch(Exception e) {
			logger.error("Exception while finance details save info - {0}", e, e.getMessage());
			res.setMessage("Saving finance Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("finance save service call completed - {0}", new Date());
		return toSuccess(res);
	}

	@CrossOrigin
	@PostMapping(value = "/list", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> list(@RequestBody SearchRequest searchRequest) {
		List<FinanceView> views = new ArrayList<>();
		List<Finance> list = financeManager.search(searchRequest);
		long count = financeManager.searchCount(searchRequest);
		for(Finance finance : list) {
			FinanceView view = new FinanceView();
			BeanUtils.copyProperties(finance, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(count, views));
	}
}
