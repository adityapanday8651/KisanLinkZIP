package com.kisanlink.ws;

import java.util.ArrayList;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.MostSelling;
import com.kisanlink.mongo.manager.MostSellingManager;
import com.kisanlink.service.core.GenericSearchRepository;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.MostSellingView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(path=APIEndpoints.BASE_API_URL_V1+"/mostselling")
public class MostSellingService extends GenericService{
	private static VCLogger logger = VCLogManager.getLogger(MostSellingService.class);
	@Autowired MostSellingManager mostSellingManager;
	@Autowired GenericSearchRepository searchRepository;

	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> saveMostSelling(@RequestBody MostSellingView view, HttpServletRequest request){
		logger.info("mostSelling save service call started - {0}", new Date());
		ResponseView res=new ResponseView();

		MostSelling mostSelling = null;
		try {

			mostSelling = mostSellingManager.findByProductName(view.getProductName());
			if(mostSelling==null) {
				mostSelling = new MostSelling();
				BeanUtils.copyProperties(view, mostSelling);
				DateUtils.setBaseData(mostSelling, "System");
				res.setMessage("MostSelling added successfully");
				res.setStatus(true);
			}else{
				BeanUtils.copyProperties(view, mostSelling,"id");
				DateUtils.setModifiedBaseData(mostSelling, "System");
				res.setMessage("MostSelling updated successfully");
			}
			res.setStatus(true);
			mostSellingManager.save(mostSelling);
		}catch(Exception e) {
			logger.error("Exception while mostSelling save info - {0}", e, e.getMessage());
			res.setMessage("Saving MostSelling Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("mostSelling save service call completed - {0}", new Date());
		return toSuccess(res);
	}

	@PostMapping(value="/list",produces= MediaType.APPLICATION_JSON_VALUE)
	ResponseEntity<Message> searchList(@RequestBody SearchRequest searchRequest, HttpServletRequest request)
	{
		List<MostSelling> list = mostSellingManager.search(searchRequest);
		long count = mostSellingManager.searchCount(searchRequest);
		List<MostSellingView> views = new ArrayList<>();
		for(MostSelling mostSelling:list)
		{
			MostSellingView view = new MostSellingView();
			BeanUtils.copyProperties(mostSelling, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(count, views));
	}
}
