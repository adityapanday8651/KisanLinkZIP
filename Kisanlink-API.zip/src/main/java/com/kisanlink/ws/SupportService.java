package com.kisanlink.ws;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.Support;
import com.kisanlink.mongo.manager.SupportManager;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;
import com.kisanlink.view.SupportView;

@RestController
@RequestMapping(path=APIEndpoints.BASE_API_URL_V1+"/support")
public class SupportService extends GenericService {
	private static VCLogger logger = VCLogManager.getLogger(SupportService.class);

	@Autowired SupportManager supportManager;

	String methodName=null;
	String apiUrl="kisanlink"+APIEndpoints.BASE_API_URL_V1+"/support";

	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> supportSave(@RequestBody SupportView view, HttpServletRequest request){
		logger.info("support save service call started - {0}", new Date());
		ResponseView res = new ResponseView();
		Support support = null;
		try {
			support = supportManager.findBySupportId(view.getSupportId());
			if(support==null) {
				support = new Support();
				BeanUtils.copyProperties(view, support);
				DateUtils.setBaseData(support, "System");
				res.setMessage("support details  added successfully");
			}else{
				BeanUtils.copyProperties(view, support,"id");
				DateUtils.setModifiedBaseData(support, "System");
				res.setMessage("support details updated successfully");
			}
			res.setStatus(true);
			supportManager.save(support);
		}catch(Exception e) {
			logger.error("Exception while support details save info - {0}", e, e.getMessage());
			res.setMessage("Saving support Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("support save service call completed - {0}", new Date());
		return toSuccess(res);
	}

	@CrossOrigin
	@PostMapping(value = "/list", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> getAllsupportList(@RequestBody SearchRequest searchRequest) {
		List<SupportView> views = new ArrayList<>();
		List<Support> supportList = supportManager.search(searchRequest);
		long count = supportManager.searchCount(searchRequest);
		for(Support support : supportList) {
			SupportView view = new SupportView();
			BeanUtils.copyProperties(support, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(count, views));
	}



}
