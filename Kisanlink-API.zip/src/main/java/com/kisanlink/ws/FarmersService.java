package com.kisanlink.ws;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.StringJoiner;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.RandomStringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.exception.ServiceException;
import com.kisanlink.filter.Search;
import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.http.HttpRequest;
import com.kisanlink.model.http.HttpUtil;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.AllIdConfiguration;
import com.kisanlink.mongo.BankDetails;
import com.kisanlink.mongo.Farmers;
import com.kisanlink.mongo.OTPDetails;
import com.kisanlink.mongo.Orders;
import com.kisanlink.mongo.manager.AllIdConfigurationManager;
import com.kisanlink.mongo.manager.BankDetailsManager;
import com.kisanlink.mongo.manager.ConfigurationManager;
import com.kisanlink.mongo.manager.FarmersManager;
import com.kisanlink.mongo.manager.OTPDetailsManager;
import com.kisanlink.mongo.manager.OrdersManager;
import com.kisanlink.service.core.GenericSearchRepository;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.ConfigurationConstants1;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.FarmerAllView;
import com.kisanlink.view.FarmersView;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.OTPDetailsView;
import com.kisanlink.view.OrdersView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(path=APIEndpoints.BASE_API_URL_V1+"/farmers")
public class FarmersService extends GenericService{
	private static VCLogger logger = VCLogManager.getLogger(FarmersService.class);

	@Autowired FarmersManager farmersManager;
	@Autowired GenericSearchRepository searchRepository;
	@Autowired AllIdConfigurationManager allIdConfigurationManager;
	@Autowired ConfigurationManager configurationManager;
	@Autowired OTPDetailsManager otpManager;
	@Autowired HttpUtil util;
	@Autowired BankDetailsManager bankManager;
	@Autowired OrdersManager ordersManager;

	String methodName=null;

	@CrossOrigin
	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> saveFarmers(@RequestBody FarmersView view, HttpServletRequest request){
		logger.info("Farmers save service call started - {0}", new Date());
		ResponseView res=new ResponseView();
		Farmers farmers = null;
		try {

			farmers = farmersManager.findByMobileNumber(view.getMobileNumber());
			AllIdConfiguration config=	allIdConfigurationManager.findByName("farmer");

			if(farmers==null) {
				farmers = new Farmers();
				BeanUtils.copyProperties(view, farmers);
				DateUtils.setBaseData(farmers, view.getKisansathiName());
				res.setMessage("Farmers added successfully");
				res.setStatus(true);
			}else{
				BeanUtils.copyProperties(view, farmers,"id");
				DateUtils.setModifiedBaseData(farmers, view.getKisansathiName());
				res.setMessage("Farmers updated successfully");
			}

			if(config==null) {
				config=new AllIdConfiguration();
				config.setLastGeneratedId(20000);
				config.setName("farmer");
				farmers.setFarmerId(config.getLastGeneratedId());
				DateUtils.setBaseData(config, "System");
			}else {
				farmers.setFarmerId(config.getLastGeneratedId()+1);
				config.setLastGeneratedId(config.getLastGeneratedId()+1);
				DateUtils.setModifiedBaseData(config, "System");
			}
			allIdConfigurationManager.save(config);
			res.setStatus(true);
			farmersManager.save(farmers);
		}catch(Exception e) {
			logger.error("Exception while farmers save info - {0}", e, e.getMessage());
			res.setMessage("Saving Farmers Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("Farmers save service call completed - {0}", new Date());
		return toSuccess(res);
	}

	@CrossOrigin
	@PostMapping(value="/list",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> getAllFarmers(@RequestBody SearchRequest searchRequest){
		List<FarmersView> views = new ArrayList<>();
		List<Farmers> list = farmersManager.search(searchRequest);
		for(Farmers farm : list) {
			FarmersView view = new FarmersView();
			BeanUtils.copyProperties(farm, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(views.size(),views));	
	}

	@CrossOrigin
	@DeleteMapping(value="/delete/{id}", produces= MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> deleteFarmers(@PathVariable("id") String id){
		ResponseView res=new ResponseView();
		farmersManager.deleteById(id);
		res.setMessage("Farmer Deleted Successfully");
		res.setStatus(true);
		return toSuccess(res);
	}

	@CrossOrigin
	@GetMapping(value = "/request/otp/{phoneNumber}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> farmerRequestOtp(@PathVariable("phoneNumber") String phoneNumber) throws ServiceException {
		logger.info("farmerRequestOtpstarted - {0}", new Date());
		String otp="";
		String message=null;
		ResponseView res = new ResponseView();
		if(phoneNumber.equalsIgnoreCase("8885299977")) {
			otp="8858";
		}else {
			otp = RandomStringUtils.randomNumeric(4);
		}
		message=otp+" "+configurationManager.findValueByKey(ConfigurationConstants1.SMS_VERIFICATION_MSG);		
		OTPDetails details = otpManager.findByMobileNumber(Long.parseLong(phoneNumber));
		if(details==null) details = new OTPDetails();
		details.setMobileNumber(Long.parseLong(phoneNumber));
		details.setCreatedDate(new Date());
		details.setOtp(otp);
		otpManager.save(details);
		sendOtp(phoneNumber,message);
		res.setMessage(otp);
		res.setStatus(true);
		logger.info("farmerRequestOtp completed - {0}", new Date());
		return toSuccess(res);
	}

	private void sendOtp(String phoneNumber,String message) {
		logger.info("send Otp service call started - {0}", new Date());
		String encodedMassage=URLEncoder.encode(message);
		StringJoiner joiner = new StringJoiner("&");
		joiner.add("AUTH_KEY="+configurationManager.findValueByKey(ConfigurationConstants1.AUTH_KEY));
		joiner.add("message="+encodedMassage);
		joiner.add("senderId="+configurationManager.findValueByKey(ConfigurationConstants1.SENDER_ID));
		joiner.add("routeId="+configurationManager.findValueByKey(ConfigurationConstants1.ROUTE_ID));
		joiner.add("mobileNos="+phoneNumber);
		joiner.add("smsContentType="+configurationManager.findValueByKey(ConfigurationConstants1.SMS_CONTENT_TYPE));		

		HttpRequest request=new HttpRequest();
		request.setUrl(new StringBuilder().append(configurationManager.findValueByKey(ConfigurationConstants1.SMS_URL)).append("?").append(joiner.toString()).toString());

		try {
			util.get(request);
		} catch (Exception e) {		
			logger.error("Exception while send otp info - {0}", e, e.getMessage());
		}
		logger.info("send Otp service call completed - {0}", new Date());
	}

	@CrossOrigin
	@PostMapping(value = "/otp/validate", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> checkOTP(@RequestBody OTPDetailsView view) {
		logger.info("check OTP service call started - {0}", new Date());
		OTPDetails details = otpManager.findByMobileNumber(view.getMobileNumber());
		ResponseView res = new ResponseView();
		if(details != null && details.getOtp().equalsIgnoreCase(view.getOtp())) {
			res.setMessage("OTP valid");
			res.setStatus(true);
		}else {
			res.setMessage("OTP invalid");
			res.setStatus(false);
		}
		logger.info("check OTP service call completed - {0}", new Date());
		return toSuccess(res);
	}

	@CrossOrigin
	@PostMapping(value = "/get/all/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getAll(@PathVariable("id") int id) {
		logger.info("get all new start- {0}", new Date());
		FarmerAllView view = new FarmerAllView();
		Farmers farmer = farmersManager.findByFarmerId(id);
		BeanUtils.copyProperties(farmer, view);
		BankDetails bankDetails = bankManager.findByUserId(farmer.getId());
		view.setBankDetails(bankDetails);

		SearchRequest request = new SearchRequest();
		request.setCurrentPage(0);
		request.setPageSize(10);
		request.setSort("DESC");
		request.setSortBy("createdAt");

		List<Search> serachList = new ArrayList<>();
		serachList.add(new Search("orderStage", "Current", "eq"));
		request.setSearch(serachList);

		List<Orders> orderList = ordersManager.search(request);
		List<OrdersView> views = new ArrayList<>();
		for(Orders order : orderList) {
			OrdersView ov = new OrdersView();
			BeanUtils.copyProperties(order, ov);
			views.add(ov);
		}		
		view.setOrdersList(views);
		logger.info("get all new end - {0}", new Date());
		return toSuccess(view);
	}
}