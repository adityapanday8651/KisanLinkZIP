package com.kisanlink.ws;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.Subsidies;
import com.kisanlink.mongo.manager.SubsidiesManager;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;
import com.kisanlink.view.SubsidiesView;

@RestController
@RequestMapping(path=APIEndpoints.BASE_API_URL_V1+"/subsidy")
public class SubsidiesService extends GenericService {
	@Autowired SubsidiesManager subsidiesManager;
	private static VCLogger logger = VCLogManager.getLogger(SubsidiesService.class);
	String methodName = null;
	String apiUrl = "kisanlink"+APIEndpoints.BASE_API_URL_V1+"/subsidy";
	@PostMapping(value="/save", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> save(@RequestBody SubsidiesView view, HttpServletRequest request)
	{
		logger.info("subsidy save service call started - {0}", new Date());
		ResponseView res = new ResponseView();
		Subsidies subsidies = null;
		try {
			subsidies = subsidiesManager.findByid(view.getId());
			if(subsidies==null)
			{
				subsidies = new Subsidies();
				BeanUtils.copyProperties(view, subsidies);
				DateUtils.setBaseData(subsidies, "System");
				res.setMessage("subsidy save successfully");
			}
			else
			{
				BeanUtils.copyProperties(view, subsidies,"id");
				DateUtils.setModifiedBaseData(subsidies, "System");
				res.setMessage("subsidy updated successfully");
			}
			res.setStatus(true);
			subsidiesManager.save(subsidies);
		}catch(Exception e)
		{
			logger.error("Exception while saving subsidy info - {0}", e, e.getMessage());
			res.setMessage("subsidy saving failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("subsidy save service call completed - {0}", new Date());
		return toSuccess(res);

	}
	
	@PostMapping(value="/list", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> list(@RequestBody SearchRequest request)
	{
		List<Subsidies> list = subsidiesManager.search(request);
		long count = subsidiesManager.searchCount(request);
		List<SubsidiesView> views = new ArrayList<>();
		for(Subsidies subsidies : list)
		{
			SubsidiesView view = new SubsidiesView();
			BeanUtils.copyProperties(subsidies, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(count, views));
		
	}
}
