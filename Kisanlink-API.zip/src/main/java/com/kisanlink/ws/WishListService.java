package com.kisanlink.ws;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.mongo.Farms;
import com.kisanlink.mongo.WishList;
import com.kisanlink.mongo.manager.WishListManager;
import com.kisanlink.service.core.GenericSearchRepository;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;
import com.kisanlink.view.WishListView;

@RestController
@RequestMapping(path="/wishlist")
public class WishListService extends GenericService{
	private static VCLogger logger = VCLogManager.getLogger(ServicesService.class);

	@Autowired WishListManager wishListManager;
	@Autowired GenericSearchRepository searchRepository;

	String methodName=null;

	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> saveWishList(@RequestBody WishListView view, HttpServletRequest request){
		logger.info("wishList save service call started - {0}", new Date());
		ResponseView res=new ResponseView();

		WishList wishList = null;
		try {

			wishList =wishListManager.findByFarmerId(view.getFarmerId());
			if(wishList==null) {
				wishList = new WishList();
				BeanUtils.copyProperties(view, wishList);
				DateUtils.setBaseData(wishList, "System");
				res.setMessage("WishList added successfully");
				res.setStatus(true);
			}else{
				BeanUtils.copyProperties(view, wishList,"id");
				DateUtils.setModifiedBaseData(wishList, "System");
				res.setMessage("WishList updated successfully");
			}
			res.setStatus(true);
			wishListManager.save(wishList);
		}catch(Exception e) {
			logger.error("Exception while wishList save info - {0}", e, e.getMessage());
			res.setMessage("Saving wishList Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("wishList save service call completed - {0}", new Date());
		return toSuccess(res);
	}

	@GetMapping(value="/list", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getAllWishLists(){
		List<WishList> list=wishListManager.findAll();
		return toSuccess(new ListResponseView(list.size(),list));
	}

	@GetMapping(value="/find/{farmerId}", produces=MediaType.APPLICATION_JSON_VALUE)
	public WishList findWishListByFarmerId(@PathVariable("farmerId") String farmerId) {
		return wishListManager.findByFarmerId(farmerId);	
	}

	@SuppressWarnings("unchecked")
	@CrossOrigin
	@PostMapping(value="/search", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> searchFarms(@RequestBody SearchRequest searchRequest,String createdBy){
		List<WishList> wishList=(List<WishList>) searchRepository.search(searchRequest,  createdBy, createdBy, Farms.class); 
		return toSuccess(new ListResponseView(wishList.size(),wishList));		
	}			
}
