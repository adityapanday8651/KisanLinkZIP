package com.kisanlink.ws;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.AllIdConfiguration;
import com.kisanlink.mongo.Collaborator;
import com.kisanlink.mongo.manager.AllIdConfigurationManager;
import com.kisanlink.mongo.manager.CollaboratorManager;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.CollaboratorView;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(value=APIEndpoints.BASE_API_URL_V1+"/collaborator")
public class CollaboratorService extends GenericService {
	@Autowired CollaboratorManager collaboratorManager;
	@Autowired AllIdConfigurationManager allIdConfigurationManager;
	private static VCLogger logger = VCLogManager.getLogger(CollaboratorService.class);
	String methodName=null;
	String apiUrl="kisanlink"+APIEndpoints.BASE_API_URL_V1+"/collaborator";

	@PostMapping(value="/save", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> save(@RequestBody CollaboratorView view, HttpServletRequest request)
	{
		logger.info("collaborator service call started - {0}", new Date());
		ResponseView res = new ResponseView();
		Collaborator collaborator = null;
		try {
			collaborator = collaboratorManager.findByid(view.getId());
			AllIdConfiguration config=allIdConfigurationManager.findByName("collaborator");

			if(collaborator==null)
			{
				collaborator = new Collaborator();
				BeanUtils.copyProperties(view, collaborator);
				DateUtils.setBaseData(collaborator, "System");
				res.setMessage("collaborator save successfully");
			}
			else
			{
				BeanUtils.copyProperties(view, collaborator, "id");
				DateUtils.setModifiedBaseData(collaborator, "System");
				res.setMessage("collaborator update successfully");
			}
			if(config==null) {
				config = new AllIdConfiguration();
				config.setLastGeneratedId(40000);
				collaborator.setCollaboratorId(config.getLastGeneratedId());
				DateUtils.setBaseData(config, "System");
			}else {
				collaborator.setCollaboratorId(config.getLastGeneratedId()+1);
				config.setLastGeneratedId(config.getLastGeneratedId()+1);
				collaborator.setCollaboratorId(config.getLastGeneratedId());
				DateUtils.setBaseData(config, "System");
			}
			allIdConfigurationManager.save(config);
			res.setStatus(true);
			allIdConfigurationManager.save(config);
			collaboratorManager.save(collaborator);
		}
		catch(Exception e)
		{
			logger.error("Exception while saving collaborator info - {0}", e, e.getMessage());
			res.setMessage("collaborator saving failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("collaborator service call completed - {0}", new Date());
		return toSuccess(res);

	}

	@PostMapping(value="/list", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> list(@RequestBody SearchRequest request)
	{
		List<CollaboratorView> views = new ArrayList<>();
		List<Collaborator> list = collaboratorManager.search(request);
		long count = collaboratorManager.searchCount(request);
		for(Collaborator collaborator: list)
		{
			CollaboratorView view = new CollaboratorView();
			BeanUtils.copyProperties(collaborator, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(count, views));		
	}
}