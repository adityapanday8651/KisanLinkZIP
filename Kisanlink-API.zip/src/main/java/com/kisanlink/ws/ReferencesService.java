package com.kisanlink.ws;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.AllIdConfiguration;
import com.kisanlink.mongo.References;
import com.kisanlink.mongo.manager.AllIdConfigurationManager;
import com.kisanlink.mongo.manager.ReferencesManager;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ReferencesView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(path=APIEndpoints.BASE_API_URL_V1+"/reference")
public class ReferencesService extends GenericService {
	@Autowired ReferencesManager referencesManager;
	@Autowired AllIdConfigurationManager allIdConfigurationManager;
	private static VCLogger logger = VCLogManager.getLogger(ReferencesService.class);
	String methodName =null;
	String apiUrl = "kisanlink"+APIEndpoints.BASE_API_URL_V1+"/reference";

	@PostMapping(value="/save", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> save(@RequestBody ReferencesView view, HttpServletRequest request)
	{
		logger.info("reference save service call stared - {0}", new Date());
		References references =null;
		ResponseView res = new ResponseView();
		try {
			references = referencesManager.findByid(view.getId());
			AllIdConfiguration config = allIdConfigurationManager.findByName("ref");
			if(references==null)
			{
				references = new References();
				BeanUtils.copyProperties(view, references);
				DateUtils.setBaseData(references, "System");
				res.setMessage("references saved successfully");
			}
			else
			{
				BeanUtils.copyProperties(view, references, "id");
				DateUtils.setModifiedBaseData(references, "System");
				res.setMessage("references updated successfully");
			}
			
			if(config==null)
			{
				config = new AllIdConfiguration();
				config.setLastGeneratedId(20000);
				references.setReferenceId(config.getLastGeneratedId());
				DateUtils.setBaseData(config, "System");
			}
			else
			{
				references.setReferenceId(config.getLastGeneratedId()+1);
				config.setLastGeneratedId(config.getLastGeneratedId()+1);
				DateUtils.setModifiedBaseData(config, "System");
			}
			res.setStatus(true);
			referencesManager.save(references);
			allIdConfigurationManager.save(config);
		}catch(Exception e)
		{
			logger.error("Exception while saving references info - {0}", e, e.getMessage());
			res.setMessage("references saving failed");
			res.setStatus(true);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("references save service call completed - {0}", new Date());
		return toSuccess(res);

	}

	@PostMapping(value="/list", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> list(@RequestBody SearchRequest request)
	{
		List<References> list = referencesManager.search(request);
		long count = referencesManager.searchCount(request);
		List<ReferencesView> views = new ArrayList<>();
		for(References references : list)
		{
			ReferencesView view = new ReferencesView();
			BeanUtils.copyProperties(references, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(count, views));

	}

} 

