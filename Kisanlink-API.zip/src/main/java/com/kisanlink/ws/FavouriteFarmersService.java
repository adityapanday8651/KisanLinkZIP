package com.kisanlink.ws;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.Farmers;
import com.kisanlink.mongo.FavouriteFarmers;
import com.kisanlink.mongo.manager.AllIdConfigurationManager;
import com.kisanlink.mongo.manager.FarmersManager;
import com.kisanlink.mongo.manager.FavouriteFarmersManager;
import com.kisanlink.mongo.repository.FavouriteFarmersRepository;
import com.kisanlink.service.core.GenericSearchRepository;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.FavouriteFarmersView;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(path=APIEndpoints.BASE_API_URL_V1+"/favouriteFarmers")
public class FavouriteFarmersService extends GenericService{
	private static VCLogger logger = VCLogManager.getLogger(FavouriteFarmersService.class);

	@Autowired FavouriteFarmersManager favouriteFarmersManager;
	@Autowired FarmersManager farmersManager;
	@Autowired GenericSearchRepository searchRepository;
	@Autowired AllIdConfigurationManager allIdConfigurationManager;
	@Autowired FavouriteFarmersRepository favRepo;

	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> saveFavouriteFarmers(@RequestBody FavouriteFarmersView view, HttpServletRequest request){
		logger.info("FavouriteFarmers save service call started - {0}", new Date());
		ResponseView res=new ResponseView();

		try {

			Farmers farmer = farmersManager.findByFarmerId(view.getFarmerId());
			if(farmer == null) {
				res.setMessage("No farmer data exists with the given id");
				res.setStatus(false);
				return toError404(res);
			}

			FavouriteFarmers fav = new FavouriteFarmers();
			fav.setFarmerId(view.getFarmerId());
			fav.setKisansathiId(farmer.getKisansathiId());
			fav.setFarmerName(view.getFarmerName());
			fav.setImage(farmer.getImage());
			DateUtils.setBaseData(fav, getLoggedInUserName());
			res.setMessage("Favourite farmer added successfully");
			res.setStatus(true);
			farmer.setFavorite(true);
			DateUtils.setModifiedBaseData(farmer, getLoggedInUserName());
			farmersManager.save(farmer);
			favouriteFarmersManager.save(fav);
		}catch(Exception e) {
			logger.error("Exception while favouriteFarmers save info - {0}", e, e.getMessage());
			res.setMessage("Saving FavouriteFarmers Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("favouriteFarmers save service call completed - {0}", new Date());
		return toSuccess(res);
	}

	@PostMapping(value="/delete", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> removeFavouriteFarmers(@RequestBody FavouriteFarmersView view, HttpServletRequest request){
		logger.info("FavouriteFarmers save service call started - {0}", new Date());
		ResponseView res=new ResponseView();
		try {

			Farmers farmer = farmersManager.findByFarmerId(view.getFarmerId());
			FavouriteFarmers fav = favouriteFarmersManager.findByFarmerId(view.getFarmerId());

			if(farmer == null || fav == null) {
				res.setMessage("No farmer data exists with the given id");
				res.setStatus(false);
				return toError404(res);
			}

			favRepo.delete(fav);
			farmer.setFavorite(false);
			DateUtils.setModifiedBaseData(farmer, getLoggedInUserName());
			farmersManager.save(farmer);
			res.setMessage("Favourite farmer deleted successfully");
			res.setStatus(true);
		}catch(Exception e) {
			logger.error("Exception while favouriteFarmers save info - {0}", e, e.getMessage());
			res.setMessage("Saving FavouriteFarmers Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("favouriteFarmers save service call completed - {0}", new Date());
		return toSuccess(res);
	}

	@CrossOrigin
	@PostMapping(value="/list",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> searchFavouriteFarmers(@RequestBody SearchRequest searchRequest){
		List<FavouriteFarmersView> views = new ArrayList<>();
		List<FavouriteFarmers> list = favouriteFarmersManager.search(searchRequest);
		for(FavouriteFarmers favouriteFarmers : list) {
			FavouriteFarmersView view = new FavouriteFarmersView();
			BeanUtils.copyProperties(favouriteFarmers, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(list.size(),list));	
	}	
}
