package com.kisanlink.ws;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.Brand;
import com.kisanlink.mongo.Comodities;
import com.kisanlink.mongo.manager.BrandManager;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.BrandView;
import com.kisanlink.view.ComoditiesView;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(path=APIEndpoints.BASE_API_URL_V1+"/brand")
public class BrandService extends GenericService{
	private static VCLogger logger = VCLogManager.getLogger(BrandService.class);
	
	@Autowired BrandManager brandManager;
	
	@CrossOrigin
	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> saveBrand(@RequestBody BrandView view, HttpServletRequest request){
		logger.info("brand save service call started - {0}", new Date());
		ResponseView res=new ResponseView();
		Brand brand = null;
		try {

			brand = brandManager.findByName(view.getName());
			if(brand==null) {
				brand = new Brand();
				BeanUtils.copyProperties(view, brand);
				DateUtils.setBaseData(brand, "System");
				res.setMessage("Brand added successfully");
				res.setStatus(true);
			}else{
				BeanUtils.copyProperties(view, brand,"id");
				DateUtils.setModifiedBaseData(brand, "System");
				res.setMessage("Brand updated successfully");
			}
			res.setStatus(true);
			brandManager.save(brand);
		}catch(Exception e) {
			logger.error("Exception while brand save info - {0}", e, e.getMessage());
			res.setMessage("Saving Brand Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("brand save service call completed - {0}", new Date());
		return toSuccess(res);
	}
	
	@CrossOrigin
	@PostMapping(value="/list",produces= MediaType.APPLICATION_JSON_VALUE)
	ResponseEntity<Message> list(@RequestBody SearchRequest searchRequest, HttpServletRequest request)
	{
		List<Brand> list = brandManager.search(searchRequest);
		long count = brandManager.searchCount(searchRequest);
		List<BrandView> views = new ArrayList<>();
		for(Brand brand:list)
		{
			BrandView view = new BrandView();
			BeanUtils.copyProperties(brand, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(count, views));
	}
	
	@CrossOrigin
	@DeleteMapping(value="/delete/{id}",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> deleteBrand(@PathVariable("id") String id){
		ResponseView res=new ResponseView();
		brandManager.deleteById(id);
		res.setMessage("Brand Deleted Successfully");
		res.setStatus(true);
		return toSuccess(res);
	}
}
