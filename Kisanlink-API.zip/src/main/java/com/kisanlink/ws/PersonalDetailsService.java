package com.kisanlink.ws;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.Agricenter;
import com.kisanlink.mongo.PersonalDetails;
import com.kisanlink.mongo.manager.PersonalDetailsManager;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.ComoditiesView;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.PersonalDetailsView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(path="/personalDetails")
public class PersonalDetailsService extends GenericService{
	private static VCLogger logger = VCLogManager.getLogger(PersonalDetailsService.class);
	@Autowired PersonalDetailsManager personalDetailsManager;
	
	@PostMapping(value="/save", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> saveAgicenter(@RequestBody PersonalDetailsView view){
		logger.info("personalDetails save service call started - {0}", new Date());
		ResponseView res=new ResponseView();
		PersonalDetails personalDetails=null;
		try {
			personalDetails =personalDetailsManager.findByUserId(view.getUserId());
			if(personalDetails==null) {
				personalDetails = new PersonalDetails();
				BeanUtils.copyProperties(view, personalDetails);
				DateUtils.setBaseData(personalDetails, "System");
				res.setMessage("PersonalDetails added Successfully");
				res.setStatus(true);
			}else {
				BeanUtils.copyProperties(view, personalDetails,"id");
				DateUtils.setModifiedBaseData(personalDetails, "System");
				res.setMessage("PersonalDetails Updated Successfully");
			}
			res.setStatus(true);
			personalDetailsManager.save(personalDetails);
		}catch(Exception e) {
			logger.error("Exception while PersonalDetails save info - {0}", e, e.getMessage());
			res.setMessage("Saving PersonalDetails Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("PersonalDetails save service call completed - {0}", new Date());
		return toSuccess(res);
	}
	
	
	@PostMapping(value="/list",produces= MediaType.APPLICATION_JSON_VALUE)
	ResponseEntity<Message> list(@RequestBody SearchRequest searchRequest, HttpServletRequest request)
	{
		List<PersonalDetails> list = personalDetailsManager.search(searchRequest);
		long count = personalDetailsManager.searchCount(searchRequest);
		List<PersonalDetailsView> views = new ArrayList<>();
		for(PersonalDetails personalDetails:list)
		{
			PersonalDetailsView view = new PersonalDetailsView();
			BeanUtils.copyProperties(personalDetails, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(count, views));
	}		
}
