package com.kisanlink.ws;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.mongo.Bids;
import com.kisanlink.mongo.manager.BidsManager;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.BidsView;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(path="/bids")
public class BidsService extends GenericService{
	private static VCLogger logger = VCLogManager.getLogger(BidsService.class);

	@Autowired BidsManager bidsManager;
	String methodName=null;

	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> saveCarts(@RequestBody BidsView view, HttpServletRequest request){
		logger.info("bids save service call started - {0}", new Date());
		ResponseView res=new ResponseView();
		Bids bids = null;
		try {

			bids = bidsManager.findByProductName(view.getProductName());
			if(bids==null) {
				bids = new Bids();
				BeanUtils.copyProperties(view, bids);
				DateUtils.setBaseData(bids, "System");
				res.setMessage("Bids added successfully");
				res.setStatus(true);
			}else{
				BeanUtils.copyProperties(view, bids,"id");
				DateUtils.setModifiedBaseData(bids, "System");
				res.setMessage("Bids updated successfully");
			}
			res.setStatus(true);
			bidsManager.save(bids);
		}catch(Exception e) {
			logger.error("Exception while bids save info - {0}", e, e.getMessage());
			res.setMessage("Saving Bids Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("bids save service call completed - {0}", new Date());
		return toSuccess(res);
	}
	
	@GetMapping(value="/list", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getAllBids(){
		List<Bids> list=bidsManager.findAll();
		return toSuccess(new ListResponseView(list.size(), list));
	}
	
	@GetMapping(value="/find/{productName}", produces=MediaType.APPLICATION_JSON_VALUE)
	public Bids findBidsByProductName(@PathVariable("productName") String productName) {
		return bidsManager.findByProductName(productName);
	}
}
