package com.kisanlink.ws;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.Goals;
import com.kisanlink.mongo.manager.GoalsManager;
import com.kisanlink.mongo.manager.UserManager;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.GoalsView;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(path=APIEndpoints.BASE_API_URL_V1+"/goals")
public class GoalsService extends GenericService {
	private static VCLogger logger = VCLogManager.getLogger(GoalsService.class);

	@Autowired GoalsManager goalsManager;
	@Autowired UserManager userManager;

	String methodName=null;
	String apiUrl="kisanlink"+APIEndpoints.BASE_API_URL_V1+"/goals";

	@PostMapping(value="/save", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> goalsSave(@RequestBody GoalsView view, HttpServletRequest request){
		logger.info("goals save service call started - {0}", new Date());
		ResponseView res = new ResponseView();
		Goals goals = null;
		Optional<Goals> opt = null;

		try {
			if(view.getId() != null) {
				opt = goalsManager.findById(view.getId());
				if(opt.isPresent()) {
					goals = opt.get();
				}
			}
			
			if(goals==null) {
				goals = new Goals();
				BeanUtils.copyProperties(view, goals);
				DateUtils.setBaseData(goals, "System");
				res.setMessage("goals details  added successfully");
			}else{
				BeanUtils.copyProperties(view, goals,"id");
				DateUtils.setModifiedBaseData(goals, "System");
				res.setMessage("goals details updated successfully");
			}
			res.setStatus(true);
			goalsManager.save(goals);
		}catch(Exception e) {
			logger.error("Exception while goals details save info - {0}", e, e.getMessage());
			res.setMessage("Saving goals Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("goals save service call completed - {0}", new Date());
		return toSuccess(res);
	}

	@CrossOrigin
	@PostMapping(value = "/list", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> goalsList(@RequestBody SearchRequest searchRequest) {
		List<GoalsView> views = new ArrayList<>();
		List<Goals> goalsList = goalsManager.search(searchRequest);
		long count = goalsManager.searchCount(searchRequest);
		for(Goals goals : goalsList) {
			GoalsView view = new GoalsView();
			BeanUtils.copyProperties(goals, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(count, views));
	}
}