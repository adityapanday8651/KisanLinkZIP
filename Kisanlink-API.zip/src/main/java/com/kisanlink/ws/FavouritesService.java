package com.kisanlink.ws;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.Favourites;
import com.kisanlink.mongo.manager.FavouritesManager;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.FavouritesView;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(path=APIEndpoints.BASE_API_URL_V1+"/favourite")
public class FavouritesService extends GenericService {
	private static VCLogger logger = VCLogManager.getLogger(FavouritesService.class);

	@Autowired FavouritesManager favouritesManager;
	
	String methodName=null;
	String apiUrl="kisanlink"+APIEndpoints.BASE_API_URL_V1+"/favourite";
	
	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> groundSave(@RequestBody FavouritesView view, HttpServletRequest request){
		logger.info("favourites save service call started - {0}", new Date());
		ResponseView res = new ResponseView();
		Favourites favourites = null;
		try {
			favourites = favouritesManager.findByfavId(view.getFavId());
			if(favourites==null) {
				favourites = new Favourites();
				BeanUtils.copyProperties(view, favourites);
				DateUtils.setBaseData(favourites, "System");
				res.setMessage("favourites details  added successfully");
			}else{
				BeanUtils.copyProperties(view, favourites,"id");
				DateUtils.setModifiedBaseData(favourites, "System");
				res.setMessage("favourites details updated successfully");
			}
			res.setStatus(true);
			favouritesManager.save(favourites);
		}catch(Exception e) {
			logger.error("Exception while favourites details save info - {0}", e, e.getMessage());
			res.setMessage("Saving favourites Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("favourites save service call completed - {0}", new Date());
		return toSuccess(res);
	}
	
	@CrossOrigin
	@PostMapping(value = "/list", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> getAllBankList(@RequestBody SearchRequest searchRequest) {
		List<FavouritesView> views = new ArrayList<>();
		List<Favourites> favouritesList = favouritesManager.search(searchRequest);
		long count = favouritesManager.searchCount(searchRequest);
		for(Favourites favourites : favouritesList) {
			FavouritesView view = new FavouritesView();
			BeanUtils.copyProperties(favourites, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(count, views));
	}

	
	
}
