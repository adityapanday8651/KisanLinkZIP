package com.kisanlink.ws;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.Agricenter;
import com.kisanlink.mongo.manager.AgricenterManager;
import com.kisanlink.service.core.GenericSearchRepository;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.AgricenterView;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(path = APIEndpoints.BASE_API_URL_V1 + "/agricenter")
public class AgricenterService extends GenericService{

	private static VCLogger logger = VCLogManager.getLogger(AgricenterService.class);

	@Autowired AgricenterManager agricenterManager;
	@Autowired GenericSearchRepository searchRepository;

	@PostMapping(value="/save", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> saveAgicenter(@RequestBody AgricenterView view){
		logger.info("agricenter save service call started - {0}", new Date());
		ResponseView res=new ResponseView();
		Agricenter agricenter=null;
		try {
			agricenter=agricenterManager.findByName(view.getName());
			if(agricenter==null) {
				agricenter=new Agricenter();
				BeanUtils.copyProperties(view, agricenter);
				DateUtils.setBaseData(agricenter, "System");
				res.setMessage("Agricenter added Successfully");
				res.setStatus(true);
			}else {
				BeanUtils.copyProperties(view, agricenter,"id");
				DateUtils.setModifiedBaseData(agricenter, "System");
				res.setMessage("Agricenter Updated Successfully");
			}
			res.setStatus(true);
			agricenterManager.save(agricenter);
		}catch(Exception e) {
			logger.error("Exception while agricenter save info - {0}", e, e.getMessage());
			res.setMessage("Saving Advisory Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("agricenter save service call completed - {0}", new Date());
		return toSuccess(res);
	}

	@SuppressWarnings("unchecked")
	@PostMapping(value="/search" ,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> searchAgricenter(@RequestBody SearchRequest searchRequest){
		List<Agricenter> searchAgricenter=(List<Agricenter>) searchRepository.search(searchRequest, Agricenter.class);
		return toSuccess(new ListResponseView(searchAgricenter.size(), searchAgricenter));
	}

	@PostMapping(value="/list",produces= MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> searchAll(@RequestBody SearchRequest searchRequest, HttpServletRequest request)
	{
		List<Agricenter> list = agricenterManager.search(searchRequest);
		long count = agricenterManager.searchCount(searchRequest);
		List<AgricenterView> views = new ArrayList<>();
		for(Agricenter agricenter:list)
		{
			AgricenterView view = new AgricenterView();
			BeanUtils.copyProperties(agricenter, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(count, views));
	}		
}
