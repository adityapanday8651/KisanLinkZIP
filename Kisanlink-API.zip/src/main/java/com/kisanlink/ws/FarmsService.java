package com.kisanlink.ws;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.AllIdConfiguration;
import com.kisanlink.mongo.Farmers;
import com.kisanlink.mongo.Farms;
import com.kisanlink.mongo.manager.AllIdConfigurationManager;
import com.kisanlink.mongo.manager.FarmersManager;
import com.kisanlink.mongo.manager.FarmsManager;
import com.kisanlink.service.core.GenericSearchRepository;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.FarmsView;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;

@RestController
@RequestMapping(path=APIEndpoints.BASE_API_URL_V1+"/farms")
public class FarmsService extends GenericService{
	private static VCLogger logger = VCLogManager.getLogger(FarmsService.class);

	@Autowired FarmsManager farmsManager;
	@Autowired GenericSearchRepository searchRepositroy;
	@Autowired AllIdConfigurationManager allIdConfigurationManager;
	@Autowired FarmersManager farmerManager;

	String methodName=null;

	@CrossOrigin
	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> userFarms(@RequestBody FarmsView view){
		logger.info("Farms save service call started - {0}", new Date());
		ResponseView res=new ResponseView();
		Farms farms = null;
		try {
			AllIdConfiguration config=	allIdConfigurationManager.findByName("farm");
			Farmers farmer = farmerManager.findByFarmerId(view.getFarmerId());
			if(view.getId() != null)farms = farmsManager.findById(view.getId());
			if(farms==null) {
				farms = new Farms();
				BeanUtils.copyProperties(view, farms);
				DateUtils.setBaseData(farms, view.getKisansathiName());
				if(farmer!=null)farmer.setNumberofFarms(farmer.getNumberofFarms()+1);
				res.setMessage("Farms added successfully");
				res.setStatus(true);
			}else{
				BeanUtils.copyProperties(view, farms,"id");
				DateUtils.setModifiedBaseData(farms, view.getKisansathiName());
				res.setMessage("Farms updated successfully");
			}

			if(config==null) {
				config=new AllIdConfiguration();
				config.setName("farm");
				config.setLastGeneratedId(200000);
				farms.setFarmId(config.getLastGeneratedId());
				DateUtils.setBaseData(config, "System");
			}else {
				farms.setFarmId(config.getLastGeneratedId()+1);
				config.setLastGeneratedId(config.getLastGeneratedId()+1);
				DateUtils.setModifiedBaseData(config, "System");
			}
			allIdConfigurationManager.save(config);
			res.setStatus(true);
			farmerManager.save(farmer);
			farmsManager.save(farms);
		}catch(Exception e) {
			logger.error("Exception while farms save info - {0}", e, e.getMessage());
			res.setMessage("Saving Farms Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("Farms save service call completed - {0}", new Date());
		return toSuccess(res);
	}

	@CrossOrigin
	@PostMapping(value="/list",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> getAllFarmers(@RequestBody SearchRequest searchRequest){
		List<FarmsView> views = new ArrayList<>();
		List<Farms> list = farmsManager.search(searchRequest);
		for(Farms farm : list) {
			FarmsView view = new FarmsView();
			BeanUtils.copyProperties(farm, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(list.size(),list));	
	}	
}