package com.kisanlink.ws;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kisanlink.filter.SearchRequest;
import com.kisanlink.logging.api.VCLogger;
import com.kisanlink.logging.api.impl.VCLogManager;
import com.kisanlink.model.message.Message;
import com.kisanlink.mongo.AllIdConfiguration;
import com.kisanlink.mongo.SoilTesting;
import com.kisanlink.mongo.manager.AllIdConfigurationManager;
import com.kisanlink.mongo.manager.SoilTestingManager;
import com.kisanlink.service.core.GenericSearchRepository;
import com.kisanlink.util.APIEndpoints;
import com.kisanlink.utilities.DateUtils;
import com.kisanlink.view.ListResponseView;
import com.kisanlink.view.ResponseView;
import com.kisanlink.view.SoilTestingView;

@RestController
@RequestMapping(path=APIEndpoints.BASE_API_URL_V1+"/soilTesting")
public class SoilTestingService extends GenericService{
	private static VCLogger logger = VCLogManager.getLogger(SoilTestingService.class);
	
	@Autowired SoilTestingManager soilTestingManager;
	@Autowired GenericSearchRepository searchRepository;
	@Autowired AllIdConfigurationManager allIdConfigurationManager;
	
	@CrossOrigin
	@PostMapping(value="/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> saveSoilTesting(@RequestBody SoilTestingView view, HttpServletRequest request){
		logger.info("soilTesting save service call started - {0}", new Date());
		ResponseView res=new ResponseView();
		
		SoilTesting soilTesting = null;
		try {
			
			AllIdConfiguration config=	allIdConfigurationManager.findByName("soilTestingService");
			
			soilTesting =soilTestingManager.findByid(view.getId());
			if(soilTesting==null) {
				soilTesting = new SoilTesting();
				BeanUtils.copyProperties(view, soilTesting);
				DateUtils.setBaseData(soilTesting, "System");
				res.setMessage("SoilTesting added successfully");
				res.setStatus(true);
			}else{
				BeanUtils.copyProperties(view, soilTesting,"id");
				DateUtils.setModifiedBaseData(soilTesting, "System");
				res.setMessage("SoilTesting updated successfully");
			}
			
			if(config==null) {
				config=new AllIdConfiguration();
				config.setLastGeneratedId(80000);
				soilTesting.setServiceProviderId(config.getLastGeneratedId());
				DateUtils.setBaseData(config, "System");
			}else {
				soilTesting.setServiceProviderId(config.getLastGeneratedId()+1);
				config.setLastGeneratedId(config.getLastGeneratedId()+1);
				DateUtils.setModifiedBaseData(config, "System");
			}
			allIdConfigurationManager.save(config);
			
			res.setStatus(true);
			soilTestingManager.save(soilTesting);
		}catch(Exception e) {
			logger.error("Exception while soilTesting save info - {0}", e, e.getMessage());
			res.setMessage("Saving SoilTesting Failed");
			res.setStatus(false);
			return toError400(res);
		}
		res.setStatus(true);
		logger.info("soilTesting save service call completed - {0}", new Date());
		return toSuccess(res);
	}
	
	@CrossOrigin
	@PostMapping(value="/list",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> searchSoilTesting(@RequestBody SearchRequest searchRequest){
		List<SoilTestingView> views = new ArrayList<>();
		List<SoilTesting> list = soilTestingManager.search(searchRequest);
		for(SoilTesting soilTesting : list) {
			SoilTestingView view = new SoilTestingView();
			BeanUtils.copyProperties(soilTesting, view);
			views.add(view);
		}
		return toSucess(new ListResponseView(list.size(),list));	
	}	
	
	@CrossOrigin
	@DeleteMapping(value="/delete/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> deleteSoilTesting(@PathVariable("id") String id){
		ResponseView res=new ResponseView();
		soilTestingManager.deleteById(id);
		res.setMessage("SoilTesting Deleted Successfully");
		res.setStatus(true);
		return toSuccess(res);
	}	
}
